import React, { useMemo, useState } from 'react';
import { Search, Sparkles, X, BookOpen, CheckCircle2 } from 'lucide-react';
import { DivineNameEntry, SOUL_NEED_LABELS, SoulNeed } from '../data/divineNames';

interface DivineConstellationExplorerProps {
  names: DivineNameEntry[];
  revealedIds: Set<string>;
  studiedIds: Set<string>;
  onSelectName: (entry: DivineNameEntry) => void;
}

export const DivineConstellationExplorer: React.FC<DivineConstellationExplorerProps> = ({
  names,
  revealedIds,
  studiedIds,
  onSelectName,
}) => {
  const [query, setQuery] = useState('');
  const [activeNeed, setActiveNeed] = useState<SoulNeed | 'all'>('all');

  // Normalise for forgiving search: case, ё/е, Hebrew vowel points & cantillation,
  // Greek diacritics, and «» quotes so «Яхве-Шалом» matches "яхве шалом".
  const normalise = (s: string) =>
    s
      .toLowerCase()
      .replace(/ё/g, 'е')
      .normalize('NFD')
      .replace(/[\u0300-\u036f\u0591-\u05c7]/g, '')
      .replace(/[«»"'’\-–—·]/g, ' ')
      .replace(/\s+/g, ' ')
      .trim();

  const filtered = useMemo(() => {
    const q = normalise(query);
    const tokens = q.split(' ').filter(Boolean);
    return names.filter((item) => {
      if (activeNeed !== 'all' && item.soulNeed !== activeNeed) return false;
      if (tokens.length === 0) return true;
      const haystack = normalise(
        [
          item.transliteration,
          item.russianName,
          item.original,
          item.literalMeaning,
          item.strongs,
          item.category,
          item.number,
          ...item.keyVerses.map((v) => `${v.ref} ${v.synodal}`),
        ].join(' ')
      );
      return tokens.every((t) => haystack.includes(t));
    });
  }, [names, query, activeNeed]);

  return (
    <section
      id="constellation-atlas"
      className="scroll-mt-24 my-16 rounded-3xl border p-6 sm:p-9 shadow-xl"
      style={{
        backgroundColor: 'var(--gb-surface)',
        borderColor: 'var(--gb-gold)',
        boxShadow: 'var(--gb-shadow-xl)',
      }}
    >
      <div className="text-center">
        <div
          className="font-ui inline-flex items-center gap-2 rounded-full border px-3.5 py-1 text-xs font-semibold tracking-wider uppercase"
          style={{
            borderColor: 'var(--gb-border-strong)',
            backgroundColor: 'var(--gb-bg)',
            color: 'var(--gb-gold)',
          }}
        >
          <Sparkles className="h-3.5 w-3.5" />
          <span>Интерактивный справочник-созвездие</span>
        </div>

        <h2
          className="font-serif-display mt-3 text-2xl sm:text-3xl font-bold"
          style={{ color: 'var(--gb-ink)' }}
        >
          Сводная скрижаль всех 36 имён Бога
        </h2>
        <p
          className="font-body-editorial mx-auto mt-2 max-w-2xl text-sm sm:text-base"
          style={{ color: 'var(--gb-muted)' }}
        >
          Фильтруйте имена по богословской теме или нужде души, ищите по русскому названию,
          оригиналу, номеру Стронга или месту Писания.
        </p>
      </div>

      {/* Search Bar */}
      <div className="relative mx-auto mt-6 max-w-xl">
        <Search
          className="pointer-events-none absolute top-1/2 left-4 h-4 w-4 -translate-y-1/2"
          style={{ color: 'var(--gb-muted)' }}
        />
        <input
          id="constellation-search-input"
          type="text"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === 'Escape') {
              setQuery('');
              (e.target as HTMLInputElement).blur();
            }
            if (e.key === 'Enter' && filtered.length > 0) {
              onSelectName(filtered[0]);
            }
          }}
          aria-label="Поиск по именам Бога"
          placeholder="Поиск: Яхве, Шалом, Элохим, Иов 19, H3068, Пастырь..."
          className="font-ui w-full rounded-xl border py-3 pr-10 pl-11 text-sm outline-none transition-colors"
          style={{
            backgroundColor: 'var(--gb-bg)',
            borderColor: 'var(--gb-border-strong)',
            color: 'var(--gb-ink)',
          }}
        />
        {query && (
          <button
            type="button"
            onClick={() => setQuery('')}
            className="absolute top-1/2 right-3 -translate-y-1/2 rounded-full p-1 hover:opacity-75"
            style={{ color: 'var(--gb-muted)' }}
            aria-label="Очистить поиск"
          >
            <X className="h-4 w-4" />
          </button>
        )}
      </div>

      {/* Soul Need / Theological Filter Pills */}
      <div className="mt-5 flex flex-wrap items-center justify-center gap-2">
        {(Object.keys(SOUL_NEED_LABELS) as Array<SoulNeed | 'all'>).map((key) => {
          const isSelected = activeNeed === key;
          return (
            <button
              key={key}
              type="button"
              onClick={() => setActiveNeed(key)}
              aria-pressed={isSelected}
              className="font-ui cursor-pointer rounded-full border px-3.5 py-1.5 text-xs font-medium transition-all"
              style={{
                backgroundColor: isSelected ? 'var(--gb-accent)' : 'var(--gb-bg)',
                borderColor: isSelected ? 'var(--gb-accent)' : 'var(--gb-border-strong)',
                color: isSelected ? '#ffffff' : 'var(--gb-ink-secondary)',
              }}
            >
              {SOUL_NEED_LABELS[key].label}
            </button>
          );
        })}
      </div>

      <p
        className="font-ui mt-3 text-center text-xs italic"
        style={{ color: 'var(--gb-muted)' }}
        aria-live="polite"
      >
        {SOUL_NEED_LABELS[activeNeed].description} — найдено: {filtered.length} · изучено вами: {studiedIds.size} из {names.length}
        {query.trim() && filtered.length > 0 && <> · Enter откроет первое</>}
      </p>

      {/* Grid of Interactive Mini Sacred Plaques */}
      {filtered.length === 0 ? (
        <div
          className="mt-8 rounded-2xl border p-8 text-center"
          style={{ borderColor: 'var(--gb-border)', backgroundColor: 'var(--gb-bg)' }}
        >
          <p className="font-body-editorial text-base" style={{ color: 'var(--gb-muted)' }}>
            {query.trim()
              ? <>По запросу «{query}» имён не найдено{activeNeed !== 'all' ? ' в выбранной теме' : ''}.</>
              : <>В теме «{SOUL_NEED_LABELS[activeNeed].label}» пока нет имён.</>}
          </p>
          <div className="mt-4 flex flex-wrap justify-center gap-2">
            {query.trim() && (
              <button
                type="button"
                onClick={() => setQuery('')}
                className="font-ui cursor-pointer rounded-full border px-3.5 py-1.5 text-xs font-medium"
                style={{ borderColor: 'var(--gb-border-strong)', color: 'var(--gb-ink)' }}
              >
                Очистить запрос
              </button>
            )}
            {activeNeed !== 'all' && (
              <button
                type="button"
                onClick={() => setActiveNeed('all')}
                className="font-ui cursor-pointer rounded-full px-3.5 py-1.5 text-xs font-semibold text-white"
                style={{ backgroundColor: 'var(--gb-accent)' }}
              >
                Показать все 36 имён
              </button>
            )}
          </div>
        </div>
      ) : (
        <div className="mt-7 grid grid-cols-1 gap-3.5 sm:grid-cols-2">
          {filtered.map((item) => {
            const isRevealed = revealedIds.has(item.id);
            const isStudied = studiedIds.has(item.id);
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => onSelectName(item)}
                className="group relative flex cursor-pointer flex-col justify-between rounded-2xl border p-4 text-left transition-all duration-300 hover:-translate-y-0.5 hover:shadow-lg"
                style={{
                  backgroundColor: 'var(--gb-bg)',
                  borderColor: isRevealed ? 'var(--gb-border-strong)' : 'var(--gb-border)',
                }}
              >
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <div className="flex items-center gap-2">
                      <span
                        className="font-ui text-[10px] font-bold tracking-wider uppercase"
                        style={{ color: 'var(--gb-gold)' }}
                      >
                        № {item.number}
                      </span>
                      <span
                        className="font-ui rounded px-1.5 py-0.5 text-[10px] font-mono"
                        style={{
                          backgroundColor: 'var(--gb-surface)',
                          color: 'var(--gb-muted)',
                        }}
                      >
                        {item.strongs}
                      </span>
                      {isStudied && (
                        <span
                          className="inline-flex items-center gap-0.5 font-ui text-[10px] font-semibold text-emerald-600"
                          title="Изучено"
                        >
                          <CheckCircle2 className="h-3 w-3" />
                        </span>
                      )}
                    </div>
                    <h4
                      className="font-serif-display mt-1 text-base font-bold transition-colors group-hover:opacity-90"
                      style={{ color: 'var(--gb-ink)' }}
                    >
                      {item.transliteration}
                    </h4>
                    <div className="font-ui text-xs font-medium" style={{ color: 'var(--gb-accent)' }}>
                      {item.russianName}
                    </div>
                  </div>

                  <span
                    lang={item.language === 'greek' ? 'el' : 'he'}
                    dir={item.language === 'greek' ? 'ltr' : 'rtl'}
                    className={`${
                      item.language === 'greek' ? 'font-greek' : 'font-hebrew'
                    } text-xl sm:text-2xl font-bold shrink-0`}
                    style={{ color: 'var(--gb-ink)' }}
                  >
                    {item.original}
                  </span>
                </div>

                <div
                  className="font-ui mt-3 flex items-center justify-between border-t pt-2 text-[11px]"
                  style={{ borderColor: 'var(--gb-border)', color: 'var(--gb-muted)' }}
                >
                  <span>{item.keyVerses[0]?.ref}</span>
                  <span
                    className="inline-flex items-center gap-1 font-semibold transition-transform group-hover:translate-x-0.5"
                    style={{ color: 'var(--gb-accent)' }}
                  >
                    <BookOpen className="h-3 w-3" />
                    Разбор →
                  </span>
                </div>
              </button>
            );
          })}
        </div>
      )}
    </section>
  );
};
