import React, { useEffect, useRef, useState } from 'react';
import { BookOpen, Sparkles, Compass, ArrowDown, ChevronLeft, ChevronRight } from 'lucide-react';

interface SacredAstrolabeHeroProps {
  theme: 'light' | 'sepia' | 'dark';
  onStartReading: () => void;
  onOpenAtlas: () => void;
  onSelectGlyphName: (nameId: string) => void;
}

const SACRED_GLYPHS = [
  { id: 'yhwh', script: 'יְהוָה', label: 'Яхве — Сущий', lang: 'he' },
  { id: 'elohim', script: 'אֱלֹהִים', label: 'Элохим — Творец', lang: 'he' },
  { id: 'el-shaddai', script: 'אֵל שַׁדַּי', label: 'Эль-Шаддай — Всемогущий', lang: 'he' },
  { id: 'immanuel', script: 'עִמָּנוּאֵל', label: 'Иммануэль — С нами Бог', lang: 'he' },
  { id: 'abba-ho-pater', script: 'ὁ Λόγος', label: 'Логос — Слово Божие', lang: 'el' },
];

export const SacredAstrolabeHero: React.FC<SacredAstrolabeHeroProps> = ({
  theme,
  onStartReading,
  onOpenAtlas,
  onSelectGlyphName,
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const pointerRef = useRef({ x: 0, y: 0, targetX: 0, targetY: 0 });
  const [glyphIndex, setGlyphIndex] = useState(0);
  const [medallionTilt, setMedallionTilt] = useState({ rx: 0, ry: 0 });
  const [carouselPaused, setCarouselPaused] = useState(false);

  // Auto-rotate the sacred glyphs, but pause while the reader hovers/focuses the medallion,
  // when the tab is hidden, and never auto-animate for users who prefer reduced motion.
  useEffect(() => {
    const reduceMotion =
      typeof window !== 'undefined' &&
      window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    if (reduceMotion || carouselPaused) return;

    const interval = window.setInterval(() => {
      if (document.hidden) return;
      setGlyphIndex((prev) => (prev + 1) % SACRED_GLYPHS.length);
    }, 4200);
    return () => window.clearInterval(interval);
  }, [carouselPaused]);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animationFrameId = 0;
    let width = 0;
    let height = 0;
    const dpr = Math.min(window.devicePixelRatio || 1, 2);

    const resize = () => {
      const rect = canvas.getBoundingClientRect();
      width = rect.width;
      height = rect.height;
      canvas.width = Math.max(1, Math.floor(width * dpr));
      canvas.height = Math.max(1, Math.floor(height * dpr));
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    };

    resize();
    window.addEventListener('resize', resize);

    // The hero grows/shrinks with the reader font scale and with content reflow,
    // so observe the element itself — otherwise the backing store goes stale and
    // the astrolabe renders blurry after an "А+" press.
    const resizeObserver =
      typeof ResizeObserver !== 'undefined' ? new ResizeObserver(resize) : null;
    resizeObserver?.observe(canvas);

    // Golden dust particles in 3D space
    const particles = Array.from({ length: 68 }, (_, i) => {
      const angle = (i / 68) * Math.PI * 2;
      const radius = 110 + (i % 7) * 34;
      return {
        x: Math.cos(angle) * radius,
        y: ((i * 37) % 280) - 140,
        z: Math.sin(angle) * radius,
        size: 1.1 + (i % 3) * 0.75,
        speed: 0.002 + (i % 5) * 0.0007,
        phase: i * 0.5,
      };
    });

    const project3D = (x: number, y: number, z: number, cx: number, cy: number, fov = 560) => {
      const scale = fov / (fov + z);
      return {
        px: cx + x * scale,
        py: cy + y * scale,
        scale,
      };
    };

    const rotatePoint = (
      x: number,
      y: number,
      z: number,
      ax: number,
      ay: number,
      az: number
    ) => {
      // Rotate X
      const cosX = Math.cos(ax);
      const sinX = Math.sin(ax);
      const y1 = y * cosX - z * sinX;
      const z1 = y * sinX + z * cosX;

      // Rotate Y
      const cosY = Math.cos(ay);
      const sinY = Math.sin(ay);
      const x2 = x * cosY + z1 * sinY;
      const z2 = -x * sinY + z1 * cosY;

      // Rotate Z
      const cosZ = Math.cos(az);
      const sinZ = Math.sin(az);
      const x3 = x2 * cosZ - y1 * sinZ;
      const y3 = x2 * sinZ + y1 * cosZ;

      return { x: x3, y: y3, z: z2 };
    };

    let t = 0;
    let isVisible = true;
    let isPageVisible = !document.hidden;
    let render: () => void;

    const restartAnimation = () => {
      window.cancelAnimationFrame(animationFrameId);
      if (isVisible && isPageVisible) {
        animationFrameId = window.requestAnimationFrame(render);
      }
    };

    const handleVisibility = () => {
      isPageVisible = !document.hidden;
      restartAnimation();
    };

    const observer =
      typeof IntersectionObserver !== 'undefined'
        ? new IntersectionObserver(
            (entries) => {
              isVisible = entries[0]?.isIntersecting ?? true;
              restartAnimation();
            },
            { threshold: 0.02 }
          )
        : null;
    if (observer) observer.observe(canvas);
    document.addEventListener('visibilitychange', handleVisibility);

    render = () => {
      if (!isVisible || !isPageVisible) {
        return;
      }
      t += 0.006;
      const p = pointerRef.current;
      p.x += (p.targetX - p.x) * 0.06;
      p.y += (p.targetY - p.y) * 0.06;

      ctx.clearRect(0, 0, width, height);

      const cx = width * 0.5;
      const cy = height * 0.43;
      const baseRadius = Math.min(width * 0.36, 250);

      const isDark = theme === 'dark';
      const goldRGB = isDark ? '212, 165, 116' : '168, 124, 72';
      const crimsonRGB = isDark ? '217, 122, 108' : '124, 45, 45';

      // Soft radial celestial halo
      const halo = ctx.createRadialGradient(cx, cy, 10, cx, cy, baseRadius * 1.45);
      halo.addColorStop(0, `rgba(${goldRGB}, ${isDark ? 0.16 : 0.14})`);
      halo.addColorStop(0.5, `rgba(${crimsonRGB}, ${isDark ? 0.07 : 0.05})`);
      halo.addColorStop(1, 'rgba(0,0,0,0)');
      ctx.fillStyle = halo;
      ctx.fillRect(0, 0, width, height);

      // Draw 3D interlocking sacred astrolabe rings
      const rings = [
        { r: baseRadius * 1.04, ax: 1.15 + p.y * 0.35, ay: t * 0.45 + p.x * 0.4, az: t * 0.2, color: goldRGB, alpha: isDark ? 0.38 : 0.3, width: 1.25, ticks: 24 },
        { r: baseRadius * 0.86, ax: -0.85 + p.y * 0.25, ay: -t * 0.55 + p.x * 0.35, az: -t * 0.15, color: crimsonRGB, alpha: isDark ? 0.36 : 0.26, width: 1.1, ticks: 12 },
        { r: baseRadius * 0.68, ax: 0.45 + p.y * 0.45, ay: t * 0.7 + p.x * 0.5, az: t * 0.3, color: goldRGB, alpha: isDark ? 0.48 : 0.36, width: 1.35, ticks: 7 },
      ];

      rings.forEach((ring) => {
        const segments = 96;
        ctx.beginPath();
        for (let s = 0; s <= segments; s++) {
          const theta = (s / segments) * Math.PI * 2;
          const lx = Math.cos(theta) * ring.r;
          const ly = Math.sin(theta) * ring.r;
          const rotated = rotatePoint(lx, ly, 0, ring.ax, ring.ay, ring.az);
          const proj = project3D(rotated.x, rotated.y, rotated.z, cx, cy);
          if (s === 0) ctx.moveTo(proj.px, proj.py);
          else ctx.lineTo(proj.px, proj.py);
        }
        ctx.strokeStyle = `rgba(${ring.color}, ${ring.alpha})`;
        ctx.lineWidth = ring.width;
        ctx.stroke();

        // Sacred degree nodes around the ring
        for (let k = 0; k < ring.ticks; k++) {
          const theta = (k / ring.ticks) * Math.PI * 2;
          const lx = Math.cos(theta) * ring.r;
          const ly = Math.sin(theta) * ring.r;
          const rotated = rotatePoint(lx, ly, 0, ring.ax, ring.ay, ring.az);
          const proj = project3D(rotated.x, rotated.y, rotated.z, cx, cy);
          const depthAlpha = Math.max(0.12, Math.min(0.85, (260 - rotated.z) / 420));
          ctx.beginPath();
          ctx.arc(proj.px, proj.py, k % 2 === 0 ? 2.1 * proj.scale : 1.3 * proj.scale, 0, Math.PI * 2);
          ctx.fillStyle = `rgba(${ring.color}, ${depthAlpha * ring.alpha * 1.9})`;
          ctx.fill();
        }
      });

      // 3D Sacred Octahedron Wireframe Core
      const octR = baseRadius * 0.44;
      const octVerts = [
        { x: 0, y: -octR, z: 0 },
        { x: octR, y: 0, z: 0 },
        { x: 0, y: 0, z: octR },
        { x: -octR, y: 0, z: 0 },
        { x: 0, y: 0, z: -octR },
        { x: 0, y: octR, z: 0 },
      ].map((v) => {
        const rot = rotatePoint(v.x, v.y, v.z, t * 0.35 + p.y * 0.4, t * 0.5 + p.x * 0.4, 0.25);
        return project3D(rot.x, rot.y, rot.z, cx, cy);
      });

      const octEdges = [
        [0, 1], [0, 2], [0, 3], [0, 4],
        [5, 1], [5, 2], [5, 3], [5, 4],
        [1, 2], [2, 3], [3, 4], [4, 1],
      ];
      ctx.beginPath();
      octEdges.forEach(([a, b]) => {
        ctx.moveTo(octVerts[a].px, octVerts[a].py);
        ctx.lineTo(octVerts[b].px, octVerts[b].py);
      });
      ctx.strokeStyle = `rgba(${goldRGB}, ${isDark ? 0.22 : 0.16})`;
      ctx.lineWidth = 0.9;
      ctx.stroke();

      // Drifting 3D light motes
      particles.forEach((pt, idx) => {
        const angle = t * (0.4 + (idx % 4) * 0.12) + pt.phase;
        const rx = pt.x * Math.cos(angle) - pt.z * Math.sin(angle);
        const rz = pt.x * Math.sin(angle) + pt.z * Math.cos(angle);
        const ry = pt.y + Math.sin(t * 1.4 + pt.phase) * 14;
        const rotated = rotatePoint(rx, ry, rz, p.y * 0.25, p.x * 0.25, 0);
        const proj = project3D(rotated.x, rotated.y, rotated.z, cx, cy);
        const alpha = Math.max(0.1, Math.min(0.75, (280 - rotated.z) / 480));
        ctx.beginPath();
        ctx.arc(proj.px, proj.py, pt.size * proj.scale, 0, Math.PI * 2);
        ctx.fillStyle = `rgba(${idx % 3 === 0 ? crimsonRGB : goldRGB}, ${alpha * 0.65})`;
        ctx.fill();
      });

      animationFrameId = window.requestAnimationFrame(render);
    };

    animationFrameId = window.requestAnimationFrame(render);

    return () => {
      window.cancelAnimationFrame(animationFrameId);
      window.removeEventListener('resize', resize);
      document.removeEventListener('visibilitychange', handleVisibility);
      if (observer) observer.disconnect();
      resizeObserver?.disconnect();
    };
  }, [theme]);

  const handleMouseMove = (e: React.MouseEvent<HTMLElement>) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const nx = ((e.clientX - rect.left) / rect.width - 0.5) * 2;
    const ny = ((e.clientY - rect.top) / rect.height - 0.5) * 2;
    pointerRef.current.targetX = nx;
    pointerRef.current.targetY = ny;
    setMedallionTilt({ rx: -ny * 11, ry: nx * 13 });
  };

  const handleMouseLeave = () => {
    pointerRef.current.targetX = 0;
    pointerRef.current.targetY = 0;
    setMedallionTilt({ rx: 0, ry: 0 });
  };

  const activeGlyph = SACRED_GLYPHS[glyphIndex];

  return (
    <header
      onMouseMove={handleMouseMove}
      onMouseLeave={handleMouseLeave}
      className="print-hero relative overflow-hidden border-b pt-24 pb-16 md:pt-28 md:pb-24"
      style={{
        borderColor: 'var(--gb-border)',
        background:
          theme === 'dark'
            ? 'radial-gradient(ellipse at 50% 25%, #1d1915 0%, #0e1116 72%)'
            : theme === 'sepia'
              ? 'radial-gradient(ellipse at 50% 25%, #f9f1e2 0%, #efe5d4 75%)'
              : 'radial-gradient(ellipse at 50% 25%, #ffffff 0%, #f8f5f0 75%)',
      }}
    >
      {/* Interactive 3D Sacred Astrolabe Canvas */}
      <canvas
        ref={canvasRef}
        aria-hidden="true"
        className="pointer-events-none absolute inset-0 h-full w-full"
      />

      <div className="relative z-10 mx-auto max-w-4xl px-5 sm:px-8 text-center">
        {/* Eyebrow */}
        <div
          className="font-ui mb-6 inline-flex items-center gap-2 rounded-full border px-4 py-1.5 text-xs font-medium tracking-wider uppercase"
          style={{
            borderColor: 'var(--gb-border-strong)',
            backgroundColor: 'var(--gb-glass)',
            color: 'var(--gb-accent)',
            backdropFilter: 'blur(12px)',
          }}
        >
          <Sparkles className="h-3.5 w-3.5" style={{ color: 'var(--gb-gold)' }} />
          <span>Экзегеза и богословие · Большое исследование</span>
        </div>

        {/* Interactive 3D Tilting Sacred Medallion with Manual Glyph Switcher */}
        <div
          className="mb-8 flex items-center justify-center gap-3"
          style={{ perspective: '900px' }}
          onMouseEnter={() => setCarouselPaused(true)}
          onMouseLeave={() => setCarouselPaused(false)}
          onFocus={() => setCarouselPaused(true)}
          onBlur={(e) => {
            if (!e.currentTarget.contains(e.relatedTarget as Node | null)) {
              setCarouselPaused(false);
            }
          }}
          role="group"
          aria-roledescription="карусель"
          aria-label="Священные имена: выберите, чтобы открыть разбор"
        >
          <button
            type="button"
            onClick={() =>
              setGlyphIndex((prev) => (prev - 1 + SACRED_GLYPHS.length) % SACRED_GLYPHS.length)
            }
            aria-label="Предыдущее священное имя"
            className="cursor-pointer rounded-full border p-2 transition-all hover:scale-110"
            style={{
              backgroundColor: 'var(--gb-glass)',
              borderColor: 'var(--gb-border-strong)',
              color: 'var(--gb-gold)',
              backdropFilter: 'blur(10px)',
            }}
          >
            <ChevronLeft className="h-4 w-4" />
          </button>

          <button
            type="button"
            onClick={() => onSelectGlyphName(activeGlyph.id)}
            title="Нажмите, чтобы открыть глубокий разбор этого Имени"
            className="group relative min-w-[230px] sm:min-w-[270px] cursor-pointer rounded-2xl border px-8 py-5 transition-shadow duration-500"
            style={{
              transform: `rotateX(${medallionTilt.rx}deg) rotateY(${medallionTilt.ry}deg)`,
              transformStyle: 'preserve-3d',
              transition: 'transform 160ms ease-out, box-shadow 400ms ease',
              backgroundColor: 'var(--gb-glass)',
              borderColor: 'var(--gb-gold)',
              boxShadow: '0 16px 44px var(--gb-gold-glow), inset 0 0 24px rgba(184, 147, 106, 0.14)',
              backdropFilter: 'blur(16px)',
            }}
          >
            {/* Inner double sacred border */}
            <div
              className="pointer-events-none absolute inset-1.5 rounded-xl border opacity-45"
              style={{ borderColor: 'var(--gb-gold)' }}
            />
            <div className="relative z-10 flex flex-col items-center">
              <span
                className={`${activeGlyph.lang === 'el' ? 'font-greek' : 'font-hebrew'} text-4xl sm:text-5xl font-bold tracking-wide transition-all duration-700`}
                style={{
                  color: 'var(--gb-ink)',
                  textShadow: '0 0 24px var(--gb-gold-glow)',
                }}
              >
                {activeGlyph.script}
              </span>
              <span
                className="font-ui mt-2 text-[11px] font-medium tracking-widest uppercase transition-colors"
                style={{ color: 'var(--gb-gold)' }}
                aria-live="polite"
              >
                {activeGlyph.label}
              </span>
              <span className="mt-2 flex items-center gap-1" aria-hidden="true">
                {SACRED_GLYPHS.map((g, i) => (
                  <span
                    key={g.id}
                    className="h-1 rounded-full transition-all duration-500"
                    style={{
                      width: i === glyphIndex ? 14 : 5,
                      backgroundColor: i === glyphIndex ? 'var(--gb-accent)' : 'var(--gb-border-strong)',
                    }}
                  />
                ))}
              </span>
            </div>
          </button>

          <button
            type="button"
            onClick={() => setGlyphIndex((prev) => (prev + 1) % SACRED_GLYPHS.length)}
            aria-label="Следующее священное имя"
            className="cursor-pointer rounded-full border p-2 transition-all hover:scale-110"
            style={{
              backgroundColor: 'var(--gb-glass)',
              borderColor: 'var(--gb-border-strong)',
              color: 'var(--gb-gold)',
              backdropFilter: 'blur(10px)',
            }}
          >
            <ChevronRight className="h-4 w-4" />
          </button>
        </div>

        {/* Main Editorial Title */}
        <h1
          className="font-serif-display mx-auto max-w-3xl text-3xl sm:text-5xl md:text-[3.35rem] font-bold leading-[1.14] tracking-tight"
          style={{ color: 'var(--gb-ink)' }}
        >
          Имена Бога в Писании:{' '}
          <span className="italic font-semibold" style={{ color: 'var(--gb-accent)' }}>
            как Творец открывает Своё сердце
          </span>{' '}
          в завете, истории и Христе
        </h1>

        {/* Lead Subtitle */}
        <p
          className="font-body-editorial mx-auto mt-6 max-w-2xl text-base sm:text-lg md:text-xl leading-relaxed"
          style={{ color: 'var(--gb-ink-secondary)' }}
        >
          В Библии имя Бога — не условный ярлык и не магическая формула, а самооткровение Его
          характера, святости и верности. По мере чтения ниже по бокам страницы будут последовательно
          являться и озаряться все 36 канонических имён Всевышнего — нажмите на любое, чтобы
          открыть лексический и богословский разбор.
        </p>

        {/* Editorial Meta Strip */}
        <div
          className="font-ui mt-8 flex flex-wrap items-center justify-center gap-x-5 gap-y-2 text-xs"
          style={{ color: 'var(--gb-muted)' }}
        >
          <span>
            Автор-редактор: <strong style={{ color: 'var(--gb-ink)' }}>Фёдор Милованов</strong>
          </span>
          <span aria-hidden="true">·</span>
          <span>36 имён (иврит, арамейский, греческий)</span>
          <span aria-hidden="true">·</span>
          <span>~48 мин вдумчивого чтения</span>
          <span aria-hidden="true">·</span>
          <span>Сверка по BDB / HALOT / BDAG</span>
        </div>

        {/* Action Buttons */}
        <div className="mt-9 flex flex-wrap items-center justify-center gap-3.5">
          <button
            type="button"
            onClick={onStartReading}
            className="font-ui inline-flex cursor-pointer items-center gap-2.5 rounded-xl px-6 py-3 text-sm font-semibold text-white shadow-md transition-all hover:opacity-95 active:scale-[0.99]"
            style={{
              backgroundColor: 'var(--gb-accent)',
              boxShadow: '0 8px 24px var(--gb-crimson-glow)',
            }}
          >
            <BookOpen className="h-4 w-4" />
            <span>Начать последовательное чтение</span>
            <ArrowDown className="h-4 w-4 opacity-80" />
          </button>

          <button
            type="button"
            onClick={onOpenAtlas}
            className="font-ui inline-flex cursor-pointer items-center gap-2 rounded-xl border px-5 py-3 text-sm font-medium transition-all hover:border-amber-600/50"
            style={{
              backgroundColor: 'var(--gb-glass)',
              borderColor: 'var(--gb-border-strong)',
              color: 'var(--gb-ink)',
              backdropFilter: 'blur(12px)',
            }}
          >
            <Compass className="h-4 w-4" style={{ color: 'var(--gb-gold)' }} />
            <span>Созвездие всех 36 имён</span>
          </button>
        </div>

        {/* Scripture Motto Anchor */}
        <blockquote
          className="font-quote-editorial mx-auto mt-10 max-w-xl border-t pt-5 text-lg sm:text-xl italic"
          style={{
            borderColor: 'var(--gb-border)',
            color: 'var(--gb-muted)',
          }}
        >
          «И будут уповать на Тебя знающие имя Твоё, потому что Ты не оставляешь ищущих Тебя, Господи».
          <footer className="font-ui mt-1 text-xs not-italic tracking-wide" style={{ color: 'var(--gb-accent)' }}>
            — Псалом 9:11 (Синодальный перевод)
          </footer>
        </blockquote>
      </div>
    </header>
  );
};
