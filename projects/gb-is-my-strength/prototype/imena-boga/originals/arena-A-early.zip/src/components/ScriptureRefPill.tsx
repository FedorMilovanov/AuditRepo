import React, { useEffect, useId, useRef, useState } from 'react';
import { BookOpen, X } from 'lucide-react';

interface ScriptureRefPillProps {
  reference: string;
  synodalText: string;
  originalNote?: string;
}

export const ScriptureRefPill: React.FC<ScriptureRefPillProps> = ({
  reference,
  synodalText,
  originalNote,
}) => {
  const [open, setOpen] = useState(false);
  const wrapperRef = useRef<HTMLSpanElement | null>(null);
  const closeRef = useRef<HTMLButtonElement | null>(null);
  const panelId = useId();

  useEffect(() => {
    if (!open) return;

    const handleOutside = (e: MouseEvent | TouchEvent) => {
      if (wrapperRef.current && !wrapperRef.current.contains(e.target as Node)) {
        setOpen(false);
      }
    };
    const handleEsc = (e: KeyboardEvent) => {
      if (e.key === 'Escape') setOpen(false);
    };

    document.addEventListener('mousedown', handleOutside);
    document.addEventListener('touchstart', handleOutside, { passive: true });
    document.addEventListener('keydown', handleEsc);

    // Move focus into the sheet so keyboard and screen-reader users land on it
    const focusTimer = window.setTimeout(() => closeRef.current?.focus(), 30);

    return () => {
      document.removeEventListener('mousedown', handleOutside);
      document.removeEventListener('touchstart', handleOutside);
      document.removeEventListener('keydown', handleEsc);
      window.clearTimeout(focusTimer);
    };
  }, [open]);

  return (
    <span ref={wrapperRef} className="relative inline-block">
      <button
        type="button"
        onClick={() => setOpen((v) => !v)}
        aria-expanded={open}
        aria-controls={panelId}
        className="font-ui inline-flex cursor-pointer items-center gap-1 rounded-md border px-1.5 py-0.5 text-[0.82em] font-semibold transition-colors hover:opacity-85"
        style={{
          backgroundColor: 'var(--gb-accent-soft)',
          borderColor: open ? 'var(--gb-gold)' : 'var(--gb-border-strong)',
          color: 'var(--gb-accent)',
        }}
        title={`Открыть текст Писания: ${reference}`}
      >
        <BookOpen className="h-3 w-3 shrink-0" style={{ color: 'var(--gb-gold)' }} />
        <span>{reference}</span>
      </button>

      {open && (
        <>
          {/* Mobile: dim the page so the sheet clearly owns the screen and never
              collides with the floating reading controls underneath it. */}
          <span
            aria-hidden="true"
            onClick={() => setOpen(false)}
            className="fixed inset-0 z-50 block cursor-default bg-black/45 backdrop-blur-[2px] sm:hidden"
          />

          <span
            id={panelId}
            role="dialog"
            aria-modal="false"
            aria-label={`Текст Писания: ${reference}`}
            className="fixed right-3 bottom-3 left-3 z-[60] block rounded-2xl border p-4 text-left shadow-2xl sm:absolute sm:right-auto sm:bottom-full sm:left-0 sm:z-50 sm:mb-2 sm:w-[340px]"
            style={{
              backgroundColor: 'var(--gb-surface)',
              borderColor: 'var(--gb-gold)',
              boxShadow: 'var(--gb-shadow-xl)',
            }}
          >
            <span
              className="flex items-center justify-between gap-2 border-b pb-2"
              style={{ borderColor: 'var(--gb-border)' }}
            >
              <span className="font-ui text-xs font-bold" style={{ color: 'var(--gb-accent)' }}>
                {reference} · Синодальный перевод
              </span>
              <button
                ref={closeRef}
                type="button"
                onClick={() => setOpen(false)}
                className="cursor-pointer rounded-full p-1 transition-opacity hover:opacity-75"
                style={{ color: 'var(--gb-muted)' }}
                aria-label="Закрыть стих"
              >
                <X className="h-3.5 w-3.5" />
              </button>
            </span>

            <span
              className="font-quote-editorial mt-2 block text-base italic leading-relaxed"
              style={{ color: 'var(--gb-ink)' }}
            >
              «{synodalText}»
            </span>

            {originalNote && (
              <span
                className="font-ui mt-2 block rounded-lg px-2.5 py-1.5 text-[0.75em]"
                style={{ backgroundColor: 'var(--gb-bg)', color: 'var(--gb-muted)' }}
              >
                {originalNote}
              </span>
            )}
          </span>
        </>
      )}
    </span>
  );
};
