import { useCallback, useEffect, useState, type ReactNode } from "react";
import { AnimatePresence, motion, useScroll, useSpring } from "framer-motion";
import Hero from "./components/Hero";
import Intro from "./components/Intro";
import PartDivider from "./components/PartDivider";
import NameSection from "./components/NameSection";
import Rails from "./components/Rails";
import Epilogue from "./components/Epilogue";
import MobileIndex from "./components/MobileIndex";
import NameGrid from "./components/NameGrid";
import BackToTop from "./components/BackToTop";
import ReaderControls from "./components/ReaderControls";
import { NAMES, PARTS } from "./data/names";
import { consumeSkipHashReplace, navigateToName, readHashId, spyLocked, syncHash } from "./utils/navigate";
import CursorGlow from "./components/CursorGlow";
import KeyboardHelp from "./components/KeyboardHelp";
import Toast from "./components/Toast";

const VISITED_KEY = "gb-names-visited";
const READING_KEY = "gb-names-reading";

function loadVisited(): Set<string> {
  try {
    const raw = sessionStorage.getItem(VISITED_KEY);
    if (!raw) return new Set();
    const arr = JSON.parse(raw) as string[];
    return new Set(arr.filter((id) => NAMES.some((n) => n.id === id)));
  } catch {
    return new Set();
  }
}

function loadReading(): number {
  try {
    const v = Number(localStorage.getItem(READING_KEY));
    return v === 0 || v === 2 ? v : 1;
  } catch {
    return 1;
  }
}

export default function App() {
  const [active, setActive] = useState<string>("");
  const [scrolled, setScrolled] = useState(false);
  const [inArticle, setInArticle] = useState(false);
  const [visited, setVisited] = useState<Set<string>>(loadVisited);
  const [reading, setReading] = useState<number>(loadReading);
  const { scrollYProgress } = useScroll();
  const progress = useSpring(scrollYProgress, { stiffness: 90, damping: 24, mass: 0.4 });

  const activeIdx = NAMES.findIndex((n) => n.id === active);
  const activeName = activeIdx >= 0 ? NAMES[activeIdx] : null;
  const pageTitle = "Имена Бога — Господь Бог — Сила Моя";

  useEffect(() => {
    document.title = activeName ? `${activeName.translit} — ${pageTitle}` : pageTitle;
  }, [activeName, pageTitle]);

  // Persist reading size.
  useEffect(() => {
    try {
      localStorage.setItem(READING_KEY, String(reading));
    } catch {
      /* private mode */
    }
  }, [reading]);

  // Mark names as read while they hold the reading position.
  useEffect(() => {
    if (!active) return;
    setVisited((prev) => {
      if (prev.has(active)) return prev;
      const next = new Set(prev);
      next.add(active);
      try {
        sessionStorage.setItem(VISITED_KEY, JSON.stringify([...next]));
      } catch {
        /* private mode */
      }
      return next;
    });
  }, [active]);

  // Keep the URL hash in sync with the name being read, without extra history.
  useEffect(() => {
    if (!active) return;
    if (consumeSkipHashReplace()) return;
    syncHash(active);
  }, [active]);

  const resetVisited = useCallback(() => {
    setVisited(new Set());
    try {
      sessionStorage.removeItem(VISITED_KEY);
    } catch {
      /* private mode */
    }
  }, []);

  // Scroll spy: one viewport marker; long sections and fast scrolls resolve consistently.
  useEffect(() => {
    const sections = NAMES.map((n) => document.getElementById(n.id)).filter(
      (el): el is HTMLElement => !!el,
    );
    let frame = 0;
    const onScroll = () => {
      if (frame) return;
      frame = requestAnimationFrame(() => {
        frame = 0;
        setScrolled(window.scrollY > 60);
        setInArticle(window.scrollY > window.innerHeight * 0.8);
        if (spyLocked()) return;
        const marker = window.innerHeight * 0.44;
        const current = sections.find((section) => {
          const rect = section.getBoundingClientRect();
          return rect.top <= marker && rect.bottom > marker;
        });
        if (current) {
          setActive(current.id);
        } else if (sections[0] && sections[0].getBoundingClientRect().top > marker) {
          // Above the first name (intro / constellation): nothing is "current".
          setActive("");
        }
      });
    };
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    window.addEventListener("resize", onScroll);
    return () => {
      cancelAnimationFrame(frame);
      window.removeEventListener("scroll", onScroll);
      window.removeEventListener("resize", onScroll);
    };
  }, []);

  // Deep links: initial hash, browser Back/Forward, and re-align after webfonts load.
  useEffect(() => {
    let cancelled = false;
    let interacted = false;
    const markInteracted = () => {
      interacted = true;
    };
    const follow = () => {
      const id = readHashId();
      if (!id) return;
      if (id === "intro" || id === "sozvezdie") {
        document.getElementById(id)?.scrollIntoView({ behavior: "instant", block: "start" });
        return;
      }
      if (!NAMES.some((n) => n.id === id)) return;
      navigateToName(id, { push: false, instant: true });
      setActive(id);
    };
    const timer = window.setTimeout(follow, 120);
    if (document.fonts?.ready) {
      document.fonts.ready.then(() => {
        if (!cancelled && !interacted && readHashId()) follow();
      });
    }
    window.addEventListener("hashchange", follow);
    window.addEventListener("popstate", follow);
    window.addEventListener("wheel", markInteracted, { passive: true });
    window.addEventListener("touchstart", markInteracted, { passive: true });
    window.addEventListener("keydown", markInteracted);
    return () => {
      cancelled = true;
      window.clearTimeout(timer);
      window.removeEventListener("hashchange", follow);
      window.removeEventListener("popstate", follow);
      window.removeEventListener("wheel", markInteracted);
      window.removeEventListener("touchstart", markInteracted);
      window.removeEventListener("keydown", markInteracted);
    };
  }, []);

  const scrollTo = useCallback((id: string) => {
    setActive(id);
    navigateToName(id);
  }, []);

  // Keyboard: ← / → turn names like pages, "/" opens search.
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const t = e.target as HTMLElement | null;
      if (t && (t.tagName === "INPUT" || t.tagName === "TEXTAREA" || t.isContentEditable)) return;
      if (document.querySelector('[role="dialog"]')) return;
      if (e.key === "/" && !e.shiftKey) {
        e.preventDefault();
        if (window.matchMedia("(min-width: 1680px)").matches) {
          document.getElementById("sozvezdie")?.scrollIntoView({ behavior: "smooth", block: "start" });
        } else {
          window.dispatchEvent(new CustomEvent("open-name-index"));
        }
        return;
      }
      if (e.key !== "ArrowLeft" && e.key !== "ArrowRight") return;
      if (!inArticle) return;
      const idx = NAMES.findIndex((n) => n.id === active);
      if (e.key === "ArrowRight") {
        if (idx === NAMES.length - 1) return;
        e.preventDefault();
        scrollTo(NAMES[Math.max(idx + 1, 0)].id);
      } else {
        if (idx <= 0) return;
        e.preventDefault();
        scrollTo(NAMES[idx - 1].id);
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [active, inArticle, scrollTo]);

  // Name sections interleaved with part dividers.
  let renderedPart = 0;
  const blocks: ReactNode[] = [];
  NAMES.forEach((name, i) => {
    if (renderedPart !== name.part) {
      renderedPart = name.part;
      const part = PARTS[name.part - 1];
      blocks.push(
        <PartDivider
          key={part.id}
          numeral={part.numeral}
          title={part.title}
          desc={part.desc}
          entries={NAMES.filter((n) => n.part === name.part)}
        />,
      );
    }
    blocks.push(<NameSection key={name.id} name={name} index={i} onNavigate={scrollTo} />);
  });

  return (
    <div className="vignette noise relative min-h-screen bg-ink-950 font-body text-cream-100">
      {/* top progress bar */}
      <motion.div
        className="fixed inset-x-0 top-0 z-[60] h-[2.5px] origin-left bg-gradient-to-r from-gold-700 via-gold-400 to-gold-200 shadow-[0_0_12px_rgba(212,175,55,0.6)]"
        style={{ scaleX: progress }}
      />

      {/* header */}
      <motion.header
        initial={{ y: -60, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ duration: 0.9, delay: 0.3, ease: [0.22, 1, 0.36, 1] }}
        className={`fixed inset-x-0 top-0 z-50 transition-all duration-500 ${
          scrolled
            ? "border-b border-gold-500/10 bg-ink-950/85 backdrop-blur-md"
            : "bg-transparent"
        }`}
      >
        <div className="mx-auto flex max-w-7xl items-center justify-between gap-4 px-6 py-4">
          <a
            href="https://gospod-bog.ru"
            className="font-ui text-[10px] font-medium uppercase tracking-[0.35em] text-cream-300 transition-colors hover:text-gold-300"
          >
            Господь Бог — Сила Моя
          </a>

          {/* center: brand mark → current name while reading */}
          <div className="hidden min-w-[160px] justify-center sm:flex">
            <AnimatePresence mode="wait" initial={false}>
              {inArticle && activeName ? (
                <motion.button
                  key="current"
                  type="button"
                  initial={{ opacity: 0, y: 8 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -8 }}
                  transition={{ duration: 0.3 }}
                  onClick={() => scrollTo(activeName.id)}
                  title="К текущему имени"
                  className="flex max-w-[46vw] items-center gap-2.5 font-ui text-[10px] uppercase tracking-[0.3em] text-gold-300 transition-colors hover:text-gold-200"
                >
                  <span className="h-1 w-1 shrink-0 rotate-45 bg-gold-400 shadow-[0_0_8px_rgba(212,175,55,0.8)]" />
                  <span className="truncate">
                    {String(activeIdx + 1).padStart(2, "0")} · {activeName.translit}
                  </span>
                </motion.button>
              ) : (
                <motion.a
                  key="shmot"
                  href="#sozvezdie"
                  initial={{ opacity: 0, y: 8 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -8 }}
                  transition={{ duration: 0.3 }}
                  aria-label="К указателю имён"
                  className="font-hebrew text-sm text-gold-400/90 transition-colors hover:text-gold-300"
                >
                  שְׁמוֹת
                </motion.a>
              )}
            </AnimatePresence>
          </div>

          <a
            href="https://gospod-bog.ru/articles/"
            className="group flex items-center gap-2 font-ui text-[10px] font-medium uppercase tracking-[0.35em] text-cream-500 transition-colors hover:text-gold-300"
          >
            Библиотека
            <span className="h-1 w-1 rotate-45 bg-gold-500 transition-transform duration-300 group-hover:rotate-[135deg]" />
          </a>
        </div>
      </motion.header>

      {/* skip link for keyboard readers */}
      <a
        href="#yhwh"
        className="sr-only focus:not-sr-only focus:fixed focus:left-4 focus:top-4 focus:z-[70] focus:rounded-full focus:border focus:border-gold-500 focus:bg-ink-950 focus:px-6 focus:py-3 focus:font-ui focus:text-xs focus:uppercase focus:tracking-[0.25em] focus:text-gold-300"
      >
        Сразу к ЯХВЕ
      </a>

      <CursorGlow />
      <Hero />
      <Intro />
      <NameGrid
        active={active}
        visited={visited}
        onSelect={scrollTo}
        onResetVisited={resetVisited}
      />

      <Rails active={active} visible={inArticle} onSelect={scrollTo} />
      <MobileIndex active={active} onSelect={scrollTo} visible={inArticle} />
      <BackToTop visible={inArticle} />
      <ReaderControls visible={inArticle} size={reading} onChange={setReading} />
      <KeyboardHelp />
      <Toast />

      <main data-reading={reading}>{blocks}</main>

      <Epilogue />
    </div>
  );
}
