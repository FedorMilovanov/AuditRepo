import { motion, useReducedMotion, useScroll, useTransform } from "framer-motion";
import { ChevronDown } from "lucide-react";
import Starfield from "./Starfield";
import { NAMES } from "../data/names";
import { navigateToName } from "../utils/navigate";

const LETTERS = [
  { ch: "י", name: "Йод" },
  { ch: "ה", name: "Хе" },
  { ch: "ו", name: "Вав" },
  { ch: "ה", name: "Хе" },
];

const RING_A = ["י", "ה", "ו", "ה", "א", "ל", "ש", "ד", "י", "מ", "נ", "ו"];
const RING_B = ["א", "ה", "י", "ה", "צ", "ו", "ר", "ע", "ם", "נ", "ו", "א", "ל", "ש"];

function Ring({
  glyphs,
  radius,
  spin,
  size,
}: {
  glyphs: string[];
  radius: number;
  spin: string;
  size: string;
}) {
  return (
    <div
      className="absolute left-1/2 top-1/2 preserve-3d"
      style={{ transform: "rotateX(66deg)" }}
    >
      <div className={`preserve-3d ${spin}`}>
        {glyphs.map((g, i) => {
          const angle = (360 / glyphs.length) * i;
          return (
            <span
              key={i}
              className={`absolute left-1/2 top-1/2 font-hebrew backface-hidden ${size} font-medium text-gold-400/50`}
              style={{
                transform: `translate(-50%, -50%) rotateY(${angle}deg) translateZ(${radius}px)`,
                textShadow: "0 0 24px rgba(212,175,55,0.5)",
              }}
            >
              {g}
            </span>
          );
        })}
      </div>
    </div>
  );
}

const ease = [0.22, 1, 0.36, 1] as const;

export default function Hero() {
  const reduced = useReducedMotion();
  const { scrollY } = useScroll();
  const bgY = useTransform(scrollY, [0, 900], [0, 110]);
  const bgScale = useTransform(scrollY, [0, 900], [1.05, 1.14]);

  return (
    <section className="hero-screen relative flex h-[100svh] min-h-[640px] items-center justify-center overflow-hidden">
      {/* atmosphere */}
      <motion.div
        aria-hidden
        className="absolute inset-0"
        style={reduced ? undefined : { y: bgY, scale: bgScale }}
      >
        <div className="absolute inset-0 bg-[url('/images/sinai-dawn.jpg')] bg-cover bg-center" />
      </motion.div>
      <div className="absolute inset-0 bg-[linear-gradient(180deg,rgba(6,6,5,.64)_0%,rgba(9,8,6,.48)_42%,rgba(10,9,7,.72)_76%,#0a0907_100%)]" />
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_55%_55%_at_50%_48%,rgba(10,9,7,.52),transparent_100%)]" />
      <div className="absolute inset-0 opacity-70"><Starfield /></div>
      <div className="absolute left-1/2 top-1/2 h-[560px] w-[560px] -translate-x-1/2 -translate-y-1/2 rounded-full bg-gold-500/[0.07] blur-[120px] animate-glow-pulse" />

      {/* A restrained armillary motif frames the title without replacing the landscape. */}
      <div
        className="absolute inset-0 hidden opacity-60 md:block preserve-3d"
        style={{ perspective: "1400px" }}
        aria-hidden
      >
        <Ring glyphs={RING_A} radius={330} spin="animate-rotate-slow" size="text-2xl" />
      </div>
      <div
        className="absolute inset-0 hidden opacity-40 lg:block preserve-3d"
        style={{ perspective: "1400px" }}
        aria-hidden
      >
        <Ring glyphs={RING_B} radius={470} spin="animate-rotate-rev" size="text-xl" />
      </div>

      {/* content */}
      <div className="relative z-10 flex flex-col items-center px-6 text-center">
        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1, delay: 0.2, ease }}
          className="font-ui text-[11px] font-medium uppercase tracking-[0.45em] text-cream-500"
        >
          Господь Бог — Сила Моя · Богословская библиотека
        </motion.p>

        <motion.div
          initial={{ opacity: 0, scale: 0.85, filter: "blur(12px)" }}
          animate={{ opacity: 1, scale: 1, filter: "blur(0px)" }}
          transition={{ duration: 1.4, delay: 0.45, ease }}
          className="mt-6 select-none md:mt-10"
        >
          <div
            dir="rtl"
            role="group"
            aria-label="Тетраграмматон: йод, хе, вав, хе"
            className="glow-gold flex items-end justify-center gap-1 font-hebrew text-6xl font-medium text-gold-300 md:text-7xl"
          >
            {LETTERS.map((l, i) => (
              <motion.button
                key={i}
                type="button"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.7, delay: 0.55 + i * 0.1, ease }}
                onClick={() => navigateToName("yhwh")}
                title={`${l.name} — открыть раздел ЯХВЕ`}
                aria-label={`Буква ${l.name}. Открыть раздел ЯХВЕ`}
                className="group relative leading-none transition-all duration-300 hover:-translate-y-1 hover:text-gold-200 hover:drop-shadow-[0_0_18px_rgba(212,175,55,0.85)] focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-gold-400"
              >
                {l.ch}
                <span
                  dir="ltr"
                  className="pointer-events-none absolute -top-6 left-1/2 -translate-x-1/2 font-ui text-[9px] uppercase tracking-[0.3em] text-gold-400 opacity-0 transition-opacity duration-300 group-hover:opacity-100 group-focus-visible:opacity-100"
                >
                  {l.name}
                </span>
              </motion.button>
            ))}
          </div>
        </motion.div>

        <motion.h1
          initial={{ opacity: 0, y: 34, letterSpacing: "0.3em" }}
          animate={{ opacity: 1, y: 0, letterSpacing: "0.06em" }}
          transition={{ duration: 1.5, delay: 0.75, ease }}
          className="gold-text mt-6 font-display text-[12.5vw] font-semibold leading-[0.95] sm:text-7xl md:text-8xl lg:text-[7.5rem]"
        >
          ИМЕНА БОГА
        </motion.h1>

        <motion.p
          initial={{ opacity: 0, y: 24 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1, delay: 1.15, ease }}
          className="mt-7 max-w-xl font-body text-lg italic leading-relaxed text-cream-300 md:text-xl"
        >
          ЯХВЕ — центральное имя Бога в Писании. От «Я есмь Сущий» у горящего
          куста до «с нами Бог»
        </motion.p>

        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 1.2, delay: 1.5 }}
          className="mt-8 flex flex-wrap items-center justify-center gap-3 font-ui text-[10px] uppercase tracking-[0.25em] text-cream-300 md:mt-12 md:gap-6"
        >
          {[`${NAMES.length} имён и титулов`, "4 части", "Писание и контекст"].map((s, i) => (
            <span key={s} className="flex items-center gap-3 md:gap-6">
              {i > 0 && <span className="h-1 w-1 rotate-45 bg-gold-500/70" />}
              {s}
            </span>
          ))}
        </motion.div>
      </div>

      {/* scroll cue */}
      <motion.a
        href="#intro"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 2, duration: 1 }}
        className="group absolute bottom-8 left-1/2 z-10 flex -translate-x-1/2 flex-col items-center gap-3"
        aria-label="Листайте вниз"
        data-print-hide
      >
        <span className="font-ui text-[10px] uppercase tracking-[0.4em] text-cream-500 transition-colors group-hover:text-gold-300">
          Читать
        </span>
        <span className="relative h-12 w-px overflow-hidden bg-cream-700/40">
          <span className="absolute left-0 top-0 h-5 w-px animate-scroll-cue bg-gold-400" />
        </span>
        <ChevronDown className="h-4 w-4 text-gold-400/80" strokeWidth={1.5} />
      </motion.a>

      {/* bottom fade */}
      <div className="pointer-events-none absolute inset-x-0 bottom-0 h-40 bg-gradient-to-t from-ink-950 to-transparent" />
    </section>
  );
}
