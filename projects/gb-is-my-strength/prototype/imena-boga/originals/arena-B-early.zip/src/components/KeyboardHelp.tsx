import { useEffect, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { X } from "lucide-react";

const ROWS = [
  { keys: ["←", "→"], label: "Листать имена" },
  { keys: ["/"], label: "Поиск по именам" },
  { keys: ["?"], label: "Эта подсказка" },
  { keys: ["Esc"], label: "Закрыть окно" },
];

export default function KeyboardHelp() {
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const t = e.target as HTMLElement | null;
      if (t && (t.tagName === "INPUT" || t.tagName === "TEXTAREA" || t.isContentEditable)) return;
      if (e.key === "?" || (e.key === "/" && e.shiftKey)) {
        e.preventDefault();
        setOpen((v) => !v);
      } else if (e.key === "Escape" && open) {
        setOpen(false);
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [open]);

  useEffect(() => {
    if (!open) return;
    const prev = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => {
      document.body.style.overflow = prev;
    };
  }, [open]);

  return (
    <AnimatePresence>
      {open && (
        <motion.div
          role="dialog"
          aria-modal="true"
          aria-label="Клавиатурные сокращения"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          data-print-hide
          className="fixed inset-0 z-[75] flex items-center justify-center bg-ink-950/80 px-6 backdrop-blur-md"
          onClick={() => setOpen(false)}
        >
          <motion.div
            initial={{ opacity: 0, y: 18, scale: 0.97 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 10, scale: 0.97 }}
            transition={{ duration: 0.4, ease: [0.22, 1, 0.36, 1] }}
            onClick={(e) => e.stopPropagation()}
            className="card-parchment relative w-full max-w-md rounded-2xl border border-gold-500/30 p-8 shadow-[0_30px_80px_-20px_rgba(0,0,0,0.8)]"
          >
            <button
              type="button"
              onClick={() => setOpen(false)}
              className="absolute right-4 top-4 rounded-full border border-cream-800/60 p-2 text-cream-400 transition-colors hover:border-gold-500/50 hover:text-gold-300"
              aria-label="Закрыть подсказку"
            >
              <X className="h-4 w-4" strokeWidth={1.5} />
            </button>
            <p className="font-ui text-[10px] uppercase tracking-[0.4em] text-gold-400">Клавиатура</p>
            <h2 className="mt-3 font-display text-3xl italic text-cream-100">Читать как книгу</h2>
            <ul className="mt-8 space-y-4">
              {ROWS.map((row) => (
                <li key={row.label} className="flex items-center justify-between gap-4">
                  <span className="font-body text-lg text-cream-300">{row.label}</span>
                  <span className="flex gap-1.5">
                    {row.keys.map((k) => (
                      <kbd key={k} className="kbd">
                        {k}
                      </kbd>
                    ))}
                  </span>
                </li>
              ))}
            </ul>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
