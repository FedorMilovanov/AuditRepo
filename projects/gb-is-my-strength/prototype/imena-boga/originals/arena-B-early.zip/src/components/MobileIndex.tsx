import { useEffect, useMemo, useRef, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { List, Search, SearchX, X } from "lucide-react";
import { NAMES, PARTS, type NameEntry } from "../data/names";

interface MobileIndexProps {
  active: string;
  onSelect: (id: string) => void;
  visible: boolean;
}

const GREEK = /[Α-Ωα-ω]/;

/** Strip niqqud and combining accents so «элохим» finds «Элохи́м», and יהוה finds pointed forms. */
function fold(s: string) {
  return s
    .normalize("NFD")
    .replace(/[\u0300-\u036f\u0591-\u05C7]/g, "")
    .toLowerCase();
}

function highlight(text: string, q: string) {
  if (!q) return text;
  const i = text.toLowerCase().indexOf(q.toLowerCase());
  if (i < 0) return text;
  return (
    <>
      {text.slice(0, i)}
      <mark className="search-mark">{text.slice(i, i + q.length)}</mark>
      {text.slice(i + q.length)}
    </>
  );
}

function Row({
  n,
  isActive,
  onGo,
  q,
}: {
  n: NameEntry;
  isActive: boolean;
  onGo: (id: string) => void;
  q?: string;
}) {
  const idx = NAMES.findIndex((x) => x.id === n.id);
  const greek = GREEK.test(n.hebrew);
  return (
    <button
      type="button"
      onClick={() => onGo(n.id)}
      aria-current={isActive ? "true" : undefined}
      className={`flex w-full items-center gap-4 rounded-xl border px-4 py-3 text-left transition-all duration-300 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-gold-400 ${
        isActive
          ? "border-gold-500/50 bg-ink-800"
          : "border-cream-800/40 bg-ink-900/50 hover:border-gold-500/30"
      }`}
    >
      <span className="w-6 shrink-0 font-ui text-[10px] tracking-[0.2em] text-cream-700">
        {String(idx + 1).padStart(2, "0")}
      </span>
      <span
        dir={greek ? "ltr" : "rtl"}
        lang={greek ? "el" : n.id === "atiq-yomin" ? "arc" : "he"}
        title={n.hebrew}
        className="max-w-[38%] shrink-0 truncate font-hebrew text-lg text-gold-300"
      >
        {n.hebrew}
      </span>
      <span className="min-w-0 flex-1">
        <span className="block truncate font-ui text-[11px] uppercase tracking-[0.18em] text-cream-300">
          {highlight(n.translit, q ?? "")}
        </span>
        <span className="block truncate font-body text-sm italic text-cream-700">
          {highlight(n.russian, q ?? "")}
        </span>
      </span>
    </button>
  );
}

export default function MobileIndex({ active, onSelect, visible }: MobileIndexProps) {
  const [open, setOpen] = useState(false);
  const [query, setQuery] = useState("");
  const dialogRef = useRef<HTMLDivElement>(null);
  const searchRef = useRef<HTMLInputElement>(null);
  const triggerRef = useRef<HTMLButtonElement>(null);

  const current = NAMES.find((n) => n.id === active);
  const idx = NAMES.findIndex((n) => n.id === active);
  const progress = idx >= 0 ? ((idx + 1) / NAMES.length) * 100 : 0;

  const q = query.trim().toLowerCase();
  const results = useMemo(() => {
    if (!q) return null;
    const needle = fold(q);
    return NAMES.filter((n) =>
      fold(`${n.translit} ${n.russian} ${n.meaning} ${n.hebrew} ${n.tagline} ${n.id}`).includes(needle),
    );
  }, [q]);

  // "/" shortcut from App opens the index (never on wide screens where rails live).
  useEffect(() => {
    const onOpen = () => {
      if (window.matchMedia("(min-width: 1680px)").matches) return;
      setOpen(true);
    };
    window.addEventListener("open-name-index", onOpen);
    return () => window.removeEventListener("open-name-index", onOpen);
  }, []);

  // Scroll lock, initial focus, Escape, focus trap, focus restore.
  useEffect(() => {
    if (!open) return;
    const previousOverflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    const focusTimer = window.setTimeout(() => searchRef.current?.focus(), 80);

    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") {
        setOpen(false);
        return;
      }
      if (e.key !== "Tab") return;
      const root = dialogRef.current;
      if (!root) return;
      const els = Array.from(
        root.querySelectorAll<HTMLElement>("button, input, a[href]"),
      ).filter((el) => el.offsetParent !== null);
      if (!els.length) return;
      const first = els[0];
      const last = els[els.length - 1];
      if (e.shiftKey && document.activeElement === first) {
        e.preventDefault();
        last.focus();
      } else if (!e.shiftKey && document.activeElement === last) {
        e.preventDefault();
        first.focus();
      }
    };
    window.addEventListener("keydown", onKey);
    return () => {
      window.clearTimeout(focusTimer);
      document.body.style.overflow = previousOverflow;
      window.removeEventListener("keydown", onKey);
      triggerRef.current?.focus();
    };
  }, [open]);

  const go = (id: string) => {
    setOpen(false);
    setQuery("");
    onSelect(id);
  };

  return (
    <>
      {/* floating pill */}
      {visible && (
        <button
          ref={triggerRef}
          type="button"
          onClick={() => setOpen(true)}
          className="fixed bottom-[max(1.25rem,env(safe-area-inset-bottom))] left-1/2 z-40 flex -translate-x-1/2 items-center gap-3 rounded-full border border-gold-500/30 bg-ink-900/90 py-2.5 pl-4 pr-5 shadow-[0_10px_40px_rgba(0,0,0,0.7)] backdrop-blur-md transition-colors hover:border-gold-400/60 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-gold-400 min-[1680px]:hidden"
          aria-label="Открыть указатель имён"
          aria-haspopup="dialog"
        >
          <List className="h-4 w-4 text-gold-400" strokeWidth={1.5} />
          <span className="max-w-[34vw] truncate font-ui text-[10px] uppercase tracking-[0.25em] text-cream-300 sm:max-w-[42vw]">
            {current ? current.translit : "Все имена"}
          </span>
          <span className="hidden font-ui text-[10px] text-cream-700 sm:inline">
            {idx >= 0 ? `${String(idx + 1).padStart(2, "0")}/${NAMES.length}` : ""}
          </span>
        </button>
      )}

      {/* overlay */}
      <AnimatePresence>
        {open && (
          <motion.div
            ref={dialogRef}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.3 }}
            role="dialog"
            aria-modal="true"
            aria-label="Указатель имён Бога"
            className="fixed inset-0 z-[70] flex flex-col bg-ink-950/96 backdrop-blur-xl min-[1680px]:hidden"
          >
            <div className="flex items-center justify-between px-6 pt-6">
              <p className="font-ui text-[10px] uppercase tracking-[0.4em] text-gold-400">
                Все имена Бога
              </p>
              <button
                type="button"
                onClick={() => setOpen(false)}
                className="rounded-full border border-cream-800/60 p-2 text-cream-300 transition-colors hover:border-gold-500/50 hover:text-gold-300 focus-visible:outline focus-visible:outline-2 focus-visible:outline-gold-400"
                aria-label="Закрыть указатель"
              >
                <X className="h-4 w-4" strokeWidth={1.5} />
              </button>
            </div>

            {/* live search */}
            <div className="relative mx-6 mt-4">
              <Search
                className="pointer-events-none absolute left-4 top-1/2 h-4 w-4 -translate-y-1/2 text-cream-700"
                strokeWidth={1.5}
              />
              <input
                ref={searchRef}
                type="text"
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="Имя, значение или перевод…"
                aria-label="Поиск по именам"
                className="w-full rounded-full border border-cream-800/60 bg-ink-900/80 py-3 pl-11 pr-11 font-body text-base text-cream-100 placeholder:text-cream-700 focus:border-gold-500/60 focus:outline-none"
              />
              {query && (
                <button
                  type="button"
                  onClick={() => {
                    setQuery("");
                    searchRef.current?.focus();
                  }}
                  className="absolute right-3 top-1/2 -translate-y-1/2 rounded-full p-1.5 text-cream-500 transition-colors hover:text-gold-300"
                  aria-label="Очистить поиск"
                >
                  <X className="h-3.5 w-3.5" strokeWidth={1.5} />
                </button>
              )}
            </div>

            <div className="mx-6 mt-4 h-px bg-cream-800/40">
              <div
                className="h-px bg-gold-500 transition-all duration-500"
                style={{ width: `${progress}%` }}
              />
            </div>

            <div className="flex-1 overflow-y-auto px-6 pb-10 pt-5">
              {results ? (
                <>
                  <p
                    aria-live="polite"
                    className="mb-4 font-ui text-[9px] uppercase tracking-[0.35em] text-cream-700"
                  >
                    Найдено: {results.length} из {NAMES.length}
                  </p>
                  {results.length > 0 ? (
                    <div className="grid grid-cols-1 gap-2">
                      {results.map((n) => (
                        <Row key={n.id} n={n} isActive={n.id === active} onGo={go} q={q} />
                      ))}
                    </div>
                  ) : (
                    <div className="flex flex-col items-center gap-4 py-16 text-center">
                      <SearchX className="h-8 w-8 text-cream-700" strokeWidth={1.25} />
                      <p className="font-body text-lg italic text-cream-500">
                        Ничего не найдено по запросу «{query.trim()}»
                      </p>
                      <button
                        type="button"
                        onClick={() => {
                          setQuery("");
                          searchRef.current?.focus();
                        }}
                        className="rounded-full border border-gold-500/40 px-5 py-2 font-ui text-[10px] uppercase tracking-[0.25em] text-gold-300 transition-colors hover:bg-ink-800"
                      >
                        Сбросить поиск
                      </button>
                    </div>
                  )}
                </>
              ) : (
                PARTS.map((part, pi) => (
                  <div key={part.id} className="mb-8">
                    <p className="flex items-center gap-3 font-ui text-[9px] uppercase tracking-[0.35em] text-cream-700">
                      <span className="font-display text-base italic text-gold-500/80">
                        {part.numeral}
                      </span>
                      {part.title}
                      <span className="hairline flex-1" />
                    </p>
                    <div className="mt-4 grid grid-cols-1 gap-2">
                      {NAMES.filter((n) => n.part === pi + 1).map((n) => (
                        <Row key={n.id} n={n} isActive={n.id === active} onGo={go} />
                      ))}
                    </div>
                  </div>
                ))
              )}

              <p className="mt-6 flex items-center justify-center gap-3 font-ui text-[9px] uppercase tracking-[0.25em] text-cream-800">
                <kbd className="kbd">Esc</kbd> закрыть
                <span className="h-1 w-1 rotate-45 bg-cream-800" />
                <kbd className="kbd">/</kbd> поиск
              </p>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
