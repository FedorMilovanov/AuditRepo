import { Check, Dices, RotateCcw } from "lucide-react";
import { NAMES, PARTS } from "../data/names";

interface NameGridProps {
  active: string;
  visited: Set<string>;
  onSelect: (id: string) => void;
  onResetVisited: () => void;
}

const gutter = (t: string) => (t.length <= 3 ? "tracking-[0.14em]" : "tracking-[0.02em]");

export default function NameGrid({ active, visited, onSelect, onResetVisited }: NameGridProps) {
  let counter = 0;

  const pickRandom = () => {
    const pool = NAMES.filter((n) => n.id !== active);
    const pick = pool[Math.floor(Math.random() * pool.length)];
    if (pick) onSelect(pick.id);
  };

  return (
    <nav
      id="sozvezdie"
      className="relative mx-auto max-w-6xl scroll-mt-28 px-6 pb-6 pt-4 md:pb-16"
      aria-label="Все имена Бога: указатель"
    >
      {/* header */}
      <div className="mb-10 flex flex-col items-center text-center">
        <p className="flex items-center gap-4 font-ui text-[10px] font-medium uppercase tracking-[0.45em] text-gold-400">
          <span className="hairline w-10" />
          Созвездие имён
          <span className="hairline w-10" />
        </p>
        <h2 className="mt-4 font-display text-3xl font-medium text-cream-100 md:text-4xl">
          ЯХВЕ в центре. Остальные имена — <span className="gold-static italic">вокруг Него</span>
        </h2>
        <p className="mt-3 max-w-md font-body text-base italic text-cream-500">
          Нажмите на любое имя, чтобы открыть его раздел.{" "}
          {NAMES.length} огней — и все они указывают на Одного.
        </p>

        <div className="mt-5 flex flex-wrap items-center justify-center gap-3">
          <button
            type="button"
            onClick={pickRandom}
            className="group inline-flex items-center gap-2.5 rounded-full border border-gold-500/30 bg-ink-900/70 px-5 py-2.5 font-ui text-[10px] font-medium uppercase tracking-[0.25em] text-gold-300 transition-all duration-300 hover:border-gold-400/60 hover:bg-ink-800 hover:shadow-[0_0_28px_-6px_rgba(212,175,55,0.35)] focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-gold-400"
            title="Открыть случайное имя"
          >
            <Dices className="h-4 w-4 transition-transform duration-500 group-hover:rotate-[135deg]" strokeWidth={1.5} />
            Случайное имя
          </button>

          {visited.size > 0 && (
            <span className="inline-flex items-center gap-2 font-ui text-[9px] uppercase tracking-[0.25em] text-cream-500">
              <Check className="h-3.5 w-3.5 text-gold-500" strokeWidth={2} />
              Прочитано {visited.size} / {NAMES.length}
              <button
                type="button"
                onClick={onResetVisited}
                title="Сбросить отметки прочитанного"
                aria-label="Сбросить отметки прочитанного"
                className="rounded-full p-1.5 text-cream-700 transition-colors hover:text-gold-300 focus-visible:outline focus-visible:outline-2 focus-visible:outline-gold-400"
              >
                <RotateCcw className="h-3 w-3" strokeWidth={1.5} />
              </button>
            </span>
          )}
        </div>

        <p className="mt-4 hidden items-center gap-3 font-ui text-[9px] uppercase tracking-[0.25em] text-cream-700 md:flex">
          <kbd className="kbd">/</kbd> поиск
          <span className="h-1 w-1 rotate-45 bg-cream-800" />
          <kbd className="kbd">←</kbd>
          <kbd className="kbd">→</kbd> листать имена
          <span className="h-1 w-1 rotate-45 bg-cream-800" />
          <kbd className="kbd">?</kbd> клавиши
        </p>
      </div>

      {/* parts */}
      {PARTS.map((part, pi) => (
        <div key={part.id} className="mb-8">
          <p className="mb-4 flex items-center gap-4 font-ui text-[9px] font-medium uppercase tracking-[0.4em] text-cream-700">
            <span className="font-display text-lg italic text-gold-500">{part.numeral}</span>
            {part.title}
            <span className="hairline flex-1" />
          </p>
          <div className="grid grid-cols-2 gap-2 sm:grid-cols-3 md:grid-cols-4 md:gap-3 lg:grid-cols-5">
            {NAMES.filter((n) => n.part === pi + 1).map((name) => {
              counter += 1;
              const n = counter;
              const greek = /[Α-Ωα-ω]/.test(name.hebrew);
              const isActive = active === name.id;
              const isRead = visited.has(name.id);
              return (
                <button
                  key={name.id}
                  type="button"
                  onClick={() => onSelect(name.id)}
                  aria-label={`Перейти к разделу: ${name.translit}${isRead ? " (прочитано)" : ""}`}
                  aria-current={isActive ? "true" : undefined}
                  title={`${name.translit} — ${name.russian}`}
                  className={`sheen group relative flex min-h-[104px] flex-col items-center justify-center overflow-hidden rounded-xl border px-2 py-4 transition-all duration-500 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-gold-400 ${
                    isActive
                      ? "border-gold-500/60 bg-gradient-to-b from-ink-800 to-ink-900 shadow-[0_0_35px_-8px_rgba(212,175,55,0.35)]"
                      : name.id === "yhwh"
                        ? "border-gold-500/35 bg-ink-900/70 hover:border-gold-400/55 hover:bg-ink-850 hover:shadow-[0_0_28px_-10px_rgba(212,175,55,0.25)]"
                        : isRead
                          ? "border-gold-700/40 bg-ink-900/60 hover:border-gold-500/40 hover:bg-ink-850"
                          : "border-cream-800/50 bg-ink-900/40 hover:border-gold-500/40 hover:bg-ink-850 hover:shadow-[0_0_28px_-10px_rgba(212,175,55,0.25)]"
                  }`}
                >
                  {/* corner number */}
                  <span
                    className={`absolute left-2.5 top-2 font-ui text-[8px] tracking-[0.3em] transition-colors duration-500 ${
                      isActive ? "text-gold-400" : "text-cream-800 group-hover:text-gold-600"
                    }`}
                  >
                    {String(n).padStart(2, "0")}
                  </span>
                  {/* diamond */}
                  <span
                    className={`absolute right-2.5 top-2.5 h-1.5 w-1.5 rotate-45 transition-all duration-500 ${
                      isActive ? "bg-gold-400 shadow-[0_0_8px_rgba(212,175,55,0.9)]" : "bg-cream-800/70 group-hover:bg-gold-600"
                    }`}
                  />
                  <span
                    dir={greek ? "ltr" : "rtl"}
                    lang={greek ? "el" : name.id === "atiq-yomin" ? "arc" : "he"}
                    className={`select-none px-1 text-center font-hebrew font-medium leading-tight transition-all duration-500 ${
                      name.hebrew.length > 16
                        ? "text-base md:text-lg"
                        : name.hebrew.length > 10
                          ? "text-lg md:text-xl"
                          : "text-xl md:text-2xl"
                    } ${gutter(name.hebrew)} ${isActive ? "glow-gold text-gold-300" : "text-gold-400/55 group-hover:text-gold-300"}`}
                  >
                    {name.hebrew}
                  </span>
                  <span
                    className={`mt-2 font-ui text-[8px] uppercase transition-colors duration-500 sm:text-[9px] ${
                      isActive ? "text-cream-100" : "text-cream-500 group-hover:text-cream-300"
                    } ${gutter(name.translit)}`}
                  >
                    {name.translit}
                  </span>
                  {name.id === "yhwh" && (
                    <span className="mt-1.5 font-ui text-[7px] uppercase tracking-[0.28em] text-gold-500">
                      Центральное имя
                    </span>
                  )}
                  {/* read mark */}
                  {isRead && (
                    <Check
                      className="absolute bottom-2 right-2 h-3 w-3 text-gold-600/90"
                      strokeWidth={2.5}
                      aria-hidden
                    />
                  )}
                </button>
              );
            })}
          </div>
        </div>
      ))}
    </nav>
  );
}
