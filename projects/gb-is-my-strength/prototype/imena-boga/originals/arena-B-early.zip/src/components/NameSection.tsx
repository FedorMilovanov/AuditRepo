import { useEffect, useRef, useState } from "react";
import { motion, useScroll, useTransform } from "framer-motion";
import { ArrowLeft, ArrowRight, BookOpen, Check, Clock, Copy, Hash, Link2, MapPin, Quote, Sparkles, User } from "lucide-react";
import { NAMES, type NameEntry } from "../data/names";
import { copyText, navigateToName } from "../utils/navigate";
import { emitToast } from "./Toast";
import Reveal from "./Reveal";
import Tilt from "./Tilt";

const FACT_ICONS = {
  book: BookOpen,
  hash: Hash,
  map: MapPin,
  clock: Clock,
  user: User,
  sparkle: Sparkles,
} as const;

interface NameSectionProps {
  name: NameEntry;
  index: number;
  onNavigate: (id: string) => void;
}

export default function NameSection({ name, index, onNavigate }: NameSectionProps) {
  const ref = useRef<HTMLElement>(null);
  const [copied, setCopied] = useState(false);
  const copyTimer = useRef(0);
  useEffect(() => () => window.clearTimeout(copyTimer.current), []);
  const copyLink = async () => {
    const url = `${window.location.origin}${window.location.pathname}#${name.id}`;
    const ok = await copyText(url);
    if (ok) {
      setCopied(true);
      emitToast("Ссылка скопирована");
      window.clearTimeout(copyTimer.current);
      copyTimer.current = window.setTimeout(() => setCopied(false), 2200);
    } else {
      navigateToName(name.id);
    }
  };
  const { scrollYProgress } = useScroll({
    target: ref,
    offset: ["start end", "end start"],
  });
  const wmY = useTransform(scrollYProgress, [0, 1], ["-12%", "12%"]);
  const wmOpacity = useTransform(scrollYProgress, [0, 0.35, 0.65, 1], [0, 1, 1, 0]);

  const flip = index % 2 === 1;
  const num = String(index + 1).padStart(2, "0");
  const greek = /[Α-Ωα-ω]/.test(name.hebrew);
  const prev = index > 0 ? NAMES[index - 1] : null;
  const next = index < NAMES.length - 1 ? NAMES[index + 1] : null;
  const jump = (id: string) => onNavigate(id);

  const copyVerse = async () => {
    const ok = await copyText(`«${name.verse.text}» — ${name.verse.ref}`);
    emitToast(ok ? "Стих скопирован" : "Не удалось скопировать");
  };

  return (
    <section
      ref={ref}
      id={name.id}
      data-part={name.part}
      className="part-tint relative scroll-mt-28 overflow-hidden py-20 md:py-28"
    >
      {/* giant hebrew watermark */}
      <motion.span
        aria-hidden
        style={{ y: wmY, opacity: wmOpacity, rotate: flip ? 5 : -5 }}
        className={`pointer-events-none absolute top-1/2 select-none font-hebrew font-bold leading-none text-gold-500/[0.055] blur-[1px] ${
          flip ? "-right-8 md:-right-16" : "-left-8 md:-left-16"
        } text-[34vw] md:text-[24rem]`}
      >
        {name.hebrew}
      </motion.span>

      <div className="relative mx-auto max-w-3xl px-6">
        {/* header */}
        <Reveal>
          <div
            className={`flex items-center gap-4 font-ui text-[10px] font-medium uppercase tracking-[0.4em] text-gold-400/90`}
          >
            <span>Раздел {num} / {NAMES.length}</span>
            <span className="hairline flex-1" />
            <span className="text-cream-500">Часть {name.part}</span>
          </div>
        </Reveal>

        <div className="mt-10 grid items-start gap-10 md:mt-14 md:grid-cols-12 md:gap-8">
          {/* left / name block */}
          <Reveal className={`md:col-span-5 ${flip ? "md:order-2" : ""}`}>
            <div className={flip ? "md:text-right" : ""}>
              <motion.p
                initial={{ opacity: 0, scale: 0.9, filter: "blur(10px)" }}
                whileInView={{ opacity: 1, scale: 1, filter: "blur(0px)" }}
                viewport={{ once: true, margin: "-80px" }}
                transition={{ duration: 1.2, ease: [0.22, 1, 0.36, 1] }}
                className="name-hebrew glow-gold select-none font-hebrew text-6xl font-medium leading-tight text-gold-300 md:text-7xl"
                dir={greek ? "ltr" : "rtl"}
                lang={greek ? "el" : name.id === "atiq-yomin" ? "arc" : "he"}
              >
                {name.hebrew}
              </motion.p>
              <h3 className="mt-6 font-display text-4xl font-semibold italic text-cream-50 md:text-5xl">
                {name.translit}
              </h3>
              {name.id === "yhwh" && (
                <p className="mt-3 font-ui text-[9px] uppercase tracking-[0.35em] text-gold-500">
                  Центральное имя Писания
                </p>
              )}
              <p className="mt-2 font-display text-xl text-cream-300">{name.russian}</p>
              <div className={`mt-6 flex items-center gap-3 ${flip ? "md:justify-end" : ""}`}>
                <span className="h-px w-8 bg-gold-500/50" />
                <p className="font-ui text-[10px] uppercase tracking-[0.3em] text-gold-400">
                  {name.meaning}
                </p>
              </div>
              <p className="mt-6 font-body text-lg italic leading-relaxed text-cream-500">
                «{name.tagline}»
              </p>
              <button
                type="button"
                onClick={copyLink}
                className="mt-8 inline-flex min-h-11 items-center gap-2 font-ui text-[10px] uppercase tracking-[0.2em] text-cream-500 transition-colors hover:text-gold-300 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-gold-400"
                aria-label={`Скопировать ссылку на ${name.translit}`}
              >
                {copied ? <Check className="h-3.5 w-3.5" /> : <Link2 className="h-3.5 w-3.5" />}
                {copied ? "Ссылка скопирована" : "Ссылка на раздел"}
              </button>
            </div>
          </Reveal>

          {/* right / content */}
          <div className={`md:col-span-7 ${flip ? "md:order-1" : ""}`}>
            {name.paragraphs.map((p, i) => (
              <Reveal key={i} delay={0.08 + i * 0.08}>
                <p
                  className={`name-body font-body leading-[1.8] text-cream-300 ${
                    i > 0 ? "mt-5" : ""
                  }`}
                >
                  {p}
                </p>
              </Reveal>
            ))}

            {/* verse card */}
            <Reveal delay={0.15}>
              <Tilt className="mt-9" max={7}>
                <div className="card-parchment sheen relative overflow-hidden rounded-2xl border border-gold-500/25 p-8 shadow-[0_30px_60px_-24px_rgba(0,0,0,0.85)] md:p-9">
                  <span className="absolute -right-6 -top-6 select-none font-hebrew text-8xl text-gold-500/10">
                    ”
                  </span>
                  <Quote className="h-5 w-5 text-gold-400" strokeWidth={1.5} />
                  <p className="mt-4 font-display text-xl font-medium italic leading-relaxed text-cream-100 md:text-2xl">
                    «{name.verse.text}»
                  </p>
                  <div className="mt-5 flex items-center justify-between gap-4">
                    <p className="font-ui text-[11px] font-medium uppercase tracking-[0.35em] text-gold-400">
                      — {name.verse.ref}
                    </p>
                    <button
                      type="button"
                      onClick={copyVerse}
                      className="inline-flex items-center gap-1.5 font-ui text-[9px] uppercase tracking-[0.22em] text-cream-700 transition-colors hover:text-gold-300 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-gold-400"
                      aria-label={`Скопировать стих ${name.verse.ref}`}
                      title="Скопировать стих"
                    >
                      <Copy className="h-3.5 w-3.5" strokeWidth={1.5} />
                      Копировать
                    </button>
                  </div>
                </div>
              </Tilt>
            </Reveal>

            {/* Unboxed reference notes keep the article readable. */}
            <div className="mt-8 grid gap-6 border-t border-gold-500/15 pt-6 sm:grid-cols-3">
              {name.facts.map((f, i) => {
                const Icon = FACT_ICONS[f.icon];
                return (
                  <Reveal key={f.label} delay={0.1 + i * 0.08} className="h-full">
                    <div className="h-full">
                      <Icon className="h-4 w-4 text-gold-500/80" strokeWidth={1.5} />
                      <p className="mt-3 font-ui text-[9px] uppercase tracking-[0.25em] text-cream-700">
                        {f.label}
                      </p>
                      <p className="mt-1 font-body text-[15px] leading-snug text-cream-300">
                        {f.value}
                      </p>
                    </div>
                  </Reveal>
                );
              })}
            </div>
          </div>
        </div>

        {/* prev / next navigation */}
        <div className="mt-16 flex items-stretch justify-between gap-4 border-t border-gold-500/15 pt-8">
          {prev ? (
            <button
              type="button"
              onClick={() => jump(prev.id)}
              className="group flex max-w-[46%] items-center gap-4 text-left"
              aria-label={`Предыдущее имя: ${prev.translit}`}
              aria-keyshortcuts="ArrowLeft"
              title="Клавиша ←"
            >
              <ArrowLeft className="h-4 w-4 shrink-0 text-cream-700 transition-all duration-300 group-hover:-translate-x-1 group-hover:text-gold-300" strokeWidth={1.5} />
              <span>
                <span className="block font-ui text-[9px] uppercase tracking-[0.3em] text-cream-700 transition-colors group-hover:text-gold-500">
                  Предыдущее
                </span>
                <span className="mt-1 block font-display text-lg italic leading-tight text-cream-300 transition-colors group-hover:text-gold-200">
                  {prev.translit}
                </span>
              </span>
            </button>
          ) : (
            <span />
          )}
          {next ? (
            <button
              type="button"
              onClick={() => jump(next.id)}
              className="group ml-auto flex max-w-[46%] items-center justify-end gap-4 text-right"
              aria-label={`Следующее имя: ${next.translit}`}
              aria-keyshortcuts="ArrowRight"
              title="Клавиша →"
            >
              <span>
                <span className="block font-ui text-[9px] uppercase tracking-[0.3em] text-cream-700 transition-colors group-hover:text-gold-500">
                  Следующее
                </span>
                <span className="mt-1 block font-display text-lg italic leading-tight text-cream-300 transition-colors group-hover:text-gold-200">
                  {next.translit}
                </span>
              </span>
              <ArrowRight className="h-4 w-4 shrink-0 text-cream-700 transition-all duration-300 group-hover:translate-x-1 group-hover:text-gold-300" strokeWidth={1.5} />
            </button>
          ) : (
            <span />
          )}
        </div>
      </div>
    </section>
  );
}
