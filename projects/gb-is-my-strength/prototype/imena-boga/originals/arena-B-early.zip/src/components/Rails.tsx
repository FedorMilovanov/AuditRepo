import { useEffect } from "react";
import { motion } from "framer-motion";
import { NAMES } from "../data/names";

interface RailsProps {
  active: string;
  visible: boolean;
  onSelect: (id: string) => void;
}

function RailItem({
  index,
  translit,
  active,
  passed,
  onSelect,
  side,
}: {
  index: number;
  translit: string;
  active: boolean;
  passed: boolean;
  onSelect: () => void;
  side: "left" | "right";
}) {
  return (
    <motion.button
      type="button"
      onClick={onSelect}
      aria-current={active ? "true" : undefined}
      initial={{ opacity: 0, x: side === "left" ? -14 : 14 }}
      whileInView={{ opacity: 1, x: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.7, delay: index * 0.04 }}
      className={`rail-item group relative flex min-h-9 items-center gap-3 px-1 py-1.5 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-gold-400 ${
        side === "left" ? "flex-row-reverse" : ""
      }`}
    >
      {/* diamond marker */}
      <span
        className={`h-1.5 w-1.5 shrink-0 rotate-45 transition-all duration-500 ${
          active
            ? "animate-diamond bg-gold-300 shadow-[0_0_12px_rgba(212,175,55,0.9)]"
            : passed
              ? "bg-gold-600/70"
              : "bg-cream-700/40 group-hover:bg-gold-500/60"
        }`}
      />
      <span className="flex flex-col items-start">
        <span
          className={`font-hebrew text-[10px] leading-none transition-all duration-500 ${
            active
              ? "text-gold-300/80"
              : passed
                ? "text-cream-700/60"
                : "text-cream-800/50 group-hover:text-cream-500"
          }`}
        >
          {String(index + 1).padStart(2, "0")}
        </span>
        <span
          className={`font-ui text-[10px] uppercase tracking-[0.22em] transition-all duration-500 ${
            active
              ? "glow-gold text-gold-200"
              : passed
                ? "text-cream-500/75"
                : "text-cream-700/35 group-hover:text-cream-300"
          }`}
        >
          {translit}
        </span>
      </span>
    </motion.button>
  );
}

function Beam({ progress }: { progress: number }) {
  return (
    <span className="pointer-events-none absolute left-1/2 top-0 h-full w-px -translate-x-1/2">
      <span className="absolute inset-0 bg-cream-800/40" />
      <motion.span
        className="absolute left-0 top-0 w-px bg-gradient-to-b from-gold-300 via-gold-500 to-transparent shadow-[0_0_10px_rgba(212,175,55,0.7)]"
        animate={{ height: `${progress}%` }}
        transition={{ duration: 0.6, ease: "easeOut" }}
      />
    </span>
  );
}

export default function Rails({ active, visible, onSelect }: RailsProps) {
  const activeIdx = NAMES.findIndex((n) => n.id === active);
  const midpoint = Math.ceil(NAMES.length / 2);

  useEffect(() => {
    if (!visible || !active) return;
    const node = document.querySelector<HTMLElement>(`aside [aria-current="true"]`);
    node?.scrollIntoView({ block: "nearest", inline: "nearest" });
  }, [active, visible]);
  const left = NAMES.slice(0, midpoint);
  const right = NAMES.slice(midpoint);

  const rail = (items: typeof NAMES, offset: number, side: "left" | "right", title: string) => {
    const localActive = items.findIndex((n) => n.id === active);
    const progress = localActive >= 0 ? ((localActive + 0.5) / items.length) * 100 : 0;
    return (
      <aside
        aria-label={title}
        className={`fixed top-1/2 z-40 hidden max-h-[94vh] w-48 -translate-y-1/2 transition-opacity duration-700 min-[1680px]:block ${
          visible ? "opacity-100" : "pointer-events-none opacity-0"
        } ${side === "left" ? "left-8" : "right-8"}`}
      >
        <p
          className={`mb-6 flex items-center gap-3 font-ui text-[9px] uppercase tracking-[0.4em] text-cream-700 ${
            side === "left" ? "justify-end" : ""
          }`}
        >
          {side === "left" && <span className="hairline w-8" />}
          {title}
          {side === "right" && <span className="hairline w-8" />}
        </p>
        <div className="rail-scroll max-h-[calc(94vh-4rem)] overflow-y-auto overscroll-contain">
          <div className="relative flex flex-col items-stretch py-1">
            <Beam progress={progress} />
            <div
              className={`relative flex flex-col justify-between gap-1 ${
                side === "left" ? "items-end pr-5" : "items-start pl-5"
              }`}
            >
              {items.map((n, i) => {
                const idx = offset + i;
                return (
                  <RailItem
                    key={n.id}
                    index={idx}
                    translit={n.translit}
                    active={n.id === active}
                    passed={activeIdx >= idx}
                    onSelect={() => onSelect(n.id)}
                    side={side}
                  />
                );
              })}
            </div>
          </div>
        </div>
      </aside>
    );
  };

  return (
    <>
      {rail(left, 0, "left", "Имена I–XV")}
      {rail(right, midpoint, "right", "Имена XVI–XXIX")}
    </>
  );
}
