import { AnimatePresence, motion } from "framer-motion";
import { Minus, Plus } from "lucide-react";

interface ReaderControlsProps {
  size: number; // 0 | 1 | 2
  visible: boolean;
  onChange: (size: number) => void;
}

const LABELS = ["обычный", "крупный", "очень крупный"];

export default function ReaderControls({ size, visible, onChange }: ReaderControlsProps) {
  return (
    <AnimatePresence>
      {visible && (
        <motion.div
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: 12 }}
          transition={{ duration: 0.35, ease: [0.22, 1, 0.36, 1] }}
          data-print-hide
          role="group"
          aria-label="Размер текста статьи"
          className="fixed bottom-[max(1.25rem,env(safe-area-inset-bottom))] left-[max(1.25rem,env(safe-area-inset-left))] z-40 hidden items-center gap-0.5 rounded-full border border-gold-500/25 bg-ink-900/90 py-1 pl-1.5 pr-1.5 shadow-[0_10px_40px_rgba(0,0,0,0.7)] backdrop-blur-md sm:flex"
        >
          <button
            type="button"
            onClick={() => onChange(Math.max(0, size - 1))}
            disabled={size === 0}
            aria-label="Уменьшить текст"
            title="Уменьшить текст"
            className="flex h-9 w-9 items-center justify-center rounded-full text-cream-300 transition-colors hover:bg-ink-800 hover:text-gold-300 disabled:cursor-default disabled:opacity-30 focus-visible:outline focus-visible:outline-2 focus-visible:outline-gold-400"
          >
            <Minus className="h-3.5 w-3.5" strokeWidth={1.5} />
          </button>

          <span className="flex flex-col items-center px-1.5" aria-hidden>
            <span className="font-display text-sm italic leading-none text-gold-300">Аа</span>
            <span className="mt-1 flex gap-1">
              {[0, 1, 2].map((i) => (
                <span
                  key={i}
                  className={`h-1 w-1 rotate-45 transition-colors duration-300 ${
                    i <= size ? "bg-gold-400" : "bg-cream-800"
                  }`}
                />
              ))}
            </span>
          </span>

          <button
            type="button"
            onClick={() => onChange(Math.min(2, size + 1))}
            disabled={size === 2}
            aria-label="Увеличить текст"
            title="Увеличить текст"
            className="flex h-9 w-9 items-center justify-center rounded-full text-cream-300 transition-colors hover:bg-ink-800 hover:text-gold-300 disabled:cursor-default disabled:opacity-30 focus-visible:outline focus-visible:outline-2 focus-visible:outline-gold-400"
          >
            <Plus className="h-3.5 w-3.5" strokeWidth={1.5} />
          </button>

          <span className="sr-only" aria-live="polite">
            Размер текста: {LABELS[size]}
          </span>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
