import { useEffect, useRef } from "react";

interface Particle {
  x: number;
  y: number;
  z: number;
  r: number;
  vx: number;
  vy: number;
  phase: number;
  speed: number;
  warm: number;
}

interface Meteor {
  x: number;
  y: number;
  vx: number;
  vy: number;
  life: number;
  maxLife: number;
}

export default function Starfield({ density = 1 }: { density?: number }) {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    const reduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    let w = 0;
    let h = 0;
    let raf = 0;
    let running = false;
    let onScreen = true;
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    const mouse = { x: 0.5, y: 0.5 };
    const smouse = { x: 0.5, y: 0.5 };
    let particles: Particle[] = [];
    let meteors: Meteor[] = [];
    let nextMeteor = 4000;
    let last = performance.now();

    const spawn = (): Particle => ({
      x: Math.random() * w,
      y: Math.random() * h,
      z: 0.25 + Math.random() * 0.75,
      r: 0.4 + Math.random() * 1.7,
      vx: (Math.random() - 0.5) * 0.06,
      vy: -0.03 - Math.random() * 0.09,
      phase: Math.random() * Math.PI * 2,
      speed: 0.4 + Math.random() * 1.2,
      warm: Math.random(),
    });

    const resize = () => {
      w = canvas.clientWidth;
      h = canvas.clientHeight;
      canvas.width = Math.max(1, w * dpr);
      canvas.height = Math.max(1, h * dpr);
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      const count = Math.floor(((w * h) / 9000) * density);
      particles = Array.from({ length: count }, () => spawn());
    };

    const drawFrame = (now: number) => {
      const dt = Math.min(now - last, 50);
      last = now;
      if (!reduced) {
        smouse.x += (mouse.x - smouse.x) * 0.04;
        smouse.y += (mouse.y - smouse.y) * 0.04;
      }
      const t = now / 1000;

      ctx.clearRect(0, 0, w, h);
      ctx.globalCompositeOperation = "lighter";

      for (const p of particles) {
        if (!reduced) {
          p.x += p.vx * dt * 0.06;
          p.y += p.vy * dt * 0.06;
          if (p.y < -10) { p.y = h + 10; p.x = Math.random() * w; }
          if (p.x < -10) p.x = w + 10;
          if (p.x > w + 10) p.x = -10;
        }

        const par = (smouse.x - 0.5) * 34 * p.z;
        const parY = (smouse.y - 0.5) * 22 * p.z;
        const tw = reduced ? 0.8 : 0.45 + 0.55 * (0.5 + 0.5 * Math.sin(t * p.speed + p.phase));
        const a = tw * (0.25 + 0.55 * p.z);

        if (p.r > 1.4) {
          const g = ctx.createRadialGradient(p.x + par, p.y + parY, 0, p.x + par, p.y + parY, p.r * 5);
          const col = p.warm > 0.5 ? "212,175,55" : "244,229,187";
          g.addColorStop(0, `rgba(${col},${a})`);
          g.addColorStop(1, `rgba(${col},0)`);
          ctx.fillStyle = g;
          ctx.beginPath();
          ctx.arc(p.x + par, p.y + parY, p.r * 5, 0, Math.PI * 2);
          ctx.fill();
        } else {
          ctx.fillStyle = `rgba(${p.warm > 0.5 ? "212,175,55" : "242,235,216"},${a})`;
          ctx.beginPath();
          ctx.arc(p.x + par, p.y + parY, p.r, 0, Math.PI * 2);
          ctx.fill();
        }
      }

      if (reduced) return;

      nextMeteor -= dt;
      if (nextMeteor <= 0) {
        nextMeteor = 5000 + Math.random() * 6000;
        meteors.push({
          x: w * (0.2 + Math.random() * 0.6),
          y: -20,
          vx: (Math.random() - 0.5) * 0.16,
          vy: 0.28 + Math.random() * 0.2,
          life: 0,
          maxLife: 1400 + Math.random() * 800,
        });
      }
      meteors = meteors.filter((m) => m.life < m.maxLife);
      for (const m of meteors) {
        m.life += dt;
        m.x += m.vx * dt;
        m.y += m.vy * dt;
        const fade = 1 - m.life / m.maxLife;
        const tail = 90;
        const g = ctx.createLinearGradient(m.x, m.y, m.x - m.vx * tail, m.y - m.vy * tail);
        g.addColorStop(0, `rgba(236,211,154,${0.7 * fade})`);
        g.addColorStop(1, "rgba(236,211,154,0)");
        ctx.strokeStyle = g;
        ctx.lineWidth = 1.4;
        ctx.beginPath();
        ctx.moveTo(m.x, m.y);
        ctx.lineTo(m.x - m.vx * tail, m.y - m.vy * tail);
        ctx.stroke();
      }
    };

    resize();

    // Reduced motion: paint one calm, static sky; redraw only on resize.
    if (reduced) {
      drawFrame(performance.now());
      const onResizeStatic = () => {
        resize();
        drawFrame(performance.now());
      };
      window.addEventListener("resize", onResizeStatic);
      return () => window.removeEventListener("resize", onResizeStatic);
    }

    const loop = (now: number) => {
      if (!running) return;
      drawFrame(now);
      raf = requestAnimationFrame(loop);
    };

    const sync = () => {
      const shouldRun = onScreen && !document.hidden;
      if (shouldRun && !running) {
        running = true;
        last = performance.now();
        raf = requestAnimationFrame(loop);
      } else if (!shouldRun && running) {
        running = false;
        cancelAnimationFrame(raf);
      }
    };

    const onPointer = (e: PointerEvent) => {
      mouse.x = e.clientX / window.innerWidth;
      mouse.y = e.clientY / window.innerHeight;
    };

    const io = new IntersectionObserver(
      ([entry]) => {
        onScreen = entry.isIntersecting;
        sync();
      },
      { threshold: 0 },
    );

    io.observe(canvas);
    sync();
    document.addEventListener("visibilitychange", sync);
    window.addEventListener("resize", resize);
    window.addEventListener("pointermove", onPointer);
    return () => {
      running = false;
      cancelAnimationFrame(raf);
      io.disconnect();
      document.removeEventListener("visibilitychange", sync);
      window.removeEventListener("resize", resize);
      window.removeEventListener("pointermove", onPointer);
    };
  }, [density]);

  return <canvas ref={canvasRef} className="absolute inset-0 h-full w-full" />;
}
