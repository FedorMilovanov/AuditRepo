import { useEffect, useRef, type ReactNode, type PointerEvent } from "react";

interface TiltProps {
  children: ReactNode;
  className?: string;
  max?: number;
}

const BASE = "perspective(900px) rotateX(0deg) rotateY(0deg)";

/** Pointer-driven 3D tilt. Writes styles directly in rAF — no React re-render per move. */
export default function Tilt({ children, className = "", max = 9 }: TiltProps) {
  const ref = useRef<HTMLDivElement>(null);
  const glareRef = useRef<HTMLDivElement>(null);
  const frame = useRef(0);

  useEffect(() => () => cancelAnimationFrame(frame.current), []);

  const onMove = (e: PointerEvent<HTMLDivElement>) => {
    if (e.pointerType === "touch") return;
    if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;
    const el = ref.current;
    const glare = glareRef.current;
    if (!el || !glare) return;
    const r = el.getBoundingClientRect();
    const px = (e.clientX - r.left) / r.width;
    const py = (e.clientY - r.top) / r.height;
    cancelAnimationFrame(frame.current);
    frame.current = requestAnimationFrame(() => {
      el.style.transform = `perspective(900px) rotateX(${(py - 0.5) * -2 * max}deg) rotateY(${(px - 0.5) * 2 * max}deg)`;
      glare.style.opacity = "1";
      glare.style.background = `radial-gradient(circle at ${px * 100}% ${py * 100}%, rgba(236,211,154,0.16), transparent 55%)`;
    });
  };

  const onLeave = () => {
    cancelAnimationFrame(frame.current);
    const el = ref.current;
    const glare = glareRef.current;
    if (el) el.style.transform = BASE;
    if (glare) glare.style.opacity = "0";
  };

  return (
    <div
      ref={ref}
      onPointerMove={onMove}
      onPointerLeave={onLeave}
      className={`relative transition-transform duration-300 ease-out will-change-transform ${className}`}
      style={{ transform: BASE }}
    >
      {children}
      <div
        ref={glareRef}
        className="pointer-events-none absolute inset-0 rounded-[inherit] transition-opacity duration-300"
        style={{ opacity: 0 }}
      />
    </div>
  );
}
