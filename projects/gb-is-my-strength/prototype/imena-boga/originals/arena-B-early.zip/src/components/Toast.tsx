import { useEffect, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";

export function emitToast(message: string): void {
  window.dispatchEvent(new CustomEvent("gb-toast", { detail: message }));
}

export default function Toast() {
  const [msg, setMsg] = useState<string | null>(null);

  useEffect(() => {
    let hide = 0;
    const onToast = (e: Event) => {
      const text = (e as CustomEvent<string>).detail;
      if (!text) return;
      setMsg(text);
      window.clearTimeout(hide);
      hide = window.setTimeout(() => setMsg(null), 2200);
    };
    window.addEventListener("gb-toast", onToast);
    return () => {
      window.clearTimeout(hide);
      window.removeEventListener("gb-toast", onToast);
    };
  }, []);

  return (
    <AnimatePresence>
      {msg && (
        <motion.div
          role="status"
          aria-live="polite"
          initial={{ opacity: 0, y: 16, scale: 0.96 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          exit={{ opacity: 0, y: 10, scale: 0.96 }}
          transition={{ duration: 0.35, ease: [0.22, 1, 0.36, 1] }}
          data-print-hide
          className="pointer-events-none fixed bottom-24 left-1/2 z-[80] -translate-x-1/2 rounded-full border border-gold-500/35 bg-ink-900/95 px-5 py-2.5 font-ui text-[11px] uppercase tracking-[0.28em] text-gold-200 shadow-[0_16px_40px_rgba(0,0,0,0.55)] backdrop-blur-md"
        >
          {msg}
        </motion.div>
      )}
    </AnimatePresence>
  );
}
