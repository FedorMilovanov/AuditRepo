export function prefersReducedMotion(): boolean {
  return (
    typeof window !== "undefined" &&
    window.matchMedia("(prefers-reduced-motion: reduce)").matches
  );
}

/* While a programmatic smooth scroll is in flight, the scroll spy must not
   overwrite the chosen target with sections we merely pass through. The lock
   releases on `scrollend`, on user input (wheel / touch), or via a fallback
   timeout for browsers without `scrollend`. */
let lockUntil = 0;
let unlockTimer = 0;

function unlockSpy(): void {
  lockUntil = 0;
  window.clearTimeout(unlockTimer);
  window.removeEventListener("scrollend", unlockSpy);
  window.removeEventListener("wheel", unlockSpy);
  window.removeEventListener("touchstart", unlockSpy);
}

function armSpyLock(ms: number): void {
  unlockSpy();
  lockUntil = Date.now() + ms;
  unlockTimer = window.setTimeout(unlockSpy, ms);
  window.addEventListener("scrollend", unlockSpy, { once: true });
  window.addEventListener("wheel", unlockSpy, { passive: true, once: true });
  window.addEventListener("touchstart", unlockSpy, { passive: true, once: true });
}

export function spyLocked(): boolean {
  return Date.now() < lockUntil;
}

/* After a click-driven pushState, the spy must not immediately replaceState
   the same hash (that would collapse the new history entry). */
let skipHashReplace = false;

export function consumeSkipHashReplace(): boolean {
  if (!skipHashReplace) return false;
  skipHashReplace = false;
  return true;
}

export function syncHash(id: string): void {
  if (!id) return;
  if (window.location.hash === `#${id}`) return;
  window.history.replaceState(null, "", `#${id}`);
}

/** Scroll to a name section, keeping the URL hash and history in sync. */
export function navigateToName(
  id: string,
  opts: { push?: boolean; instant?: boolean } = {},
): void {
  const { push = true, instant = false } = opts;
  const el = document.getElementById(id);
  if (!el) return;
  if (push && window.location.hash !== `#${id}`) {
    skipHashReplace = true;
    window.history.pushState(null, "", `#${id}`);
  }
  const smooth = !instant && !prefersReducedMotion();
  if (smooth) armSpyLock(2600);
  else unlockSpy();
  el.scrollIntoView({ behavior: smooth ? "smooth" : "instant", block: "start" });
}

/** Safely read the current hash id (malformed URIs must not crash the page). */
export function readHashId(): string {
  try {
    return decodeURIComponent(window.location.hash.slice(1));
  } catch {
    return "";
  }
}

/** Clipboard with a legacy fallback for non-secure contexts. */
export async function copyText(text: string): Promise<boolean> {
  try {
    if (navigator.clipboard?.writeText) {
      await navigator.clipboard.writeText(text);
      return true;
    }
  } catch {
    /* fall through to legacy path */
  }
  try {
    const ta = document.createElement("textarea");
    ta.value = text;
    ta.setAttribute("readonly", "");
    ta.style.position = "fixed";
    ta.style.opacity = "0";
    document.body.appendChild(ta);
    ta.select();
    const ok = document.execCommand("copy");
    document.body.removeChild(ta);
    return ok;
  } catch {
    return false;
  }
}
