import { useEffect, useMemo, useRef, useState } from "react";
import { Check, RotateCcw, Search, X } from "lucide-react";
import { NAMES, PARTS } from "../data/names";
import { normalizeSearch, scriptAttrs, scriptLabel } from "../utils/script";

interface NameGridProps {
  active: string;
  completedIds: Set<string>;
  onSelect: (id: string) => void;
  onClearProgress: () => void;
}

const GLOBAL_INDEX = new Map(NAMES.map((name, index) => [name.id, index]));

/** Wraps the matched fragment of a label in a gold mark, ignoring stress accents. */
function Highlight({ text, query }: { text: string; query: string }) {
  const q = normalizeSearch(query);
  if (!q) return <>{text}</>;
  const hay = normalizeSearch(text);
  const at = hay.indexOf(q);
  if (at < 0) return <>{text}</>;
  return (
    <>
      {text.slice(0, at)}
      <mark className="rounded-sm bg-gold-500/25 px-0.5 text-gold-100">{text.slice(at, at + q.length)}</mark>
      {text.slice(at + q.length)}
    </>
  );
}

export default function NameGrid({ active, completedIds, onSelect, onClearProgress }: NameGridProps) {
  const [query, setQuery] = useState("");
  const [partFilter, setPartFilter] = useState(0);
  const searchRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    const onKeyDown = (event: KeyboardEvent) => {
      const target = event.target as HTMLElement | null;
      const typing =
        target?.tagName === "INPUT" || target?.tagName === "TEXTAREA" || target?.isContentEditable;
      if (typing) return;
      if (event.key === "/" || ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === "k")) {
        event.preventDefault();
        document.getElementById("sozvezdie")?.scrollIntoView({ behavior: "smooth", block: "start" });
        window.setTimeout(() => searchRef.current?.focus({ preventScroll: true }), 420);
      }
    };
    window.addEventListener("keydown", onKeyDown);
    return () => window.removeEventListener("keydown", onKeyDown);
  }, []);

  const filtered = useMemo(() => {
    const q = normalizeSearch(query);
    return NAMES.filter((name) => {
      if (partFilter !== 0 && name.part !== partFilter) return false;
      if (!q) return true;
      const haystack = normalizeSearch(
        [
          name.translit,
          name.russian,
          name.meaning,
          name.tagline,
          name.verse.ref,
          name.verse.text,
          name.hebrew,
          scriptLabel(name),
        ].join(" "),
      );
      return q.split(/\s+/).every((word) => haystack.includes(word));
    });
  }, [partFilter, query]);

  const progress = Math.round((completedIds.size / NAMES.length) * 100);

  const resetFilters = () => {
    setQuery("");
    setPartFilter(0);
    searchRef.current?.focus();
  };

  return (
    <nav
      id="sozvezdie"
      className="relative mx-auto max-w-6xl scroll-mt-28 px-6 pb-6 pt-4 md:pb-16"
      aria-label="Все имена Бога: указатель"
    >
      {/* header */}
      <div className="mb-8 flex flex-col items-center text-center">
        <p className="flex items-center gap-4 font-ui text-[10px] font-medium uppercase tracking-[0.45em] text-gold-400">
          <span className="hairline w-10" />
          Созвездие имён
          <span className="hairline w-10" />
        </p>
        <h2 className="mt-4 font-display text-3xl font-medium text-cream-100 md:text-4xl">
          Все имена Писания — <span className="gold-static italic">одним взглядом</span>
        </h2>
        <p className="mt-3 max-w-lg font-body text-base italic leading-relaxed text-cream-500">
          Нажмите на любое имя, чтобы открыть его раздел. Созвездие складывается из {NAMES.length}{" "}
          огней — и все они указывают на Одного.
        </p>
      </div>

      {/* search and study progress */}
      <div className="mx-auto mb-10 max-w-4xl rounded-3xl border border-gold-500/15 bg-ink-900/45 p-4 shadow-[0_24px_70px_-35px_rgba(0,0,0,0.9)] backdrop-blur-sm sm:p-5">
        <div className="flex flex-col gap-4 md:flex-row md:items-center">
          <label className="group relative flex-1">
            <span className="sr-only">Найти имя Бога</span>
            <Search className="pointer-events-none absolute left-4 top-1/2 h-4 w-4 -translate-y-1/2 text-cream-700 transition-colors group-focus-within:text-gold-400" />
            <input
              ref={searchRef}
              onKeyDown={(e) => {
                if (e.key === "Enter" && filtered.length > 0) {
                  e.preventDefault();
                  onSelect(filtered[0].id);
                } else if (e.key === "Escape") {
                  e.preventDefault();
                  if (query) setQuery("");
                  else searchRef.current?.blur();
                }
              }}
              value={query}
              onChange={(event) => setQuery(event.target.value)}
              type="search"
              placeholder="Найти: целитель, пастырь, Исход 3, ἐγώ εἰμι…"
              className="h-12 w-full rounded-full border border-cream-800/70 bg-ink-950/75 pl-11 pr-11 font-body text-base text-cream-100 outline-none transition-all placeholder:text-cream-700 focus:border-gold-500/60 focus:shadow-[0_0_0_4px_rgba(212,175,55,0.08)]"
            />
            {query ? (
              <button
                type="button"
                onClick={() => setQuery("")}
                className="absolute right-2.5 top-1/2 flex h-7 w-7 -translate-y-1/2 items-center justify-center rounded-full text-cream-500 transition-colors hover:bg-gold-500/10 hover:text-gold-300"
                aria-label="Очистить поиск"
              >
                <X className="h-3.5 w-3.5" />
              </button>
            ) : (
              <kbd className="pointer-events-none absolute right-4 top-1/2 hidden -translate-y-1/2 rounded border border-cream-800/70 px-1.5 py-0.5 font-ui text-[9px] text-cream-700 sm:block">
                /
              </kbd>
            )}
          </label>

          <div className="min-w-44 md:text-right">
            <div className="flex items-center justify-between gap-3 md:justify-end">
              <p className="font-ui text-[9px] uppercase tracking-[0.28em] text-cream-500">
                Изучено {completedIds.size}/{NAMES.length}
              </p>
              {completedIds.size > 0 && (
                <button
                  type="button"
                  onClick={onClearProgress}
                  className="inline-flex items-center gap-1 font-ui text-[9px] uppercase tracking-[0.18em] text-cream-700 transition-colors hover:text-gold-300"
                >
                  <RotateCcw className="h-3 w-3" /> Сброс
                </button>
              )}
            </div>
            <div className="mt-2 h-1 overflow-hidden rounded-full bg-cream-800/50" aria-hidden>
              <div
                className="h-full rounded-full bg-gradient-to-r from-gold-700 via-gold-500 to-gold-300 shadow-[0_0_12px_rgba(212,175,55,0.55)] transition-all duration-700"
                style={{ width: `${progress}%` }}
              />
            </div>
          </div>
        </div>

        <div className="mt-4 flex flex-wrap items-center gap-2" aria-label="Фильтр по частям исследования">
          <button
            type="button"
            onClick={() => setPartFilter(0)}
            aria-pressed={partFilter === 0}
            className={`rounded-full border px-3.5 py-1.5 font-ui text-[9px] uppercase tracking-[0.2em] transition-all ${
              partFilter === 0
                ? "border-gold-400/70 bg-gold-500/15 text-gold-200"
                : "border-cream-800/60 text-cream-500 hover:border-gold-500/35 hover:text-cream-300"
            }`}
          >
            Все · {NAMES.length}
          </button>
          {PARTS.map((part, index) => {
            const count = NAMES.filter((name) => name.part === index + 1).length;
            const selected = partFilter === index + 1;
            return (
              <button
                key={part.id}
                type="button"
                onClick={() => setPartFilter(index + 1)}
                aria-pressed={selected}
                className={`rounded-full border px-3.5 py-1.5 font-ui text-[9px] uppercase tracking-[0.18em] transition-all ${
                  selected
                    ? "border-gold-400/70 bg-gold-500/15 text-gold-200"
                    : "border-cream-800/60 text-cream-500 hover:border-gold-500/35 hover:text-cream-300"
                }`}
              >
                {part.numeral}. {part.title} · {count}
              </button>
            );
          })}
          <span className="ml-auto font-ui text-[9px] uppercase tracking-[0.22em] text-cream-700" aria-live="polite">
            {query && filtered.length > 0 ? "Enter — открыть первое" : `Показано: ${filtered.length}`}
          </span>
        </div>
        <p className="mt-3 hidden items-center gap-4 border-t border-cream-800/40 pt-3 font-ui text-[9px] uppercase tracking-[0.2em] text-cream-700 lg:flex">
          <span><kbd className="rounded border border-cream-800/80 px-1 text-gold-400">/</kbd> поиск</span>
          <span><kbd className="rounded border border-cream-800/80 px-1 text-gold-400">← →</kbd> соседние имена в статье</span>
          <span><kbd className="rounded border border-cream-800/80 px-1 text-gold-400">M</kbd> отметить изученным</span>
        </p>
      </div>

      {/* parts */}
      {PARTS.map((part, pi) => {
        const entries = filtered.filter((name) => name.part === pi + 1);
        if (entries.length === 0) return null;
        return (
          <div key={part.id} className="mb-8">
            <p className="mb-4 flex items-center gap-4 font-ui text-[9px] font-medium uppercase tracking-[0.4em] text-cream-500">
              <span className="font-display text-lg italic text-gold-500">{part.numeral}</span>
              {part.title}
              <span className="hairline flex-1" />
              <span className="tracking-[0.2em] text-cream-700">{entries.length}</span>
            </p>
            <div className="grid grid-cols-2 gap-2 sm:grid-cols-3 md:grid-cols-4 md:gap-3 lg:grid-cols-5">
              {entries.map((name) => {
                const n = (GLOBAL_INDEX.get(name.id) ?? 0) + 1;
                const attrs = scriptAttrs(name);
                const isActive = active === name.id;
                const isCompleted = completedIds.has(name.id);
                return (
                  <button
                    key={name.id}
                    onClick={() => onSelect(name.id)}
                    aria-label={`Перейти к разделу: ${name.translit}${isCompleted ? ", изучено" : ""}`}
                    aria-current={isActive ? "true" : undefined}
                    className={`group relative flex min-h-[122px] flex-col items-center justify-center overflow-hidden rounded-xl border px-2 py-4 transition-all duration-500 hover:-translate-y-1 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-gold-400 ${
                      isActive
                        ? "border-gold-500/60 bg-gradient-to-b from-ink-800 to-ink-900 shadow-[0_0_35px_-8px_rgba(212,175,55,0.35)]"
                        : isCompleted
                          ? "border-gold-600/35 bg-ink-900/55 hover:border-gold-500/50 hover:bg-ink-850"
                          : "border-cream-800/50 bg-ink-900/40 hover:border-gold-500/40 hover:bg-ink-850 hover:shadow-[0_0_28px_-10px_rgba(212,175,55,0.25)]"
                    }`}
                  >
                    <span
                      className={`absolute left-2.5 top-2 font-ui text-[8px] tracking-[0.3em] transition-colors duration-500 ${
                        isActive || isCompleted ? "text-gold-400" : "text-cream-700 group-hover:text-gold-600"
                      }`}
                    >
                      {String(n).padStart(2, "0")}
                    </span>
                    {isCompleted ? (
                      <span className="absolute right-2 top-2 flex h-4 w-4 items-center justify-center rounded-full bg-gold-500/20 text-gold-300 ring-1 ring-gold-500/40">
                        <Check className="h-2.5 w-2.5" strokeWidth={2.5} />
                      </span>
                    ) : (
                      <span
                        className={`absolute right-2.5 top-2.5 h-1.5 w-1.5 rotate-45 transition-all duration-500 ${
                          isActive ? "bg-gold-400 shadow-[0_0_8px_rgba(212,175,55,0.9)]" : "bg-cream-800/70 group-hover:bg-gold-600"
                        }`}
                      />
                    )}
                    <span
                      {...attrs}
                      className={`select-none text-center font-hebrew text-xl font-medium leading-tight transition-all duration-500 md:text-2xl ${
                        isActive ? "glow-gold text-gold-300" : "text-gold-400/60 group-hover:text-gold-300"
                      }`}
                    >
                      {name.hebrew}
                    </span>
                    <span
                      className={`mt-2 text-center font-ui text-[8px] uppercase tracking-[0.08em] transition-colors duration-500 sm:text-[9px] ${
                        isActive ? "text-cream-100" : "text-cream-400 group-hover:text-cream-200"
                      }`}
                    >
                      <Highlight text={name.translit} query={query} />
                    </span>
                    <span className="mt-1 line-clamp-2 text-center font-display text-sm italic leading-tight text-cream-500 transition-colors group-hover:text-cream-300">
                      <Highlight text={name.russian} query={query} />
                    </span>
                  </button>
                );
              })}
            </div>
          </div>
        );
      })}

      {filtered.length === 0 && (
        <div className="rounded-3xl border border-gold-500/15 bg-ink-900/40 px-6 py-12 text-center">
          <p className="font-display text-2xl italic text-cream-300">По этому запросу имён не нашлось</p>
          <p className="mx-auto mt-2 max-w-md font-body text-base text-cream-500">
            Попробуйте транслитерацию, русский смысл или ссылку — например, «шалом», «пастырь» или «Иоанна 8».
          </p>
          <button
            type="button"
            onClick={resetFilters}
            className="mt-6 rounded-full border border-gold-500/40 px-5 py-2.5 font-ui text-[9px] uppercase tracking-[0.25em] text-gold-300 transition-colors hover:bg-gold-500/10"
          >
            Показать все имена
          </button>
        </div>
      )}
    </nav>
  );
}
