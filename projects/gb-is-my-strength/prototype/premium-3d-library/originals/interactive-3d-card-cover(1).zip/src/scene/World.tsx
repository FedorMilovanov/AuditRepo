import { useRef } from "react";
import { Canvas, useFrame } from "@react-three/fiber";
import { Environment, Lightformer } from "@react-three/drei";
import { XR } from "@react-three/xr";
import { EffectComposer, Bloom, Vignette } from "@react-three/postprocessing";
import { useApp, xrStore, set, get, input, toggleQuality, notify } from "../store";
import { SkyDome, Stars, Mountains, CloudSea, Motes } from "./Sky";
import { Platform } from "./Platform";
import { Center } from "./Center";
import { Stations } from "./Stations";
import { Cards, VRDetail } from "./Cards";
import { Dressing } from "./Dressing";
import { Tomes } from "./Tomes";
import { Vault, StainedLight } from "./Vault";
import { Player, XRRig, CardboardRig } from "./Player";

/**
 * Постобработка.
 * Здесь нет ToneMapping-эффекта: R3F уже включает ACESFilmic у рендерера,
 * а второй проход затемнял и «мылил» всю картинку — и менял яркость
 * при переключении качества (тогда композер размонтируется).
 */
function Effects() {
  const q = useApp((s) => s.quality);
  const xr = useApp((s) => s.xr);
  const mode = useApp((s) => s.mode);
  if (q !== "high" || xr || mode === "cardboard") return null;
  return (
    <EffectComposer multisampling={0} enableNormalPass={false}>
      <Bloom intensity={0.62} luminanceThreshold={0.82} luminanceSmoothing={0.3} mipmapBlur radius={0.7} />
      <Vignette offset={0.34} darkness={0.55} />
    </EffectComposer>
  );
}

function ReadyFlag() {
  const n = useRef(0);
  useFrame(() => {
    if (n.current < 12 && ++n.current === 12) set({ ready: true });
  });
  return null;
}

/**
 * Если зал идёт рывками — сам переходит на «Лёгкую» графику, один раз за сессию.
 * Меряем только когда игрок стоит или идёт сам: во время перелётов кадр всегда тяжёлый.
 */
function AutoQuality() {
  const acc = useRef({ t: 0, n: 0, low: 0, spent: 0, done: false });
  useFrame((_, dt) => {
    const s = get();
    const a = acc.current;
    if (a.done || s.quality !== "high" || s.xr || s.mode === "cardboard") return;
    if (s.phase !== "play" || s.photo || s.paused || s.sitemap || s.opened || input.flying) {
      a.t = 0;
      a.n = 0;
      return;
    }
    a.t += dt;
    a.n++;
    a.spent += dt;
    if (a.t > 4 && a.spent > 10) {
      const fps = a.n / a.t;
      a.low = fps < 36 ? a.low + 1 : 0;
      a.t = 0;
      a.n = 0;
      if (a.low >= 3) {
        a.done = true;
        toggleQuality();
        notify("Включил «Лёгкую» графику — так плавнее.");
      }
    }
  });
  return null;
}

function Cardboard() {
  const mode = useApp((s) => s.mode);
  const phase = useApp((s) => s.phase);
  return mode === "cardboard" && phase === "play" ? <CardboardRig /> : null;
}

/** Настройки контекста фиксируются один раз: WebGL не умеет менять их на ходу,
 *  а новая объектная обёртка заставила бы R3F пересоздать рендерер — и «мигнуть». */
const GL = {
  antialias: true,
  powerPreference: "high-performance" as const,
  stencil: false,
  alpha: false,
  depth: true,
};
const CAMERA = { fov: 72, near: 0.2, far: 900, position: [0, 13, 22] as [number, number, number] };

export default function World() {
  const q = useApp((s) => s.quality);
  const coarse = typeof window !== "undefined" && window.matchMedia?.("(pointer: coarse)").matches;

  return (
    <Canvas
      dpr={q === "high" ? [1, coarse ? 1.5 : 1.75] : [1, 1.25]}
      camera={CAMERA}
      gl={GL}
      onCreated={({ gl }) => {
        // Потеря контекста — самая частая причина «чёрного экрана» на слабых GPU.
        gl.domElement.addEventListener(
          "webglcontextlost",
          (e) => {
            e.preventDefault();
            set({ glLost: true });
          },
          false
        );
        gl.domElement.addEventListener(
          "webglcontextrestored",
          () => {
            set({ glLost: false });
          },
          false
        );
      }}
    >
      <XR store={xrStore}>
        <color attach="background" args={["#0a0c1c"]} />
        <fogExp2 attach="fog" args={["#3a2848", 0.0036]} />

        <SkyDome />
        <Stars count={q === "high" ? 2600 : 1200} />
        <Mountains />
        <CloudSea />

        <Environment resolution={256} frames={1} environmentIntensity={0.9}>
          <color attach="background" args={["#16143a"]} />
          <Lightformer form="rect" intensity={7} color="#ff9a5c" position={[0, 1.5, -9]} scale={[16, 3, 1]} />
          <Lightformer form="rect" intensity={2.4} color="#8aa0ff" position={[0, 9, 0]} rotation-x={Math.PI / 2} scale={[16, 16, 1]} />
          <Lightformer form="ring" intensity={3.2} color="#ffd9a0" position={[0, 4, 0]} rotation-x={Math.PI / 2} scale={5} />
          <Lightformer form="rect" intensity={1.4} color="#b49cff" position={[9, 3, 6]} rotation-y={-Math.PI / 2} scale={[8, 4, 1]} />
        </Environment>
        <hemisphereLight args={["#9a90d8", "#2a2040", 0.72]} />
        <pointLight position={[0, 7.4, 0]} color="#ffd6a0" intensity={34} distance={30} decay={1.7} />
        <directionalLight position={[0, 7, -30]} color="#ffb27a" intensity={2.7} />
        <directionalLight position={[12, 20, 14]} color="#8a9cff" intensity={0.5} />

        <Platform />
        <Vault />
        <Center />
        <Stations />
        <Cards />
        <Tomes />
        <Dressing />
        <StainedLight />
        <Motes count={q === "high" ? 700 : 260} radius={19} height={12} />
        <VRDetail />

        <Player />
        <XRRig />
        <Cardboard />
        <Effects />
        <ReadyFlag />
        <AutoQuality />
      </XR>
    </Canvas>
  );
}
