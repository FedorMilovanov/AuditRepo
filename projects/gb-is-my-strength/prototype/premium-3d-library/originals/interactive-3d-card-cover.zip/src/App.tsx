import { useEffect, useState } from "react";
import { useApp as useStore } from "./store";
import { loadFonts } from "./fonts";
import {
  get,
  input,
  set,
  openItem,
  closeItem,
  toggleSitemap,
  startTour,
  tourStep,
  endTour,
  toggleSit,
  togglePhoto,
  flyTo,
  deepLink,
  pauseGame,
  resumeGame,
} from "./store";
import World from "./scene/World";
import Overlay from "./ui/Overlay";

const MOVE_KEYS = ["KeyW", "KeyA", "KeyS", "KeyD", "ArrowUp", "ArrowDown", "ArrowLeft", "ArrowRight", "ShiftLeft", "ShiftRight"];

export default function App() {
  const [fontsReady, setFontsReady] = useState(false);

  useEffect(() => {
    const onReady = (s: { ready: boolean }) => {
      if (!s.ready || !deepLink) return;
      unsub();
      try {
        history.replaceState(null, "", location.pathname + location.search);
      } catch {
        /* ignore */
      }
      flyTo(deepLink);
    };
    const unsub = useStore.subscribe(onReady);
    return unsub;
  }, []);

  useEffect(() => {
    loadFonts().then(() => setFontsReady(true));
    (navigator as any).xr
      ?.isSessionSupported?.("immersive-vr")
      .then((ok: boolean) => set({ xrSupported: !!ok }))
      .catch(() => {});

    const kd = (e: KeyboardEvent) => {
      const tag = (e.target as HTMLElement | null)?.tagName;
      if (tag === "INPUT" || tag === "TEXTAREA") return;
      const s = get();
      if (s.phase === "play" && MOVE_KEYS.includes(e.code)) {
        input.keys.add(e.code);
        input.dest = null;
        if (s.sitting) toggleSit();
        if (e.code.startsWith("Arrow")) e.preventDefault();
      }
      if (e.repeat) return;
      if (s.phase === "play" && (e.code === "KeyE" || e.code === "KeyF") && s.aimed && !s.opened && !s.paused && !s.sitemap) openItem(s.aimed);
      if (e.code === "KeyM") toggleSitemap();
      if (e.code === "KeyT" && s.phase === "play" && !s.opened && !s.sitemap && !s.xr) {
        if (s.tour === null) startTour();
        else tourStep(1);
      }
      if (e.code === "KeyC" && s.phase === "play" && !s.opened && !s.sitemap) toggleSit();
      if (e.code === "KeyH") togglePhoto();
      if (e.code === "Escape") {
        if (s.photo) togglePhoto(false);
        else if (s.opened) {
          input.suppressPause = performance.now() + 600;
          closeItem(false);
        } else if (s.sitemap) {
          input.suppressPause = performance.now() + 600;
          toggleSitemap(false);
        } else if (s.tour !== null) endTour();
        else if (s.sitting) toggleSit();
        else if (s.paused) resumeGame();
        else if (s.phase === "play" && e.code === "Escape") pauseGame();
      }
      if (e.code === "KeyP" && s.phase === "play" && !s.opened && !s.sitemap && !s.photo && !s.xr) {
        if (s.paused) resumeGame();
        else pauseGame();
      }
    };
    const ku = (e: KeyboardEvent) => input.keys.delete(e.code);
    const blur = () => input.keys.clear();
    window.addEventListener("keydown", kd);
    window.addEventListener("keyup", ku);
    window.addEventListener("blur", blur);
    return () => {
      window.removeEventListener("keydown", kd);
      window.removeEventListener("keyup", ku);
      window.removeEventListener("blur", blur);
    };
  }, []);

  return (
    <div className="fixed inset-0 select-none overflow-hidden bg-[#05070f]">
      {fontsReady && <World />}
      <Overlay fontsReady={fontsReady} />
    </div>
  );
}
