import { useMemo, useRef } from "react";
import { useFrame } from "@react-three/fiber";
import { Billboard } from "@react-three/drei";
import * as THREE from "three";
import { goldMat, marble, stone } from "./Platform";
import { Motes } from "./Sky";
import { titleTexture, verseTexture } from "../textures";
import { useApp } from "../store";

export function Beam({
  height = 4,
  r0 = 0.3,
  r1 = 0.8,
  color = "#ffd58a",
  opacity = 0.35,
  power = 1.6,
}: {
  height?: number;
  r0?: number;
  r1?: number;
  color?: string;
  opacity?: number;
  power?: number;
}) {
  return (
    <mesh position={[0, height / 2, 0]}>
      <cylinderGeometry args={[r1, r0, height, 40, 1, true]} />
      <shaderMaterial
        transparent
        depthWrite={false}
        side={THREE.DoubleSide}
        blending={THREE.AdditiveBlending}
        fog={false}
        uniforms={{ uColor: { value: new THREE.Color(color) }, uOp: { value: opacity }, uPow: { value: power } }}
        vertexShader={/* glsl */ `
          varying vec2 vUv; varying vec3 vN; varying vec3 vV;
          void main(){
            vUv = uv; vN = normalize(normalMatrix*normal);
            vec4 mv = modelViewMatrix*vec4(position,1.);
            vV = normalize(-mv.xyz);
            gl_Position = projectionMatrix*mv;
          }
        `}
        fragmentShader={/* glsl */ `
          uniform vec3 uColor; uniform float uOp; uniform float uPow;
          varying vec2 vUv; varying vec3 vN; varying vec3 vV;
          void main(){
            float f = pow(abs(dot(normalize(vN), normalize(vV))), 1.6);
            float a = pow(1.-vUv.y, uPow)*smoothstep(0.0,0.1,vUv.y)*f*uOp;
            gl_FragColor = vec4(uColor*1.4, a);
          }
        `}
      />
    </mesh>
  );
}

const orbMat = () =>
  new THREE.ShaderMaterial({
    toneMapped: false,
    uniforms: { uTime: { value: 0 } },
    vertexShader: /* glsl */ `
      varying vec3 vN; varying vec3 vV; varying vec3 vP;
      void main(){
        vP = position; vN = normalize(normalMatrix*normal);
        vec4 mv = modelViewMatrix*vec4(position,1.);
        vV = normalize(-mv.xyz);
        gl_Position = projectionMatrix*mv;
      }
    `,
    fragmentShader: /* glsl */ `
      uniform float uTime; varying vec3 vN; varying vec3 vV; varying vec3 vP;
      void main(){
        float f = pow(1.-abs(dot(normalize(vN),normalize(vV))), 2.2);
        float n = sin(vP.x*7.+uTime*1.3)*sin(vP.y*6.-uTime*1.1)*sin(vP.z*7.+uTime*.9);
        float n2 = sin(vP.y*14.+uTime*2.+n*2.)*0.5+0.5;
        vec3 core = mix(vec3(0.95,0.52,0.16), vec3(1.0,0.87,0.62), 0.5+0.5*n);
        vec3 col = core*(0.85+n2*0.25) + vec3(1.,0.72,0.38)*f*1.15;
        gl_FragColor = vec4(col,1.);
      }
    `,
  });

export function Center() {
  const q = useApp((s) => s.quality);
  const orb = useRef<THREE.Mesh>(null!);
  const rings = useRef<THREE.Group>(null!);
  const verse = useRef<THREE.Group>(null!);
  const r1 = useRef<THREE.Mesh>(null!);
  const r2 = useRef<THREE.Mesh>(null!);
  const r3 = useRef<THREE.Mesh>(null!);
  const mat = useMemo(orbMat, []);
  // Пояс: одна фраза, центр текста смотрит на вход; иначе на стыке читается мусор
  const BELT_R = 2.62;
  const BELT_H = 0.44;
  const vTex = useMemo(() => {
    const t = verseTexture(2 * Math.PI * BELT_R, BELT_H);
    t.wrapS = THREE.RepeatWrapping;
    t.offset.x = 0.5;
    return t;
  }, []);
  const tTex = useMemo(() => titleTexture(), []);

  useFrame(({ clock }, dt) => {
    const t = clock.elapsedTime;
    mat.uniforms.uTime.value = t;
    orb.current.position.y = 3.5 + Math.sin(t * 0.8) * 0.12;
    orb.current.scale.setScalar(1 + Math.sin(t * 1.6) * 0.03);
    rings.current.position.y = orb.current.position.y;
    r1.current.rotation.x += dt * 0.45;
    r1.current.rotation.y += dt * 0.2;
    r2.current.rotation.y += dt * 0.5;
    r2.current.rotation.z += dt * 0.3;
    r3.current.rotation.x -= dt * 0.35;
    r3.current.rotation.z += dt * 0.55;
    verse.current.rotation.y -= dt * 0.06;
  });

  return (
    <group>
      {/* ступени */}
      <mesh position={[0, 0.125, 0]} material={stone}>
        <cylinderGeometry args={[3.2, 3.3, 0.25, 64]} />
      </mesh>
      <mesh position={[0, 0.375, 0]} material={marble}>
        <cylinderGeometry args={[2.75, 2.85, 0.25, 64]} />
      </mesh>
      <mesh position={[0, 0.625, 0]} material={marble}>
        <cylinderGeometry args={[2.3, 2.4, 0.25, 64]} />
      </mesh>
      {[3.3, 2.85, 2.4].map((r, i) => (
        <mesh key={i} position={[0, 0.26 * (i + 1) - 0.01 * i, 0]} rotation-x={Math.PI / 2}>
          <torusGeometry args={[r - 0.02, 0.025, 6, 96]} />
          <meshBasicMaterial color="#ffcf80" toneMapped={false} />
        </mesh>
      ))}
      <mesh position={[0, 0.9, 0]} material={goldMat}>
        <cylinderGeometry args={[0.35, 0.8, 0.3, 32]} />
      </mesh>

      {/* светило */}
      <mesh ref={orb} position={[0, 3.5, 0]} material={mat}>
        <icosahedronGeometry args={[0.85, 5]} />
      </mesh>
      <group ref={rings} position={[0, 3.5, 0]}>
        <mesh ref={r1} material={goldMat}>
          <torusGeometry args={[1.35, 0.03, 10, 120]} />
        </mesh>
        <mesh ref={r2} material={goldMat}>
          <torusGeometry args={[1.65, 0.025, 10, 120]} />
        </mesh>
        <mesh ref={r3} material={goldMat}>
          <torusGeometry args={[1.95, 0.02, 10, 140]} />
        </mesh>
      </group>
      <pointLight position={[0, 3.6, 0]} color="#ffc47a" intensity={q === "high" ? 13 : 9} distance={22} decay={1.9} />
      {/* столб света в небо */}
      <group position={[0, 4.2, 0]}>
        <Beam height={70} r0={2.4} r1={0.25} color="#ffcf8a" opacity={0.22} power={1.1} />
      </group>

      {/* стих-лента */}
      {/* пояс с девизом у основания пьедестала: не заслоняет светило */}
      <group ref={verse} position={[0, 0.83, 0]}>
        <mesh>
          <cylinderGeometry args={[BELT_R, BELT_R, BELT_H, 128, 1, true]} />
          <meshBasicMaterial map={vTex} toneMapped={false} />
        </mesh>
        <mesh position={[0, BELT_H / 2, 0]} rotation-x={Math.PI / 2}>
          <torusGeometry args={[BELT_R + 0.01, 0.02, 6, 128]} />
          <meshBasicMaterial color="#f0c27a" toneMapped={false} />
        </mesh>
        <mesh position={[0, -BELT_H / 2, 0]} rotation-x={Math.PI / 2}>
          <torusGeometry args={[BELT_R + 0.01, 0.02, 6, 128]} />
          <meshBasicMaterial color="#f0c27a" toneMapped={false} />
        </mesh>
      </group>

      {/* заголовок */}
      <Billboard position={[0, 13.7, 0]} lockX lockZ>
        <mesh>
          <planeGeometry args={[6.5, 6.5 * (640 / 2048)]} />
          <meshBasicMaterial map={tTex} transparent depthWrite={false} toneMapped={false} color="#dcdcdc" fog={false} />
        </mesh>
      </Billboard>

      <Motes count={q === "high" ? 160 : 70} radius={1.8} height={9} size={1.1} speed={1.6} color="#ffe2a8" />
    </group>
  );
}
