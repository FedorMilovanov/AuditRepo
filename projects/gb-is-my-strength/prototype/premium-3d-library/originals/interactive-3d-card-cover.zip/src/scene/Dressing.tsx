import { useEffect, useMemo, useRef } from "react";
import { useFrame } from "@react-three/fiber";
import * as THREE from "three";
import { ITEMS, byId, itemPos } from "../data";
import { get, input, openItem, registry, set, useApp } from "../store";
import { lecternPage, lintelTexture, verseTabletTexture } from "../textures";
import { darkStone, goldMat, marble, wax, wood } from "./Platform";

const ARCH_Z = 13.32;

function veilMat() {
  return new THREE.ShaderMaterial({
    transparent: true,
    depthWrite: false,
    side: THREE.DoubleSide,
    blending: THREE.AdditiveBlending,
    uniforms: { uTime: { value: 0 } },
    vertexShader: `varying vec2 vUv; void main(){ vUv=uv; gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.); }`,
    fragmentShader: `
      uniform float uTime; varying vec2 vUv;
      void main(){
        float edge = smoothstep(0.0,0.18,vUv.x)*smoothstep(1.0,0.82,vUv.x);
        float up = smoothstep(0.0,0.15,vUv.y)*smoothstep(1.0,0.55,vUv.y);
        float wisp = 0.65+0.35*sin(vUv.y*10.+uTime*0.6+vUv.x*6.);
        gl_FragColor = vec4(vec3(1.0,0.82,0.5), edge*up*wisp*0.16);
      }
    `,
  });
}

function Arch() {
  const tex = useMemo(() => lintelTexture(), []);
  const veil = useMemo(veilMat, []);
  useFrame(({ clock }) => {
    veil.uniforms.uTime.value = clock.elapsedTime;
  });
  return (
    <group position={[0, 0, ARCH_Z]}>
      {[-1.9, 1.9].map((x) => (
        <group key={x} position={[x, 0, 0]}>
          <mesh position={[0, 0.22, 0]} material={darkStone}>
            <cylinderGeometry args={[0.46, 0.54, 0.44, 20]} />
          </mesh>
          <mesh position={[0, 2.95, 0]} material={marble}>
            <cylinderGeometry args={[0.28, 0.36, 5.1, 20]} />
          </mesh>
          <mesh position={[0, 5.58, 0]} material={goldMat}>
            <cylinderGeometry args={[0.42, 0.3, 0.26, 20]} />
          </mesh>
        </group>
      ))}
      <mesh position={[0, 5.78, 0]} material={marble}>
        <boxGeometry args={[4.55, 0.4, 0.72]} />
      </mesh>
      <mesh position={[0, 6.02, 0]} material={goldMat}>
        <boxGeometry args={[4.75, 0.08, 0.8]} />
      </mesh>
      <mesh position={[0, 5.78, -0.38]}>
        <planeGeometry args={[3.7, 0.3]} />
        <meshBasicMaterial map={tex} transparent toneMapped={false} />
      </mesh>
      <mesh position={[0, 5.78, 0.38]} rotation-y={Math.PI}>
        <planeGeometry args={[3.7, 0.3]} />
        <meshBasicMaterial map={tex} transparent toneMapped={false} />
      </mesh>
      <mesh position={[0, 2.7, 0]} material={veil}>
        <planeGeometry args={[3.15, 5.1]} />
      </mesh>
    </group>
  );
}

function VerseTablet() {
  const tex = useMemo(() => verseTabletTexture(), []);
  return (
    <group position={[2.35, 0, 11.55]} rotation-y={Math.atan2(1.05 - 2.35, 9.5 - 11.55)}>
      <mesh position={[0, 0.32, 0]} material={darkStone}>
        <cylinderGeometry args={[0.34, 0.4, 0.64, 18]} />
      </mesh>
      <mesh position={[0, 1.42, 0]} material={marble}>
        <boxGeometry args={[1.05, 1.55, 0.08]} />
      </mesh>
      <mesh position={[0, 1.42, 0.045]}>
        <planeGeometry args={[0.92, 1.38]} />
        <meshBasicMaterial map={tex} toneMapped={false} />
      </mesh>
      <mesh position={[0, 1.42, -0.045]} rotation-y={Math.PI} material={goldMat}>
        <planeGeometry args={[0.7, 0.04]} />
      </mesh>
    </group>
  );
}

function Lectern() {
  const item = byId("c-about");
  const [x, z] = itemPos(item);
  const page = useMemo(() => lecternPage(item), [item]);
  const hit = useRef<THREE.Mesh>(null!);
  const glow = useRef<THREE.MeshBasicMaterial>(null!);
  useEffect(() => {
    const o = hit.current;
    registry.add(o);
    return () => {
      registry.delete(o);
    };
  }, []);
  useFrame(({ clock }, dt) => {
    const a = get().aimed === item.id ? 1 : 0;
    if (glow.current) glow.current.opacity += (0.14 + a * 0.5 - glow.current.opacity) * Math.min(1, dt * 8);
    if (light.current) light.current.intensity = 3.5 + a * 6 + Math.sin(clock.elapsedTime * 2) * 0.3;
  });
  const light = useRef<THREE.PointLight>(null!);
  return (
    <group position={[x, 0, z]} rotation={[0, -(item.angle * Math.PI) / 180, 0]}>
      <mesh position={[0, 0.07, 0]} material={darkStone}>
        <cylinderGeometry args={[0.32, 0.4, 0.14, 20]} />
      </mesh>
      {/* наклонная стойка кафедры */}
      <mesh position={[0, 0.66, -0.1]} rotation={[-0.24, 0, 0]} material={wood}>
        <boxGeometry args={[0.13, 1.2, 0.13]} />
      </mesh>
      <mesh position={[0, 1.06, 0.02]} rotation={[-0.62, 0, 0]} material={wood}>
        <boxGeometry args={[0.74, 0.05, 0.5]} />
      </mesh>
      {/* раскрытая книга на пюпитре */}
      <group position={[0, 1.11, 0.03]} rotation={[-0.62, 0, 0]}>
        <mesh position={[0, 0.012, 0]}>
          <boxGeometry args={[0.62, 0.022, 0.44]} />
          <meshStandardMaterial color="#f7efdb" roughness={0.85} />
        </mesh>
        <mesh position={[0, 0.026, 0]}>
          <planeGeometry args={[0.58, 0.4]} />
          <meshBasicMaterial map={page} toneMapped={false} />
        </mesh>
        <mesh position={[0, -0.012, 0]}>
          <planeGeometry args={[0.86, 0.62]} />
          <meshBasicMaterial ref={glow} color={item.color} transparent opacity={0.2} depthWrite={false} blending={THREE.AdditiveBlending} toneMapped={false} />
        </mesh>
      </group>
      <pointLight ref={light} position={[0, 1.9, 0.5]} color="#ffd9a0" intensity={4} distance={5} decay={1.8} />
      <mesh
        ref={hit}
        position={[0, 1.05, 0]}
        userData={{ id: item.id }}
        onClick={(e) => {
          if (get().xr) {
            e.stopPropagation();
            openItem(item.id);
          }
        }}
        onPointerOver={() => get().xr && set({ aimed: item.id })}
        onPointerOut={() => get().xr && get().aimed === item.id && set({ aimed: null })}
      >
        <boxGeometry args={[0.95, 1.5, 0.7]} />
        <meshBasicMaterial visible={false} />
      </mesh>
    </group>
  );
}

const LANTERNS = [22, 58, 94, 130, 166, 202, 238, 274, 310, 346];

function Lanterns() {
  const q = useApp((s) => s.quality);
  return (
    <group>
      {LANTERNS.map((deg) => {
        const a = (deg * Math.PI) / 180;
        const x = Math.sin(a) * 14.05;
        const z = Math.cos(a) * 14.05;
        return (
          <group key={deg} position={[x, 8.9, z]}>
            <mesh position={[0, 0.06, 0]} material={goldMat}>
              <sphereGeometry args={[0.075, 12, 10]} />
            </mesh>
            <mesh position={[0, -0.78, 0]} material={goldMat}>
              <cylinderGeometry args={[0.012, 0.012, 1.6, 6]} />
            </mesh>
            <mesh position={[0, -1.65, 0]} material={goldMat}>
              <cylinderGeometry args={[0.1, 0.07, 0.08, 10]} />
            </mesh>
            <mesh position={[0, -1.81, 0]}>
              <sphereGeometry args={[0.085, 12, 10]} />
              <meshBasicMaterial color="#ffc98a" toneMapped={false} />
            </mesh>
            <mesh position={[0, -1.81, 0]}>
              <sphereGeometry args={[0.19, 10, 8]} />
              <meshBasicMaterial color="#ff9a4a" transparent opacity={0.22} depthWrite={false} blending={THREE.AdditiveBlending} toneMapped={false} />
            </mesh>
          </group>
        );
      })}
      {/* Свет только в двух точках: каждый источник света — это отдельный цикл в шейдере */}
      {q === "high" &&
        [58, 238].map((deg) => {
          const a = (deg * Math.PI) / 180;
          return (
            <pointLight
              key={deg}
              position={[Math.sin(a) * 11.4, 4.6, Math.cos(a) * 11.4]}
              color="#ffb56a"
              intensity={14}
              distance={13}
              decay={2}
            />
          );
        })}
    </group>
  );
}

function candleSpots(): [number, number, number][] {
  const spots: [number, number, number][] = [
    [3.15, 0, 10.55],
    [-2.4, 0, 11.15],
    [-1.7, 0, 8.35],
  ];
  ITEMS.filter((i) => i.kind === "section").forEach((it) => {
    const a = (it.angle * Math.PI) / 180;
    const r = 7.65;
    const s = 0.62;
    spots.push([Math.sin(a) * r + Math.cos(a) * s, 0, Math.cos(a) * r - Math.sin(a) * s]);
    spots.push([Math.sin(a) * r - Math.cos(a) * s, 0, Math.cos(a) * r + Math.sin(a) * s]);
  });
  return spots;
}

function Candles() {
  const spots = useMemo(candleSpots, []);
  const g = useRef<THREE.Group>(null!);
  useFrame(({ clock }) => {
    const t = clock.elapsedTime;
    g.current.children.forEach((ch, i) => {
      const flame = ch.children[1];
      const s = 0.82 + Math.sin(t * 8.5 + i * 1.7) * 0.18 + Math.sin(t * 21 + i) * 0.08;
      flame.scale.setScalar(Math.max(0.45, s));
      flame.position.y = 0.2 + s * 0.01;
    });
  });
  return (
    <group ref={g}>
      {spots.map((p, i) => (
        <group key={i} position={p}>
          <mesh position={[0, 0.09, 0]} material={wax}>
            <cylinderGeometry args={[0.028, 0.034, 0.18, 8]} />
          </mesh>
          <mesh position={[0, 0.2, 0]}>
            <sphereGeometry args={[0.03, 8, 8]} />
            <meshBasicMaterial color="#ffb15a" toneMapped={false} />
          </mesh>
        </group>
      ))}
    </group>
  );
}

/**
 * Скамьи привязаны к разделу, а не к мировому углу: раньше они стояли
 * на линии взгляда и закрывали вход к станции. Теперь каждая скамья
 * смещена вбок и не попадает в проход.
 */
function Benches() {
  return (
    <group>
      {ITEMS.filter((i) => i.kind === "section").map((it, idx) => {
        const a = (it.angle * Math.PI) / 180;
        const r = 5.55;
        const side = idx % 2 === 0 ? 1 : -1;
        const off = side * 1.15;
        const px = Math.sin(a) * r + Math.cos(a) * off;
        const pz = Math.cos(a) * r - Math.sin(a) * off;
        const top = new THREE.MeshStandardMaterial({ color: "#4a2f1d", roughness: 0.7 });
        return (
          <group key={it.id} position={[px, 0, pz]} rotation={[0, a + Math.PI / 2, 0]}>
            <mesh position={[0, 0.38, 0]} material={top}>
              <boxGeometry args={[1.15, 0.09, 0.38]} />
            </mesh>
            <mesh position={[0, 0.6, -0.19]} rotation-x={-0.12} material={top}>
              <boxGeometry args={[1.15, 0.3, 0.06]} />
            </mesh>
            {[-0.46, 0.46].map((sx) => (
              <group key={sx}>
                <mesh position={[sx, 0.19, 0]} material={goldMat}>
                  <boxGeometry args={[0.05, 0.38, 0.32]} />
                </mesh>
                <mesh position={[sx, 0.45, -0.17]} material={goldMat}>
                  <boxGeometry args={[0.05, 0.54, 0.05]} />
                </mesh>
              </group>
            ))}
          </group>
        );
      })}
    </group>
  );
}

function PathSparks() {
  const sections = ITEMS.filter((i) => i.kind === "section");
  const refs = useRef<THREE.Mesh[]>([]);
  useFrame(({ clock }) => {
    const t = clock.elapsedTime;
    sections.forEach((it, i) => {
      const m = refs.current[i];
      if (!m) return;
      const k = (t * 0.07 + i / sections.length) % 1;
      const r = 4.15 + k * 4.3;
      const a = (it.angle * Math.PI) / 180;
      m.position.set(Math.sin(a) * r, 0.12 + Math.sin(k * Math.PI) * 0.28, Math.cos(a) * r);
      (m.material as THREE.MeshBasicMaterial).opacity = Math.sin(k * Math.PI) * 0.95;
    });
  });
  return (
    <group>
      {sections.map((it, i) => (
        <mesh key={it.id} ref={(el) => { if (el) refs.current[i] = el; }}>
          <sphereGeometry args={[0.055, 10, 10]} />
          <meshBasicMaterial color={it.color} transparent opacity={0.8} depthWrite={false} blending={THREE.AdditiveBlending} toneMapped={false} />
        </mesh>
      ))}
    </group>
  );
}

function Glass() {
  const W = 1.7;
  const H = 3.15;
  return (
    <group>
      {[162, 180, 198].map((deg) => {
        const a = (deg * Math.PI) / 180;
        const R = 15.15;
        return (
          <group key={deg} position={[Math.sin(a) * R, 3.55, Math.cos(a) * R]} rotation={[0, a, 0]}>
            <mesh position={[0, H / 2, 0]} material={marble}>
              <boxGeometry args={[W + 0.16, 0.1, 0.08]} />
            </mesh>
            <mesh position={[0, -H / 2, 0]} material={marble}>
              <boxGeometry args={[W + 0.16, 0.1, 0.08]} />
            </mesh>
            <mesh position={[-W / 2, 0, 0]} material={marble}>
              <boxGeometry args={[0.1, H, 0.08]} />
            </mesh>
            <mesh position={[W / 2, 0, 0]} material={marble}>
              <boxGeometry args={[0.1, H, 0.08]} />
            </mesh>
            <mesh>
              <planeGeometry args={[W - 0.06, H - 0.06]} />
              <shaderMaterial
                transparent
                depthWrite={false}
                side={THREE.DoubleSide}
                toneMapped={false}
                vertexShader={`varying vec2 vUv; void main(){ vUv=uv; gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.); }`}
                fragmentShader={`
                  varying vec2 vUv;
                  void main(){
                    vec2 g = abs(fract(vUv * vec2(3.0, 4.0)) - 0.5);
                    float lead = 1.0 - smoothstep(0.02, 0.09, min(g.x, g.y));
                    float pane = floor(vUv.x * 3.0) + floor(vUv.y * 4.0) * 3.0;
                    vec3 c1 = vec3(1.0, 0.38, 0.16);
                    vec3 c2 = vec3(1.0, 0.72, 0.32);
                    vec3 c3 = vec3(0.55, 0.22, 0.85);
                    vec3 col = mix(c1, c2, fract(pane * 0.41));
                    col = mix(col, c3, step(0.66, fract(pane * 0.23)));
                    // свечение за стеклом: ярче к центру каждой створки
                    float glow = 0.55 + 0.45 * (1.0 - length((fract(vUv * vec2(3.0, 4.0)) - 0.5) * 2.0));
                    col *= glow;
                    col = mix(col, vec3(0.09, 0.05, 0.04), lead);
                    gl_FragColor = vec4(col, mix(0.72, 0.96, lead));
                  }
                `}
              />
            </mesh>
          </group>
        );
      })}
    </group>
  );
}

function Aisle() {
  const mat = useMemo(
    () =>
      new THREE.ShaderMaterial({
        transparent: true,
        depthWrite: false,
        blending: THREE.AdditiveBlending,
        toneMapped: false,
        uniforms: { uTime: { value: 0 } },
        vertexShader: `varying vec2 vUv; void main(){ vUv=uv; gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.); }`,
        fragmentShader: `
          uniform float uTime; varying vec2 vUv;
          void main(){
            float edge = smoothstep(0.0,0.28,vUv.x)*smoothstep(1.0,0.72,vUv.x);
            float f = fract(vUv.y * 3.0 - uTime * 0.06);
            float pulse = smoothstep(0.0,0.12,f)*smoothstep(0.5,0.18,f);
            float ends = smoothstep(0.0,0.06,vUv.y)*smoothstep(1.0,0.94,vUv.y);
            gl_FragColor = vec4(vec3(1.0,0.8,0.42), edge*(0.18+pulse*0.55)*ends);
          }
        `,
      }),
    []
  );
  useFrame(({ clock }) => {
    mat.uniforms.uTime.value = clock.elapsedTime;
  });
  return (
    <mesh rotation-x={-Math.PI / 2} position={[0, 0.03, 8.15]} material={mat}>
      <planeGeometry args={[0.7, 9.2]} />
    </mesh>
  );
}

function DestMark() {
  const m = useRef<THREE.Mesh>(null!);
  useFrame(({ clock }) => {
    const d = input.dest;
    const on = !!d && get().phase === "play";
    m.current.visible = on;
    if (!d) return;
    m.current.position.set(d.x, 0.04, d.z);
    const s = 1 + Math.sin(clock.elapsedTime * 4) * 0.08;
    m.current.scale.setScalar(s);
  });
  return (
    <mesh ref={m} rotation-x={-Math.PI / 2} visible={false}>
      <ringGeometry args={[0.26, 0.38, 32]} />
      <meshBasicMaterial color="#ffd58a" transparent opacity={0.85} depthWrite={false} toneMapped={false} />
    </mesh>
  );
}

export function Dressing() {
  return (
    <group>
      <Arch />
      <VerseTablet />
      <Lectern />
      <Lanterns />
      <Candles />
      <Benches />
      <PathSparks />
      <Glass />
      <Aisle />
      <DestMark />
    </group>
  );
}
