import { useLayoutEffect, useMemo, useRef } from "react";
import * as THREE from "three";


import { floorTexture } from "../textures";

export const stone = new THREE.MeshStandardMaterial({ color: "#8d90ad", roughness: 0.55, metalness: 0.05 });
export const darkStone = new THREE.MeshStandardMaterial({ color: "#3c4066", roughness: 0.55, metalness: 0.12 });
export const baseStone = new THREE.MeshStandardMaterial({ color: "#6d72a0", roughness: 0.5, metalness: 0.1 });
export const goldMat = new THREE.MeshStandardMaterial({ color: "#e2b866", roughness: 0.28, metalness: 1 });
export const marble = new THREE.MeshStandardMaterial({ color: "#c9c4ba", roughness: 0.5, metalness: 0.03 });
export const wood = new THREE.MeshStandardMaterial({ color: "#5c3a24", roughness: 0.72, metalness: 0.04 });
export const wax = new THREE.MeshStandardMaterial({ color: "#f4ead4", roughness: 0.55, metalness: 0 });

function rockGeometry() {
  const g = new THREE.ConeGeometry(16, 36, 56, 12, true);
  g.rotateX(Math.PI);
  const p = g.attributes.position;
  const h = (x: number, y: number, z: number) => {
    const s = Math.sin(x * 1.7 + y * 0.9) * Math.cos(z * 1.3 - y * 1.1) + Math.sin(x * 0.6 - z * 0.8 + y * 2.1) * 0.6;
    return s;
  };
  for (let i = 0; i < p.count; i++) {
    const x = p.getX(i), y = p.getY(i), z = p.getZ(i);
    const f = (18 - y) / 36; // 0 у верхнего края, 1 в нижней точке
    const r = Math.hypot(x, z) || 1;
    const k = h(x, y, z) * 1.9 * Math.min(f * 4, 1) * (1 - f * 0.4);
    p.setXYZ(i, x + (x / r) * k, y + h(z, x, y) * 0.9 * f, z + (z / r) * k);
  }
  g.computeVertexNormals();
  return g;
}

export function Platform() {
  const floorTex = useMemo(() => floorTexture(), []);
  const rock = useMemo(() => rockGeometry(), []);
  const N = 20;
  const R = 14.5;

  const shaft = useRef<THREE.InstancedMesh>(null!);
  const base = useRef<THREE.InstancedMesh>(null!);
  const cap = useRef<THREE.InstancedMesh>(null!);
  useLayoutEffect(() => {
    const m = new THREE.Matrix4();
    const e = new THREE.Euler();
    const qn = new THREE.Quaternion();
    const s = new THREE.Vector3(1, 1, 1);
    for (let i = 0; i < N; i++) {
      const a = (i / N) * Math.PI * 2 + Math.PI / N;
      const x = Math.sin(a) * R, z = Math.cos(a) * R;
      qn.setFromEuler(e.set(0, -a, 0));
      shaft.current.setMatrixAt(i, m.compose(new THREE.Vector3(x, 4.35, z), qn, s));
      base.current.setMatrixAt(i, m.compose(new THREE.Vector3(x, 0.17, z), qn, s));
      cap.current.setMatrixAt(i, m.compose(new THREE.Vector3(x, 8.55, z), qn, s));
    }
    [shaft, base, cap].forEach((r) => (r.current.instanceMatrix.needsUpdate = true));
  }, []);

  return (
    <group>
      {/* плита */}
      <mesh position={[0, -0.3, 0]} material={darkStone}>
        <cylinderGeometry args={[16.2, 16.0, 0.6, 96]} />
      </mesh>
      {/* пол: полированный камень с отражением окружения.
          Раньше здесь стоял MeshReflectorMaterial — он рендерил сцену ещё дважды
          за кадр и на слабых GPU вызывал потерю контекста. */}
      <mesh rotation-x={-Math.PI / 2} position={[0, 0.005, 0]}>
        <circleGeometry args={[16, 96]} />
        <meshStandardMaterial
          map={floorTex}
          color="#8f96c4"
          roughness={0.34}
          metalness={0.3}
          envMapIntensity={0.55}
        />
      </mesh>
      {/* мягкий блик по центру, имитирующий отражение светила */}
      <mesh rotation-x={-Math.PI / 2} position={[0, 0.012, 0]}>
        <circleGeometry args={[9.5, 48]} />
        <meshBasicMaterial color="#ffe0b0" transparent opacity={0.02} depthWrite={false} blending={THREE.AdditiveBlending} toneMapped={false} />
      </mesh>
      {/* золотой кант */}
      <mesh rotation-x={Math.PI / 2} position={[0, 0.02, 0]}>
        <torusGeometry args={[16.05, 0.06, 8, 160]} />
        <meshBasicMaterial color="#ffd58a" toneMapped={false} />
      </mesh>
      {/* скальное основание */}
      <mesh geometry={rock} position={[0, -18.6, 0]}>
        <meshStandardMaterial color="#232642" roughness={0.95} metalness={0} flatShading />
      </mesh>

      {/* колоннада */}
      <instancedMesh ref={shaft} args={[undefined, undefined, N]} material={marble}>
        <cylinderGeometry args={[0.36, 0.42, 8.2, 24]} />
      </instancedMesh>
      <instancedMesh ref={base} args={[undefined, undefined, N]} material={marble}>
        <cylinderGeometry args={[0.62, 0.7, 0.34, 24]} />
      </instancedMesh>
      <instancedMesh ref={cap} args={[undefined, undefined, N]} material={marble}>
        <cylinderGeometry args={[0.72, 0.46, 0.42, 24]} />
      </instancedMesh>
      <mesh position={[0, 9.05, 0]} rotation-x={Math.PI / 2} material={marble}>
        <torusGeometry args={[R, 0.4, 14, 160]} />
      </mesh>
      <mesh position={[0, 9.5, 0]} rotation-x={Math.PI / 2} material={goldMat}>
        <torusGeometry args={[R, 0.09, 8, 160]} />
      </mesh>
      <mesh position={[0, 8.72, 0]} rotation-x={Math.PI / 2}>
        <torusGeometry args={[R - 0.18, 0.045, 8, 160]} />
        <meshBasicMaterial color="#ffcf80" toneMapped={false} />
      </mesh>
    </group>
  );
}
