import { useMemo, useRef } from "react";
import { useFrame } from "@react-three/fiber";
import * as THREE from "three";
import { goldMat, marble, wax } from "./Platform";
import { useApp } from "../store";
import { Motes } from "./Sky";

const RIBS = 20;
const OC_R = 4.15;
const OC_Y = 13.15;
const COL_R = 14.45;
const COL_Y = 8.9;
const UP = new THREE.Vector3(0, 1, 0);

function ribCurve(index: number) {
  // ребро вырастает ровно из капители колонны
  const a = (index / RIBS) * Math.PI * 2 + Math.PI / RIBS;
  const p0 = new THREE.Vector3(Math.sin(a) * COL_R, COL_Y, Math.cos(a) * COL_R);
  const p2 = new THREE.Vector3(Math.sin(a) * OC_R, OC_Y, Math.cos(a) * OC_R);
  const pr = (COL_R + OC_R) * 0.5;
  const p1 = new THREE.Vector3(Math.sin(a) * pr, COL_Y + (OC_Y - COL_Y) * 0.9, Math.cos(a) * pr);
  return new THREE.QuadraticBezierCurve3(p0, p1, p2);
}

/**
 * Купол-оболочка между колоннадой и окулусом.
 * Сфера с центром на оси, проходящая через оба кольца: изнутри читается как
 * сплошная поверхность с рёбрами, а небо и звёзды просвечивают.
 */
function DomeShell() {
  const mat = useMemo(
    () =>
      new THREE.ShaderMaterial({
        transparent: true,
        depthWrite: false,
        side: THREE.BackSide,
        blending: THREE.AdditiveBlending,
        fog: false,
        toneMapped: false,
        uniforms: { uTime: { value: 0 }, uOff: { value: Math.PI / RIBS } },
        vertexShader: `
          varying vec3 vP; varying vec3 vN;
          void main(){
            vP = position; vN = normalize(normalMatrix*normal);
            gl_Position = projectionMatrix*modelViewMatrix*vec4(position,1.);
          }
        `,
        fragmentShader: `
          uniform float uTime; uniform float uOff; varying vec3 vP; varying vec3 vN;
          void main(){
            float ang = atan(vP.x, vP.z) - uOff;
            // 20 рёбер свода
            float rib = pow(abs(sin(ang * 10.0)), 26.0);
            // 0 у окулуса, 1 у колоннады
            float t = clamp((25.05 - vP.y) / 4.25, 0.0, 1.0);
            float glow = 0.5 + 0.5 * sin(uTime * 0.25 + ang * 2.0);
            vec3 col = mix(vec3(0.30, 0.27, 0.56), vec3(1.0, 0.82, 0.52), rib * 0.85);
            col += vec3(0.16, 0.12, 0.30) * (1.0 - t) * glow;
            float a = 0.035 + rib * 0.14 + (1.0 - t) * 0.035;
            gl_FragColor = vec4(col, a);
          }
        `,
      }),
    []
  );
  useFrame(({ clock }) => {
    mat.uniforms.uTime.value = clock.elapsedTime;
  });
  return (
    <mesh position={[0, -11.9, 0]} material={mat} renderOrder={-1}>
      <sphereGeometry args={[25.39, 96, 22, 0, Math.PI * 2, 0.1637, 0.4472]} />
    </mesh>
  );
}

/** Свод: рёбра от колонн к световому окулусу, в котором видны звёзды */
export function Vault() {
  const ribs = useMemo(
    () => Array.from({ length: RIBS }, (_, i) => new THREE.TubeGeometry(ribCurve(i), 26, 0.105, 6, false)),
    []
  );
  const ringRef = useRef<THREE.Mesh>(null!);
  const boss = useRef<THREE.Mesh>(null!);
  useFrame(({ clock }) => {
    const t = clock.elapsedTime;
    boss.current.position.y = 14.9 + Math.sin(t * 0.6) * 0.05;
  });
  return (
    <group>
      {ribs.map((g, i) => (
        <mesh key={i} geometry={g} material={marble} />
      ))}
      {/* окулус */}
      <mesh ref={ringRef} position={[0, OC_Y, 0]} rotation-x={Math.PI / 2} material={marble}>
        <torusGeometry args={[OC_R + 0.25, 0.3, 12, 96]} />
      </mesh>
      <mesh position={[0, OC_Y - 0.14, 0]} rotation-x={Math.PI / 2}>
        <torusGeometry args={[OC_R + 0.1, 0.05, 8, 96]} />
        <meshBasicMaterial color="#ffcf80" toneMapped={false} />
      </mesh>
      {/* замковый камень */}
      <mesh ref={boss} position={[0, 11.9, 0]} material={goldMat}>
        <sphereGeometry args={[0.26, 24, 18]} />
      </mesh>
      {/* пятки рёбер на капителях */}
      {Array.from({ length: RIBS }).map((_, i) => {
        const a = (i / RIBS) * Math.PI * 2 + Math.PI / RIBS;
        return (
          <mesh key={`p${i}`} position={[Math.sin(a) * COL_R, COL_Y - 0.12, Math.cos(a) * COL_R]} material={goldMat}>
            <sphereGeometry args={[0.16, 14, 12]} />
          </mesh>
        );
      })}
      <DomeShell />
      <Chandelier />
      <Motes count={90} radius={OC_R} height={4.2} size={0.7} speed={0.7} color="#ffe6b8" />
    </group>
  );
}

function Chandelier() {
  const Y = 12.35;
  const R = 1.95;
  const g = useRef<THREE.Group>(null!);
  useFrame(({ clock }) => {
    const t = clock.elapsedTime;
    g.current.rotation.y = t * 0.06;
    g.current.children.forEach((c, i) => {
      const f = c.userData.flame as THREE.Mesh | undefined;
      if (!f) return;
      const s = 0.8 + Math.sin(t * 9 + i * 1.9) * 0.2;
      f.scale.setScalar(Math.max(0.4, s));
    });
  });
  return (
    <group ref={g} position={[0, Y, 0]}>
      <mesh position={[0, 1.15, 0]} material={goldMat}>
        <cylinderGeometry args={[0.02, 0.02, 2.3, 6]} />
      </mesh>
      <mesh material={goldMat}>
        <torusGeometry args={[R, 0.05, 10, 72]} />
      </mesh>
      <mesh position={[0, -0.16, 0]} material={goldMat}>
        <torusGeometry args={[R * 0.62, 0.03, 8, 56]} />
      </mesh>
      {Array.from({ length: 10 }).map((_, i) => {
        const a = (i / 10) * Math.PI * 2;
        return (
          <group key={i} position={[Math.cos(a) * R, 0.09, Math.sin(a) * R]}>
            <mesh material={wax}>
              <cylinderGeometry args={[0.035, 0.045, 0.24, 8]} />
            </mesh>
            <mesh position={[0, 0.19, 0]} userData={{ flame: true }}>
              <sphereGeometry args={[0.042, 8, 8]} />
              <meshBasicMaterial color="#ffbe6e" toneMapped={false} />
            </mesh>
            <mesh position={[0, 0.2, 0]}>
              <sphereGeometry args={[0.1, 8, 8]} />
              <meshBasicMaterial color="#ff9a3a" transparent opacity={0.16} depthWrite={false} blending={THREE.AdditiveBlending} toneMapped={false} />
            </mesh>
          </group>
        );
      })}
      <pointLight position={[0, -0.2, 0]} color="#ffc487" intensity={24} distance={26} decay={1.7} />
    </group>
  );
}

const WINDOWS = [
  { deg: 162, color: "#b06cff" },
  { deg: 180, color: "#ffb055" },
  { deg: 198, color: "#ff7a6b" },
];
const WIN_R = 15.15;
const WIN_Y = 3.55;

function FloorPool({ deg, color }: { deg: number; color: string }) {
  const a = (deg * Math.PI) / 180;
  const r = WIN_R - 6.1;
  return (
    <mesh rotation-x={-Math.PI / 2} position={[Math.sin(a) * r, 0.05, Math.cos(a) * r]} rotation-z={-a}>
      <circleGeometry args={[1.85, 48]} />
      <shaderMaterial
        transparent
        depthWrite={false}
        blending={THREE.AdditiveBlending}
        toneMapped={false}
        uniforms={{ uColor: { value: new THREE.Color(color) }, uTime: { value: 0 } }}
        vertexShader={`varying vec2 vUv; void main(){ vUv=uv; gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.); }`}
        fragmentShader={`
          uniform vec3 uColor; uniform float uTime; varying vec2 vUv;
          void main(){
            float d = length((vUv-0.5)*2.0);
            float fall = pow(1.0-clamp(d,0.,1.), 2.4);
            float panes = 0.62+0.38*abs(sin(vUv.x*16.0+1.2))*abs(sin(vUv.y*11.0));
            float breathe = 0.9+0.1*sin(uTime*0.7+vUv.x*3.0);
            gl_FragColor = vec4(uColor*1.25, fall*panes*breathe*0.75);
          }
        `}
      />
    </mesh>
  );
}

function Shaft({ deg, color }: { deg: number; color: string }) {
  const { pos, quat, len } = useMemo(() => {
    const a = (deg * Math.PI) / 180;
    const win = new THREE.Vector3(Math.sin(a) * WIN_R, WIN_Y, Math.cos(a) * WIN_R);
    const pool = new THREE.Vector3(Math.sin(a) * (WIN_R - 6.1), 0.05, Math.cos(a) * (WIN_R - 6.1));
    const dir = pool.clone().sub(win);
    const l = dir.length();
    const q = new THREE.Quaternion().setFromUnitVectors(UP, dir.clone().normalize());
    return { pos: win.clone().add(pool).multiplyScalar(0.5), quat: q, len: l };
  }, [deg]);
  const mat = useRef<THREE.ShaderMaterial>(null!);
  useFrame(({ clock }) => {
    if (mat.current) mat.current.uniforms.uTime.value = clock.elapsedTime;
  });
  return (
    <group>
      <mesh position={pos} quaternion={quat}>
        <cylinderGeometry args={[1.95, 0.9, len, 30, 1, true]} />
        <shaderMaterial
          ref={mat}
          transparent
          depthWrite={false}
          side={THREE.DoubleSide}
          blending={THREE.AdditiveBlending}
          toneMapped={false}
          uniforms={{ uColor: { value: new THREE.Color(color) }, uTime: { value: 0 } }}
          vertexShader={`
            varying vec2 vUv; varying vec3 vN; varying vec3 vV;
            void main(){
              vUv = uv; vN = normalize(normalMatrix*normal);
              vec4 mv = modelViewMatrix*vec4(position,1.);
              vV = normalize(-mv.xyz);
              gl_Position = projectionMatrix*mv;
            }
          `}
          fragmentShader={`
            uniform vec3 uColor; uniform float uTime;
            varying vec2 vUv; varying vec3 vN; varying vec3 vV;
            void main(){
              float rim = abs(dot(normalize(vN), normalize(vV)));
              float edge = smoothstep(0.0, 0.55, rim);
              float fall = pow(1.0-vUv.y, 1.5);
              float dust = 0.86+0.14*sin(vUv.x*26.0+uTime*0.4);
              gl_FragColor = vec4(uColor*1.15, fall*edge*dust*0.30);
            }
          `}
        />
      </mesh>
      <FloorPool deg={deg} color={color} />
      <pointLight
        position={[Math.sin((deg * Math.PI) / 180) * 10.4, 1.9, Math.cos((deg * Math.PI) / 180) * 10.4]}
        color={color}
        intensity={5}
        distance={8}
        decay={2}
      />
    </group>
  );
}

export function StainedLight() {
  const q = useApp((s) => s.quality);
  if (q !== "high") return null;
  return (
    <group>
      {WINDOWS.map((w) => (
        <Shaft key={w.deg} deg={w.deg} color={w.color} />
      ))}
    </group>
  );
}
