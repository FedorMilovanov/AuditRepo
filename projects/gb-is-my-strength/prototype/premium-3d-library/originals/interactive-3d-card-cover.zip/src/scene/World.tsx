import { useEffect, useRef } from "react";
import { Canvas, useFrame, useThree } from "@react-three/fiber";
import { Environment, Lightformer } from "@react-three/drei";
import { XR } from "@react-three/xr";
import { EffectComposer, Bloom, Vignette, ToneMapping } from "@react-three/postprocessing";
import { ToneMappingMode } from "postprocessing";
import { useApp, xrStore, set, toggleQuality, notify, get, input } from "../store";
import { SkyDome, Stars, Mountains, CloudSea, Motes } from "./Sky";
import { Platform } from "./Platform";
import { Center } from "./Center";
import { Stations } from "./Stations";
import { Cards, VRDetail } from "./Cards";
import { Dressing } from "./Dressing";
import { Tomes } from "./Tomes";
import { Vault, StainedLight } from "./Vault";
import { Player, XRRig, CardboardRig } from "./Player";

/** Постобработка. Не размонтируем её при смене качества — иначе экран мигает. */
function Effects() {
  const q = useApp((s) => s.quality);
  const xr = useApp((s) => s.xr);
  const mode = useApp((s) => s.mode);
  if (xr || mode === "cardboard") return null;
  return (
    <EffectComposer multisampling={0} enableNormalPass={false}>
      <Bloom
        intensity={q === "high" ? 0.5 : 0.22}
        luminanceThreshold={q === "high" ? 0.92 : 0.97}
        luminanceSmoothing={0.22}
        mipmapBlur
        radius={0.62}
      />
      <Vignette offset={0.36} darkness={0.5} />
      <ToneMapping mode={ToneMappingMode.ACES_FILMIC} />
    </EffectComposer>
  );
}

function ReadyFlag() {
  const n = useRef(0);
  useFrame(() => {
    if (n.current < 10 && ++n.current === 10) set({ ready: true });
  });
  return null;
}

/**
 * Адаптивное разрешение вместо резкой смены настроек:
 * сначала плавно снижаем DPR, и только если это не помогло — один раз
 * выключаем тяжёлые эффекты. Экран при этом не чернеет.
 */
function PerfGuard() {
  const setDpr = useThree((s) => s.setDpr);
  const acc = useRef({ t: 0, n: 0, low: 0, high: 0, warm: 0, dpr: 1.5, dropped: false });
  useEffect(() => {
    setDpr(acc.current.dpr);
  }, [setDpr]);
  useFrame((_, dt) => {
    const a = acc.current;
    const s = get();
    if (s.phase !== "play" || s.paused || s.photo || s.xr || s.mode === "cardboard" || input.flying) {
      a.t = 0;
      a.n = 0;
      return;
    }
    a.t += dt;
    a.n++;
    a.warm += dt;
    if (a.t < 1.6 || a.warm < 4) return;
    const fps = a.n / a.t;
    set({ fps: Math.round(fps) });
    a.t = 0;
    a.n = 0;
    if (fps < 40) {
      a.low++;
      a.high = 0;
    } else if (fps > 57) {
      a.high++;
      a.low = 0;
    }
    // Разрешение только понижаем: обратное повышение даёт «дышащую» картинку и рывки
    if (a.low >= 2 && a.dpr > 0.75) {
      a.dpr = Math.max(0.75, a.dpr - 0.2);
      setDpr(a.dpr);
      a.low = 0;
    } else if (a.low >= 5 && !a.dropped && s.quality === "high") {
      a.dropped = true;
      toggleQuality();
      notify("Снизил графику, чтобы зал не дёргался. Вернуть можно в паузе или в меню.");
    }
  });
  return null;
}

/**
 * «Чёрный экран» обычно означает потерю WebGL-контекста. Показываем понятный
 * экран восстановления и один раз перезагружаем страницу; при повторе
 * включаем лёгкий режим, чтобы не застрять в цикле.
 * Сторож «нет кадров» здесь намеренно не используется: на медленном GPU
 * он давал ложные срабатывания и сам вызывал чёрный экран.
 */
function ContextGuard() {
  const gl = useThree((s) => s.gl);
  useEffect(() => {
    const el = gl.domElement;
    let timer = 0;
    const lost = (e: Event) => {
      e.preventDefault();
      set({ ctxLost: true });
      timer = window.setTimeout(() => {
        try {
          const prev = Number(sessionStorage.getItem("gb-hall-loss-at") || 0);
          const count = Date.now() - prev < 120_000 ? Number(sessionStorage.getItem("gb-hall-loss-n") || 0) + 1 : 1;
          sessionStorage.setItem("gb-hall-loss-at", String(Date.now()));
          sessionStorage.setItem("gb-hall-loss-n", String(count));
          if (count >= 2) localStorage.setItem("gb-hall-quality", "low");
        } catch {
          /* ignore */
        }
        location.reload();
      }, 2600);
    };
    el.addEventListener("webglcontextlost", lost, false);
    return () => {
      window.clearTimeout(timer);
      el.removeEventListener("webglcontextlost", lost);
    };
  }, [gl]);
  return null;
}

function Cardboard() {
  const mode = useApp((s) => s.mode);
  const phase = useApp((s) => s.phase);
  return mode === "cardboard" && phase === "play" ? <CardboardRig /> : null;
}

export default function World() {
  return (
    <Canvas
      dpr={[1, 1.5]}
      frameloop="always"
      camera={{ fov: 72, near: 0.08, far: 900, position: [0, 6, 21] }}
      gl={{ antialias: true, powerPreference: "high-performance", alpha: false, stencil: false }}
    >
      <XR store={xrStore}>
        <color attach="background" args={["#0a0c1c"]} />
        <fogExp2 attach="fog" args={["#3a2848", 0.0036]} />
        <ContextGuard />

        <SkyDome />
        <Stars count={2200} />
        <Mountains />
        <CloudSea />

        {/* Фиксированное разрешение: смена качества не должна пересоздавать окружение */}
        <Environment resolution={256} frames={1} environmentIntensity={0.38}>
          <color attach="background" args={["#121029"]} />
          <Lightformer form="rect" intensity={4} color="#ff9a5c" position={[0, 1.5, -9]} scale={[16, 3, 1]} />
          <Lightformer form="rect" intensity={1.5} color="#8aa0ff" position={[0, 9, 0]} rotation-x={Math.PI / 2} scale={[16, 16, 1]} />
          <Lightformer form="ring" intensity={2} color="#ffd9a0" position={[0, 4, 0]} rotation-x={Math.PI / 2} scale={5} />
          <Lightformer form="rect" intensity={0.9} color="#b49cff" position={[9, 3, 6]} rotation-y={-Math.PI / 2} scale={[8, 4, 1]} />
        </Environment>
        <hemisphereLight args={["#8b84c8", "#211a38", 0.55]} />
        <pointLight position={[0, 7.4, 0]} color="#ffd6a0" intensity={16} distance={26} decay={1.8} />
        <directionalLight position={[0, 7, -30]} color="#ffb27a" intensity={1.55} />
        <directionalLight position={[12, 20, 14]} color="#8a9cff" intensity={0.45} />

        <Platform />
        <Vault />
        <Center />
        <Stations />
        <Cards />
        <Tomes />
        <Dressing />
        <StainedLight />
        <Motes count={620} radius={19} height={12} />
        <VRDetail />

        <Player />
        <XRRig />
        <Cardboard />
        <Effects />
        <ReadyFlag />
        <PerfGuard />
      </XR>
    </Canvas>
  );
}
