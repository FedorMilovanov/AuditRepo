# Пакет Research + Gill + три мобильных движка

## Читать по порядку

1. `01_MASTER_AUDIT_RESEARCH_AND_3_ENGINES.md`
2. `GILL_RESEARCH_COVERAGE_MATRIX.csv`
3. `02_GILL_ATMOSPHERE_EDITORIAL_STANDARD.md`
4. `03_THREE_MOBILE_ENGINES_ARCHITECTURE.md`
5. `04_AGENT_IMPLEMENTATION_PLAN.md`
6. `05_MOBILE_TOC_VERIFICATION_PLAN.md`
7. `PATCH_VARIANT_A_INCREMENTAL.md`
8. `PATCH_VARIANT_B_FULL_PLATFORM.md`
9. `PROMPT_FOR_AGENT.md`
10. `patches/*`

## Как использовать

- Передать агенту ZIP целиком.
- Начать с verification current Gill TOC.
- Editorial и controls вести разными PR.
- Выбрать Variant A.
- Patch-файлы являются подготовленными предложениями и требуют rebase на свежий `main`.
- Не применять весь пакет одним мегакоммитом.
