# Mobile Chrome Platform — три движка и общий каркас

## 1. Цель

Получить один общий платформенный каркас и три тонких профиля:

1. `series` — Gill;
2. `article` — Hermenevtika;
3. `page` — обычные страницы с глобальным поиском.

Общий каркас должен позволять менять размеры, safe-area, sheet lifecycle, touch targets и accessibility один раз для всего сайта. При этом series/article/page не должны быть одним гигантским компонентом с десятками флагов.

---

## 2. Типы

```ts
export type MobileChromeEngine = 'series' | 'article' | 'page';

export type MobileChromePrimary =
  | { kind: 'learning'; label: string; controlsId: string }
  | { kind: 'search'; label: string }
  | { kind: 'custom'; label: string };

export type MobileChromeProgress =
  | { kind: 'dual'; articleLabel: string; seriesLabel: string }
  | { kind: 'single'; articleLabel: string }
  | { kind: 'none' };

export type MobileChromeToc =
  | { kind: 'series-and-part'; seriesOverlayId: string; partOverlayId: string }
  | { kind: 'article'; overlayId: string }
  | { kind: 'sections'; overlayId: string }
  | { kind: 'none' };

export interface MobileChromeContract {
  engine: MobileChromeEngine;
  id: string;
  primary: MobileChromePrimary;
  progress: MobileChromeProgress;
  toc: MobileChromeToc;
  playback: boolean;
  save: boolean;
  readerSettings: boolean;
}
```

---

## 3. Общие файлы

```text
src/components/article-pilots/_shared/
├── MobileChromeShell.astro
├── MobileSheetShell.astro
├── MobileChromeIcon.astro
├── mobileChromeTypes.ts
└── speedSlot.ts
```

Новые CSS/JS-файлы для controls не создавать: это нарушит текущий protected contract. Стили остаются в `css/floating-cluster.css`, runtime — в `js/floating-cluster-controller.js` до отдельного разрешённого refactor lane.

---

## 4. Shell

```astro
---
import type { MobileChromeEngine } from './mobileChromeTypes';

interface Props {
  engine: MobileChromeEngine;
  id: string;
  rootClass?: string;
  topClass?: string;
  bottomClass?: string;
}

const {
  engine,
  id,
  rootClass = '',
  topClass = 'mobile-top-bar',
  bottomClass = 'mobile-bottom-bar',
} = Astro.props;
---

<div
  id={id}
  class:list={['mobile-chrome', rootClass]}
  data-mobile-chrome
  data-mobile-chrome-engine={engine}
>
  <header class={topClass} data-mobile-topbar>
    <div class="mobile-chrome__top-leading"><slot name="top-leading" /></div>
    <div class="mobile-chrome__top-primary"><slot name="top-primary" /></div>
    <div class="mobile-chrome__top-playback"><slot name="top-playback" /></div>
    <div class="mobile-chrome__top-trailing"><slot name="top-trailing" /></div>
  </header>

  <footer class={bottomClass} data-mobile-bottombar>
    <div class="mobile-chrome__bottom-progress"><slot name="bottom-progress" /></div>
    <div class="mobile-chrome__bottom-context"><slot name="bottom-context" /></div>
    <div class="mobile-chrome__bottom-actions"><slot name="bottom-actions" /></div>
  </footer>

  <slot name="overlays" />
</div>
```

Shell ничего не знает о Gill, Hermenevtika, Pagefind, TTS, BookmarkEngine и quiz. Он только гарантирует структуру.

---

## 5. Sheet shell

```astro
---
interface Props {
  id: string;
  label: string;
  titleId?: string;
  kind: 'toc' | 'learning' | 'settings' | 'search' | 'actions';
}
const { id, label, titleId, kind } = Astro.props;
---

<div
  id={id}
  class:list={['toc-overlay', 'mobile-sheet-overlay', `mobile-sheet-overlay--${kind}`]}
  data-mobile-sheet={kind}
  aria-hidden="true"
>
  <section
    class:list={['toc-sheet', 'mobile-sheet', `mobile-sheet--${kind}`]}
    role="dialog"
    aria-modal="true"
    aria-label={titleId ? undefined : label}
    aria-labelledby={titleId}
  >
    <button
      type="button"
      class="toc-sheet__handle"
      data-mobile-sheet-close
      aria-label="Закрыть"
    ></button>
    <slot name="head" />
    <slot />
    <slot name="actions" />
  </section>
</div>
```

---

## 6. Series adapter

```text
Top:
Back · Home · Learning/Speed · Play · Save

Bottom:
Dual progress · Current part/section · Theme · Settings · Share

Overlays:
Series TOC · Part TOC · Learning · Settings
```

Series-specific:

- marks;
- dual progress;
- Series TOC;
- optional series SVG;
- series-level quiz/learning scope.

---

## 7. Single Article adapter

```text
Top:
Back · Home(optional) · Learning/Speed · Play · Save

Bottom:
Single progress · Current section · Theme · Settings · Share

Overlays:
Article TOC · Learning · Settings
```

Запрещено переносить из Gill:

- dual progress;
- Series TOC;
- Roman series marks;
- «часть N из M»;
- series-wide learning без явной конфигурации.

Hermenevtika получает тот же качественный shell, settings, sepia, speed slot, focus/overlay contract, но остаётся одиночной статьёй.

---

## 8. Page/Search adapter

```text
Top:
Back · Home · Global Search · optional page action

Bottom:
только реальные page actions
```

По умолчанию отсутствуют:

- Learning;
- TTS;
- reading progress;
- Save article;
- current reading section.

Search вызывает существующую command palette. Второй поиск не создаётся.

---

## 9. Runtime contract

Расширять существующий controller:

```js
function initMobileChrome() {
  document.querySelectorAll('[data-mobile-chrome]').forEach(initOneMobileChrome);
}

function initOneMobileChrome(root) {
  const engine = root.dataset.mobileChromeEngine;

  initMobileSheets(root);
  initMobileTopbar(root);
  initMobileProgress(root);

  if (root.querySelector('[data-mobile-speed-slot]')) {
    initInlineSpeed(root);
  }

  if (engine === 'series') initSeriesNavigation(root);
  if (engine === 'article') initArticleNavigation(root);
  if (engine === 'page') initPageSearch(root);
}
```

Старые IDs/classes сохраняются на первом этапе как compatibility contract.

---

## 10. CSS contract

```css
[data-mobile-chrome] {
  --mc-bg: var(--color-surface);
  --mc-ink: var(--color-text);
  --mc-muted: var(--color-text-muted);
  --mc-border: var(--color-border);
  --mc-accent: var(--color-accent);
}

[data-mobile-chrome-engine="series"] {
  --mc-progress-secondary: var(--gill-mobile-bar-gold);
}

[data-mobile-chrome-engine="article"] {
  --mc-progress-secondary: transparent;
}

[data-mobile-chrome-engine="page"] {
  --mc-progress-primary: transparent;
}
```

Новые правила сначала должны быть aliases поверх текущих Gill/Herm selectors. Удалять старые selectors можно только после parity и freeze.

---

## 11. Route configuration

После трёх пилотов:

```ts
mobileChrome: {
  enabled: true,
  engine: 'series' | 'article' | 'page',
  adapter: 'gill' | 'hermenevtika' | 'default-page'
}
```

Не определять engine по `pathname.includes(...)`.

---

## 12. Почему не mega-component

Плохой API:

```astro
<MobileBar
  isSeries
  isArticle
  hasLearning
  hasSearch
  hasTts
  hasDualProgress
  hasSecondToc
  ...
/>
```

Через несколько миграций он превратится в лес несовместимых условий. Общий shell + адаптеры сохраняют единый каркас и отдельную семантику.

---

## 13. Порядок миграции

1. Baseline Gill v5.
2. Shell extraction без DOM/visual изменений.
3. Gill adapter и pixel parity.
4. Hermenevtika adapter.
5. Hermenevtika новый Single Article UX.
6. Page/Search pilot.
7. Route registry.
8. Freeze.
9. Rollout.
