# Инструкция агенту по правилам репозитория

## 1. Обязательный pre-flight

До кода подтвердить чтение:

1. `docs/WORK_MODES.md`
2. `AGENTS.md`
3. `docs/LANE_LOCK_POLICY.md`
4. `migration/route-migration-matrix.json`
5. `AuditRepo/SANDBOX-ENV-2026-06-21.md`
6. `audit/external-checks/README.md`, если есть внешние проверки

Зафиксировать:

```text
Base main SHA
Production SHA
Branch
Lane
Shared files
In-flight branches
Route modes
```

## 2. Governance

- subsystem: PremiumControls / Mobile Chrome;
- mode: SYSTEM;
- risk: 3;
- lane обязателен;
- один subsystem на PR;
- raw finding не чинить;
- current-head evidence обязателен;
- production build = strangler-build;
- Playwright локально до push;
- Nagornaya не менять;
- новый control CSS/JS file не создавать;
- controller не дробить без отдельного lane/sign-off.

## 3. Этап 0 — verify Gill TOC

Проверить current `main`, а не старый mock.

Собрать:

```text
screenshots
trace
computed metrics
focus order
scroll lock state
console
DOM snapshot
```

Routes: все 6 Gill.  
Widths: 320, 360, 390, 430, 768.  
Themes: light, sepia, dark.

Если finding не воспроизводится, отметить stale/false positive.

## 4. Этап 1 — отдельный editorial PR

Ветка:

```text
fix/gill-editorial-integrity
```

Сделать:

- новое Введение;
- распределение свидетельств;
- glossary glue;
- headings Part IV;
- sources order;
- related;
- переводной contract;
- ссылки Core → Companion.

Не менять mobile chrome.

## 5. Этап 2 — shared shell extraction

Ветка:

```text
lane/system-mobile-chrome-core-v1
```

Создать:

```text
src/components/article-pilots/_shared/MobileChromeShell.astro
src/components/article-pilots/_shared/MobileSheetShell.astro
src/components/article-pilots/_shared/mobileChromeTypes.ts
```

Первый PR не меняет внешний вид Gill.

Acceptance:

- те же IDs/classes/order;
- zero screenshot diff или документированная техническая погрешность;
- те же Learning/Settings/TOC/TTS;
- никаких новых console warnings;
- existing audits зелёные.

## 6. Этап 3 — Gill Series adapter

Создать тонкий adapter.

Он собирает:

- dual progress;
- Learning;
- Series/Part TOC;
- marks;
- settings;
- TTS;
- Save/Share.

`GillSeriesMobileBar.astro` временно может быть compatibility wrapper. Удалять после подтверждённой миграции.

## 7. Этап 4 — Hermenevtika Single Article adapter

Сначала snapshot текущей страницы.

Перенести:

- single progress;
- Learning текущей статьи;
- Article TOC;
- settings sheet;
- scoped sepia;
- inline speed;
- Save/Share.

После parity удалить:

- локальный duplicate speed runtime;
- A−/A+ из bar;
- отдельный overlay lifecycle, если он дублирует общий;
- устаревший binary reader theme.

Не добавлять series progress/Series TOC.

## 8. Этап 5 — Page/Search adapter

Пилот на одном обычном route.

Top:

```text
Back · Home · Global Search · optional action
```

Bottom только при реальной необходимости.

Запрещено:

- Learning без learning content;
- TTS по умолчанию;
- fake progress;
- второй search engine.

## 9. Этап 6 — registry

После трёх пилотов добавить route profile. Engine выбирается registry, не строкой URL.

## 10. Команды

Использовать реальные scripts текущего `package.json`. Минимальный барьер:

```bash
git diff --check
npm run guard:shared-files
npm run strangler:build:production-like
npm run validate:static-publication
npm run strangler:deploy-readiness
```

Плюс существующие Gill/Hermenevtika-specific audits.

## 11. Freeze

После owner sign-off:

- 10–14 дней без layout экспериментов;
- только блокирующие fixes;
- production monitoring;
- rollout только после freeze.

## 12. Отчёт агента

```text
Task
Branch
Lane
Base SHA
Branch SHA
PR
Merge SHA
Main SHA after merge
Changed files
Commands
Routes
Viewports
Artifacts
Warnings
Deferred
Production verification
```
