# Gill mobile TOC — контрольная программа проверки

## 1. Source status

Текущий Gill использует:

```text
#partTocOverlay
#seriesTocOverlay
.toc-overlay
.toc-sheet
#gbs2PartToc
.toc-part-item
#backToSeries
```

Это правильный Gill-контракт. `.btoc-*` в новый стандарт не переносится.

## 2. Подозрительные места current source

1. `#gbs2PartTocEmpty` мог остаться после удаления прежнего local TOC search.
2. Scroll indicator стартует с `--scroll-pct:0%`; обновление надо доказать.
3. `toc-part-item__progress` может быть декоративным.
4. Current series item использует `href="#partTocOverlay"`; controller обязан переключить overlay/focus/scroll lock.
5. `partToc` задан вручную и может расходиться с headings MDX.
6. Generic labels «Раздел/Подраздел» не заменяют summary.
7. Длинный список Part IV может обрезаться на 320px.
8. Learning/Settings/Part/Series должны быть mutually exclusive.
9. Focus restore после `backToSeries` надо проверить.
10. Browser Back не должен оставлять lock или открытый невидимый dialog.

## 3. Routes

```text
/articles/dzhon-gill-istoricheskiy-kontekst/
/articles/dzhon-gill-chast-1-chelovek/
/articles/dzhon-gill-chast-2-uchenyi/
/articles/dzhon-gill-chast-4-ekzeget/
/articles/dzhon-gill-chast-3-nasledie/
/articles/dzhon-gill-spravochnik/
```

## 4. Matrix

Widths:

```text
320×568
360×800
375×812
390×844
430×932
768×1024
```

Themes:

```text
light
sepia
dark
```

Input:

```text
touch
keyboard
screen reader smoke
orientation change
```

## 5. Part TOC scenarios

- open by current-section button;
- close by handle;
- close by backdrop;
- close by Escape;
- focus trap;
- focus restore;
- H2 jump;
- H3 jump;
- current item visible;
- last item visible;
- actions row not clipped;
- progress indicator changes;
- no horizontal overflow;
- scroll lock released after navigation.

## 6. Series TOC scenarios

- open from Part TOC;
- current part → Part TOC;
- other part → route navigation;
- Back to series;
- browser Back;
- correct marks;
- six materials;
- current `aria-current`;
- focus moves correctly.

## 7. Coexistence

```text
Learning → Part TOC
Part TOC → Series TOC
Settings → Part TOC
Speed rail → Part TOC
TTS playing → Part TOC
Part TOC → Learning
```

В каждый момент:

```text
open overlays = 1
scroll locks = 1
focus traps = 1
```

## 8. Data drift audit

Собрать фактические H2/H3 IDs и сравнить с `page.partToc`:

- каждый `href` существует;
- duplicate href отсутствует;
- orphan heading либо осознанно скрыт, либо добавлен;
- current item соответствует viewport;
- source order совпадает.

## 9. Playwright skeleton

```ts
test.describe('Gill mobile TOC', () => {
  for (const width of [320, 360, 390, 430, 768]) {
    test(`lifecycle ${width}`, async ({ page }) => {
      await page.setViewportSize({ width, height: 844 });
      await page.goto('/articles/dzhon-gill-chast-3-nasledie/');

      await page.locator('#mobPartTocBtn').click();
      await expect(page.locator('#partTocOverlay')).toHaveClass(/is-open/);

      await page.locator('#backToSeries').click();
      await expect(page.locator('#seriesTocOverlay')).toHaveClass(/is-open/);
      await expect(page.locator('#partTocOverlay')).not.toHaveClass(/is-open/);

      await page.locator('#seriesTocOverlay .is-current').click();
      await expect(page.locator('#partTocOverlay')).toHaveClass(/is-open/);

      await page.keyboard.press('Escape');
      await expect(page.locator('#partTocOverlay')).not.toHaveClass(/is-open/);
    });
  }
});
```

Заменить условные assertions на реальные lock/focus contracts проекта.

## 10. Evidence pack

Для каждого failure:

```text
Target SHA
Route
Viewport
Theme
Steps
Expected
Actual
Screenshot
Trace
Console
DOM/computed evidence
Severity
Repair lane
```

Только confirmed-current finding переводится в repair-ready.
