# Patch Variant A — инкрементальное извлечение каркаса

**Рекомендуемый вариант.**

## Цель

Извлечь общий shell без изменения Gill v5.

## PR A1 — shared Astro/TS

Добавить:

```text
MobileChromeShell.astro
MobileSheetShell.astro
mobileChromeTypes.ts
```

Gill продолжает рендерить те же classes, IDs, order и data-actions.

Visual diff должен быть нулевым.

## PR A2 — additive runtime contract

В существующий controller добавить:

```text
[data-mobile-chrome]
[data-mobile-sheet]
[data-mobile-sheet-close]
```

Старые Gill/Herm IDs остаются fallback. Не удалять их в том же PR.

## PR A3 — Gill adapter

Перенести current Gill markup в slots. Не менять:

- размеры;
- иконки;
- позиции;
- auto-hide;
- Learning;
- Settings;
- TOC;
- TTS.

После parity compatibility wrapper можно убрать отдельным commit.

## PR A4 — Hermenevtika adapter

Сначала только shell migration с сохранением старого UX.

Затем отдельным PR:

- Learning вместо прежнего top search;
- Settings sheet вместо A−/A+;
- scoped sepia;
- единый overlay lifecycle;
- single article progress.

## PR A5 — Page/Search pilot

Один обычный route:

- global Search сверху;
- no Learning;
- no TTS;
- no fake progress;
- optional page actions.

## Преимущества

- маленькие diff;
- проще откат;
- проще parity;
- соответствует protected subsystem;
- позволяет freeze между фазами.

## Недостаток

Некоторое время остаются legacy selectors и CSS aliases. Это приемлемая цена за отсутствие красивого крупного регрессионного пожара.
