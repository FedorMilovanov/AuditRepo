# Patch Variant B — полная платформенная переработка

**Не выполнять первым.**

## Состав

- единый `MobileChromeHost`;
- route registry;
- common overlay manager;
- common topbar auto-hide;
- progress adapters;
- reader settings service;
- search/learning primary slots;
- общая CSS token layer;
- migration всех routes.

## Условия запуска

- Variant A стабилен;
- Gill freeze завершён;
- Hermenevtika adapter прошёл sign-off;
- Page pilot прошёл sign-off;
- owner утвердил canonical architecture;
- отдельный SYSTEM lane;
- current production baseline сохранён.

## Риск

Одновременно затрагиваются:

```text
shared CSS
shared JS
layouts
route registry
Gill
Hermenevtika
generic pages
visual parity
```

При регрессии root cause будет размазан между shell, adapter, registry, controller и CSS. Поэтому Variant B является вторым этапом, а не эффектным первым коммитом на сотню файлов.
