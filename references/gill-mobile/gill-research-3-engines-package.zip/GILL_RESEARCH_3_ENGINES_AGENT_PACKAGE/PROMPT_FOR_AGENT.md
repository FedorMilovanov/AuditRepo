# Задание агенту: Gill Research + три мобильных движка

Работай по пакету `GILL_RESEARCH_3_ENGINES_AGENT_PACKAGE`.

## Цель

1. Закрыть editorial integrity Gill и подготовить Research Companion.
2. Доказательно проверить текущий Gill mobile TOC.
3. Извлечь общий mobile chrome shell без изменения Gill v5.
4. Создать три стандарта:
   - Series Reader — Gill;
   - Single Article Reader — Hermenevtika;
   - Page/Search Shell — обычные страницы.

## Обязательный порядок

1. Прочитай `docs/WORK_MODES.md`, `AGENTS.md`, `docs/LANE_LOCK_POLICY.md`, route matrix, AuditRepo sandbox document.
2. Зафиксируй current main SHA и production SHA.
3. Проверь in-flight branches/lanes.
4. Выполни `05_MOBILE_TOC_VERIFICATION_PLAN.md`.
5. Не чини непроверенные findings.
6. Editorial изменения вынеси в отдельный PR.
7. Используй Patch Variant A.
8. Сначала извлеки shell с нулевым visual diff Gill.
9. Только после Gill parity переноси Hermenevtika.
10. Только после Hermenevtika sign-off добавляй Page/Search pilot.

## Архитектурные инварианты

- `.btoc-*` не является новым каноном.
- Не создавать новый control CSS/JS file.
- Не создавать второй search, TTS, BookmarkEngine или overlay manager.
- Не делать mega-component с boolean soup.
- Shell содержит slots и accessibility structure.
- Series/Article/Page реализуются адаптерами.
- Runtime остаётся в существующем controller до отдельного разрешённого refactor.
- CSS остаётся в существующем `floating-cluster.css` до отдельного разрешённого refactor.
- Все current Gill IDs/classes сохраняются на первом extraction PR.

## Editorial инварианты

- Не добавлять все 42 Research-досье в Core Series.
- Core и Research Companion разделить.
- Убрать оправдания Введения.
- Не делать блок «мощные цитаты».
- Распределить короткие свидетельства по месту.
- Русский перевод всегда first/front.
- English original reverse, `lang=en`, default Pagefind/TTS ignore.
- Part IV integrity исправляется до построения learning targets.

## Git/verification

- SYSTEM / Risk-3 / lane.
- Один subsystem на PR.
- FAST loop при разработке.
- FULL gate перед push/merge.
- Production-like strangler build.
- Playwright screenshots/traces.
- После merge проверить remote main и production.

## Верни

```text
Task
Branch
Lane
Base SHA
Branch SHA
PR
Merge SHA
Main SHA after merge
Changed files
Commands
Routes
Viewports
Evidence artifacts
Warnings
Deferred
Production verification
```
