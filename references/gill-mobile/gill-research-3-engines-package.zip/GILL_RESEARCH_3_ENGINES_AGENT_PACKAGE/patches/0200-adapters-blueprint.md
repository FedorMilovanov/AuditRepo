# Adapter patch blueprint

## Gill

```astro
<MobileChromeShell engine="series" id="gillMobileChrome" rootClass="gill-mobile-chrome">
  <Fragment slot="top-leading">Back + Home</Fragment>
  <Fragment slot="top-primary">Learning / inline speed slot</Fragment>
  <Fragment slot="top-playback">Play + rate badge</Fragment>
  <Fragment slot="top-trailing">Save</Fragment>

  <Fragment slot="bottom-progress">DualProgress</Fragment>
  <Fragment slot="bottom-context">Current part/section</Fragment>
  <Fragment slot="bottom-actions">Theme + Settings + Share</Fragment>

  <Fragment slot="overlays">
    <GillSeriesOverlay />
    <GillPartTocOverlay />
    <GillLearningSheet />
    <GillReaderSettingsSheet />
  </Fragment>
</MobileChromeShell>
```

## Hermenevtika

```astro
<MobileChromeShell engine="article" id="hermMobileChrome" rootClass="hm-mobile-chrome">
  <Fragment slot="top-leading">Back + optional Home</Fragment>
  <Fragment slot="top-primary">Learning / inline speed slot</Fragment>
  <Fragment slot="top-playback">Play + rate badge</Fragment>
  <Fragment slot="top-trailing">Save</Fragment>

  <Fragment slot="bottom-progress">SingleProgress</Fragment>
  <Fragment slot="bottom-context">Current section</Fragment>
  <Fragment slot="bottom-actions">Theme + Settings + Share</Fragment>

  <Fragment slot="overlays">
    <HermenevtikaTocSheet />
    <HermenevtikaLearningSheet />
    <ReaderSettingsSheet scope="article" />
  </Fragment>
</MobileChromeShell>
```

## Generic page

```astro
<MobileChromeShell engine="page" id="pageMobileChrome" rootClass="page-mobile-chrome">
  <Fragment slot="top-leading">Back + Home</Fragment>
  <Fragment slot="top-primary">
    <button data-fc-action="search">Поиск</button>
  </Fragment>
  <Fragment slot="top-trailing">optional page action</Fragment>

  <Fragment slot="bottom-context">optional section label</Fragment>
  <Fragment slot="bottom-actions">Theme + Share/Actions</Fragment>
</MobileChromeShell>
```

Это blueprint, не третий набор копипаста. Сначала сохранить current Gill DOM внутри slots и доказать parity.
